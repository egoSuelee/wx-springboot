create proc CreateRkdSaveTable_chen
@guizuno varchar(32),
@TableName varchar(100)
as
begin
        if (select object_id('tempdb..'+@TableName))is not null
         exec('drop table '+@TableName)
	declare @sql varchar(5000)
	select @sql='create table '+@TableName+'('
	select @sql=@sql+'
	rkdno varchar(32),
        serno int,
	spno varchar(32),
	mingcheng varchar(64),
	guige varchar(32),
	dw1 varchar(32),
	danwei varchar(32),
	shuliang money,
	jinjia money,
	jinjiajine money,
	shuilv money,
	shuilvjine money,
	shoujia money,
	shoujiajine money,
	chajiajine money,
	cangkuno varchar(32),
	cangku varchar(64),
	guizuno varchar(32),
	zdriqi datetime,
	zdtime datetime '
	
  declare @Type varchar(32)
  declare @AllType varchar(5000)
  set @Type=''
  set @AllType=''
  if @guizuno<>''
  begin
	declare Cur_type cursor for 
	select type from guizu_type
	where guizuno=@guizuno
	open Cur_type
	
	fetch next from Cur_type into @type
	while (@@fetch_status=0)
	begin
	  set @AllType=@AllType+','+@type+ ' money '
	  fetch next from Cur_type into @type
	end
	
	close Cur_type
	dealLocate Cur_type
	
   end

	set @sql=@sql+@AllType+')'
	exec(@sql)

end

--CreateRkdSaveTable_chen '100','##rkdsp_chen'
--select * from ##rkdsp_chen
GO
