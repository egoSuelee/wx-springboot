create proc FindPayment_chen
@SaveToTableName varchar(32),
@gysNo varchar(32),
@date1 datetime,
@date2 datetime
as
begin
	 if (select object_id('tempdb..'+@SaveToTableName))is not null
	begin
	 exec('drop table '+ @SaveToTableName)
	end
	
	if (select object_id('tempdb..#payment_tmp'))is not null
	begin
	   drop table #payment_tmp
	end

	set @gysNo=ltrim(rtrim(@gysno))
	select a.cMainsheetNo,a.gysno,a.gys,a.dDate,a.dOperate,a.cOperator,a.accountant,
	a.fMoney_payoff as fMoney,b.paymentType,b.fmoney_payoff,b.iTypeNo
	into #payment_tmp
	from 
	(
	select distinct gysNo,gys,cMainSheetNo,fMoney_Payoff=sum(isnull(fMoney_Payoff,0)),
	dDate,dOperate,cOperator=cOperatorNo+':'+cOperator,accountant=accountantNo+':'+accountant
	from t_Account_supplier
	group by gysNo,gys,cMainSheetNo,dDate,dOperate,cOperatorNo,cOperator,accountantNo,accountant
	
	)a left join t_Account_supplier_payment b
	on a.cMainSheetNo=b.cSheetNo
  where (a.dDate between @date1 and @date2)
	and (((@gysNo<>'')and(gysno=@gysno))or(@gysNo=''))

	
	declare @sql varchar(8000)
	set @sql='select 序号='' '',cast(cMainsheetNo as varchar(32)) as ''付款单号'',gysno as ''供应商编号'',gys as ''供应商'',dDate as ''付款日期'',dOperate as ''操作日期'',
   cOperator as ''出纳'',accountant as ''会计'',fMoney as ''付款金额''' 
	select @sql=@sql+',['+paymentType+']=sum(case paymentType when '''+paymentType+''' then fMoney_payoff else 0 end)'
	from ( select distinct paymentType from #payment_tmp  
	       where paymentType is not null 
	      )a

  set @sql=@sql+ ' into '+@SaveToTableName+' from #payment_tmp group by cMainsheetNo,gysno,gys,dDate,dOperate,cOperator,accountant,fMoney'
--print @sql

  exec(@sql)


end

--select * from ##chen
--FindPayment_chen '##chen','','2009-09-07','2009-09-08'


GO
