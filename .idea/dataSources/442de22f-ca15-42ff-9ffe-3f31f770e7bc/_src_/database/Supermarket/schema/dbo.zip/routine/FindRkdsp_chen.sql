create proc FindRkdsp_chen
@SaveToTableName varchar(32),
@Rkdno varchar(32)
as
begin
 if (select object_id('tempdb..'+@SaveToTableName))is not null
begin
 exec('drop table '+ @SaveToTableName)
end
if (select object_id('tempdb..'+@SaveToTableName+'_rkd'))is not null
begin
 exec('drop table '+ @SaveToTableName+'_rkd')
end
declare @sql varchar(8000)
set @sql='select rkdno,spno,mingcheng,guige,dw1,danwei,jinjia,shuilv,
         shoujia,cangkuno,cangku,guizuno,zdriqi,zdtime' 
select @sql=@sql+',['+type+']=sum(case type when '''+type+''' then shuliang else 0 end)'
from ( select distinct type from  rkd_sp 
       where type is not null and rkdno=@Rkdno
      )a
set @sql=@sql+',shuliang=sum(shuliang)
          into '+@SaveToTableName+'_rkd 
          from rkd_sp where rkdno='''+@Rkdno+'''
          group by  rkdno,spno,mingcheng,guige,dw1,danwei,jinjia,shuilv,
         shoujia,cangkuno,cangku,guizuno,zdriqi,zdtime'
exec(@sql)
exec('
select a.*,jinjiajine=isnull(a.shuliang,0)*isnull(a.jinjia,0),
           shuilvjine=(isnull(a.shuliang,0)*isnull(a.jinjia,0))*isnull(a.shuilv,0),
           shoujiajine=isnull(a.shuliang,0)*isnull(a.shoujia,0),
           chajiajine=isnull(a.shuliang,0)*isnull(a.shoujia,0)-isnull(a.shuliang,0)*isnull(a.jinjia,0)
into '+@SaveToTableName+ '
from '+@SaveToTableName+'_rkd  a'

)
end

--select * from ##chen
--findrkdsp_chen '##chen','RKD2009100-000001'

--select * from rkd where rkdno='RKD2009100-000001'
--select * from rkd_sp where rkdno='RKD2009100-000001'


GO
