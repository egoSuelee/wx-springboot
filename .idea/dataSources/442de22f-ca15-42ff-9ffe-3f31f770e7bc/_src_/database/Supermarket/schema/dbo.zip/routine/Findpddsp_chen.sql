create proc Findpddsp_chen
@SaveToTableName varchar(32),
@Rkdno varchar(32)
as
begin
 if (select object_id('tempdb..'+@SaveToTableName))is not null
begin
 exec('drop table '+ @SaveToTableName)
end
if (select object_id('tempdb..'+@SaveToTableName+'_pdd'))is not null
begin
 exec('drop table '+ @SaveToTableName+'_pdd')
end
declare @sql varchar(8000)
set @sql='select pddno,spno,mingcheng,guige,dw1,danwei,jinjia,shuilv,
         shoujia,cangkuno,cangku,guizuno,zdriqi' 
select @sql=@sql+',['+type+']=sum(case type when '''+type+''' then shuliang else 0 end)'
from ( select distinct type from  pdd_sp 
       where type is not null and pddno=@Rkdno
      )a
set @sql=@sql+',shuliang=sum(shuliang)
          into '+@SaveToTableName+'_pdd 
          from pdd_sp where pddno='''+@Rkdno+'''
          group by  pddno,spno,mingcheng,guige,dw1,danwei,jinjia,shuilv,
         shoujia,cangkuno,cangku,guizuno,zdriqi'
--print @sql
exec(@sql)
exec('
select a.*,jinjiajine=isnull(a.shuliang,0)*isnull(a.jinjia,0),
           shuilvjine=(isnull(a.shuliang,0)*isnull(a.jinjia,0))*isnull(a.shuilv,0),
           shoujiajine=isnull(a.shuliang,0)*isnull(a.shoujia,0),
           chajiajine=isnull(a.shuliang,0)*isnull(a.shoujia,0)-isnull(a.shuliang,0)*isnull(a.jinjia,0)
into '+@SaveToTableName+ '
from '+@SaveToTableName+'_pdd  a'

)
end

--select * from ##chen
--findpddsp_chen '##chen','edt_sheetno'

--select * from pdd_sp where rkdno='RKD2009100-000001'
--select * from rkd_sp where rkdno='RKD2009100-000001'


GO
