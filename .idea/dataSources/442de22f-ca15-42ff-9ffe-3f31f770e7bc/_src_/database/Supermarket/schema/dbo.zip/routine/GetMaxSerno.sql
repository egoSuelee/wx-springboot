
create  function GetMaxSerno(@cSheetNo varchar(32))
returns int
as
begin
  declare @MaxSerno int
  select @MaxSerno=max(iserno)
  from t_Account_supplier
  where rkdno=@cSheetNo
  if @MaxSerno is null 
  begin  
    set @MaxSerno=1
  end else 
  begin
    set @MaxSerno=@MaxSerno+1
  end

  return @MaxSerno
end



--select dbo.getMaxserno('001')

GO
