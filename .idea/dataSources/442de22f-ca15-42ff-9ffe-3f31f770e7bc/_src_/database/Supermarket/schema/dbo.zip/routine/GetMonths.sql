CREATE function GetMonths (@Month smallint, @Year int)
returns smallint
/*获取当月的天数*/
as
begin
 return(
				DAY(
						dateadd(dd,-1,DATEADD(m,
																	1,
																	cast(@Year as varchar(4)) + '-' + cast(@Month as varchar(2)) + '-01'
																 )
									 )
					 )
			 )
end


GO
