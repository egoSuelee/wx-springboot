

create   function LeftAddChar
(@Str varchar(32),@Char char(1),@iLen int) returns varchar(32)
as
begin
  declare @i int
  declare @iMyLen int
  set @i=1
  set @Str=rtrim(ltrim(@Str))
  set @iMyLen=len(@Str)
  if @iLen>@iMyLen
  begin
    while @i<=@iLen-@iMyLen
    begin
      set @Str=@char+@Str
      set @i=@i+1 
    end
  end
  return @Str
end


GO
