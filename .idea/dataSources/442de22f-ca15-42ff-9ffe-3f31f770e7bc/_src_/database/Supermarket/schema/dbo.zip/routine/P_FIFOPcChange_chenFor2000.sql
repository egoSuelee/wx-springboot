/*
  批次调整(向后调整)
drop table #t_wh_form
drop table #t_Cost_distribute
select * into #t_wh_form
from t_wh_form 
where cGoodsNo in('10114','10309')

select * into #t_Cost_distribute
from dbo.t_Cost_distribute
where iSerNo in(select iserNo  from t_wh_form 
where cGoodsNo  in('10114','10309'))

select * from #t_wh_form
select * from #t_Cost_distribute where bdone=0

declare @i int
exec P_FIFOPcChange_chenFor2000 1,'101',3,@i output
select @i
*/
create proc P_FIFOPcChange_chenFor2000
@iSerNo_old bigint,       --需要调整的批次号
@cGoodsNo_old varchar(32),--待调整的商品编号
@iSerNo_New bigint,       --调整为新的批次号
@iReturn int output
as

--set @iSerNo_old=4805
--set @iSerNo_New=6267
--set @iReturn=0
set xact_abort on
set @iReturn=10
if not exists
(
  select iSerNo,cGoodsNo from t_wh_form
  where iSerNo=@iSerNo_old and cGoodsNo=@cGoodsNo_old
)
begin
  --print '待调整的批次号商品信息不存在'
  set @iReturn=9
  return
end
if not exists
(
  select iSerNo from t_wh_form
  --where iSerNo=@iSerNo_New
)
begin
  --print '欲调整的批次号不存在'
  set @iReturn=1
  return
end

declare @tmpIN money
declare @tmpOut money
select @tmpIN=sum(isnull(fQty_in,0)),@tmpOut=sum(isnull(fQty_out,0)) 
from t_wh_form
where cGoodsNo=@cGoodsNo_old

--此商品是负库存商品，不允许调整批次
if @tmpIN<@tmpOut
begin
  --print '此商品是负库存商品'
  set @iReturn=2
  return
end
declare @num money
select @num=fQty_in-fQty_out
from t_wh_form
where iSerNo=@iSerNo_old
if @num=0 
begin
  --print '此商品已售完，无需调整'
  set @iReturn=3
  return
end
--找到最大批次号，新调整的批次号不能大于最大批次号
declare @iSerNo_Max bigint 
select @iSerNo_Max=max(iMyIdentity)from t_wh_form
set @iSerNo_Max=isnull(@iSerNo_Max,0)
if (@iSerNo_New>@iSerNo_Max)or(@iSerNo_New<1)
begin
  --调整后的批次号不在现有批次号内
  --print '调整后的批次号不在现有批次号内'
  set @iReturn=4
  return
end
if exists
(
 select cGoodsNo 
 from t_wh_form 
 where iSerNo=@iSerNo_New and cGoodsNo=@cGoodsNo_old
)
begin
   --新调整的批次号的商品编号如果和待调整的商品相同
   --print '新调整的批次号的商品编号和待调整的商品相同'
   set @iReturn=5
   return 
end

--找出调整批次前是否有此商品
if @iSerNo_New>@iSerNo_old
begin
  if not exists
  (
    select cGoodsNo,iserNo
    from t_wh_form
    where iSerNo between @iSerNo_old+1 and @iSerNo_New and cGoodsNO=@cGoodsNo_old
  )
  begin
    --print '调整的批次前无此商品'
    set @iReturn=6
    return  
  end
end else
begin
  if not exists
  (
    select cGoodsNo,iserNo
    from t_wh_form
    where iSerNo between @iSerNo_New+1 and @iSerNo_old-1 and cGoodsNO=@cGoodsNo_old
  )
  begin
    --print '调整的批次后无此商品'
    set @iReturn=7
    return  
  end
end

begin tran
    update t_wh_form
    set iSerNo=@iSerNo_New
    where iSerNo=@iSerNo_old and cGoodsNo=@cGoodsNo_old

    update t_Cost_distribute
    set iSerNo=@iSerNo_New
    where iSerNo=@iSerNo_old and cGoodsNo=@cGoodsNo_old
commit tran
set @iReturn=0


GO
