/*
P_GetChildren '1','diquno','cParentNo','diqu','0'
*/

CREATE   procedure P_GetChildren
@cNode varchar(64),
@Fieldname varchar(64),
@Fieldname_parent varchar(64),
@TableName varchar(64),
@bBoolean char(1)--是否显示非叶子节点
as
begin
  select TypeNo=cast(@cNode as varchar(64)) into #temp_table
  select TypeNo=cast(@cNode as varchar(64)) into #temp_table2
  select TypeNo=cast(@cNode as varchar(64)) into #temp_table3

	exec('
	  while (select count('+@Fieldname+') from '+@TableName+' where '+@Fieldname_parent+' in 
	       (select '+@Fieldname_parent+'=TypeNo  from #temp_table))>0
	  begin
	    delete from #temp_table
	    insert into #temp_table (TypeNo)
	    (             
	    select TypeNo=a.'+@Fieldname+' from '
			+@TableName+' a right join #temp_table2 b on a.'+@Fieldname_parent+'=b.TypeNo
	    )
	
	    if ('+@bBoolean+'=''1'')
	    begin
				      insert into #temp_table3 (TypeNo)
				      (             
				      select TypeNo=a.'+@Fieldname+' from '+@TableName+' a right join #temp_table2 b on a.'+@Fieldname_parent+'=b.Typeno
				      )
	    end else
	    begin
	      delete from #temp_table3
	    end
	              
	    delete from #temp_table2
	    insert into #temp_table2 (TypeNo)
	    (select TypeNo from #temp_table)
	
	  end
	
	')

  if (@bBoolean='1')
  begin
    select TypeNo from #temp_table3 where TypeNo is not NULL
  end else
  begin
    select TypeNo from #temp_table where TypeNo is not NULL
  end

end

GO
