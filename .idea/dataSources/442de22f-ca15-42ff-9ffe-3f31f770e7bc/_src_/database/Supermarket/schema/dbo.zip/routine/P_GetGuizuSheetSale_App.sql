/*
  P_GetGuizuSheetSale_App '1002','2015-5-01','2015-5-31','100201'
  
*/
create proc P_GetGuizuSheetSale_App
@guizuNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@pinpaiNo varchar(32)
as
begin
if (select object_id('tempdb..#tmp_Sheetguizu'))is not null
drop table #tmp_Sheetguizu

select Lsriqi,LsdNo,b.SpNo,b.Mingcheng,Shuliang,Danjia,Jine,Dw1,b.Danwei,b.pinpai 
into #tmp_Sheetguizu
from lsdsp a,Spxx b
where Lsriqi between @dDate1 and @dDate2 and a.SpNo=b.SpNo
and b.guizuno=@guizuNo and b.pinpaino=@pinpaiNo
order by Lsriqi desc

if (select object_id('tempdb..#tmp_SheetguizuHeji'))is not null
drop table #tmp_SheetguizuHeji

select Lsriqi,LsdNo,SpNo,Mingcheng,Shuliang,Danjia,Jine,Dw1,Danwei,pinpai,a=0
into #tmp_SheetguizuHeji
from #tmp_Sheetguizu
union all
select Lsriqi,LsdNo='合计',SpNo=null,Mingcheng=null,sum(Shuliang),Danjia=null,
sum(Jine),Dw1=null,Danwei=null,pinpai=null,a=1
from #tmp_Sheetguizu 
group by Lsriqi

select Lsriqi,LsdNo,SpNo,Mingcheng,Shuliang,Danjia,Jine,Dw1,Danwei,pinpai 
from #tmp_SheetguizuHeji
order by Lsriqi desc,a


end
GO
