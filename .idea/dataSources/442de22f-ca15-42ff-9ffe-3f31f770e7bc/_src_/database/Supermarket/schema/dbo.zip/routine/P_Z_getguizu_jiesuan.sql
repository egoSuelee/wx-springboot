create       procedure P_Z_getguizu_jiesuan
  @guizuno varchar(16)
as
  
  select jiesuanno,guizu,guizuno,
         xiaoshoujine,feiyongjine,
         jiesuanjine,baodijine,koudian,
         koudianjine,qita,dbo.getDayStr(jiesuanriqi) as jiesuanriqi,
         shenhe=case when shenhe=1 then '√'
                     else ''
                end,dbo.getDayStr(riqi1) as riqi1,
        dbo.getDayStr(riqi2) as riqi2,fukuan=case when fukuan=1 then '√'
													 else ' '
											end,
				dbo.getDayStr(fukuanriqi) as fukuanriqi
  from   guizu_jiesuan
  where guizuno=@guizuno


GO
