create    procedure P_Z_getguizu_jiesuan_mingxi
        @jiesuanno varchar(32)
as
  select jiesuanno,dbo.getDayStr(zdriqi) as zdriqi,
         guizuno,guizu,xiaoshoujine,yingfujine
  from   guizu_jiesuan_mingxi
  where  jiesuanno=@jiesuanno


GO
