
create     procedure P_Z_guizufeiyong
  @jiesuanno varchar(32)
as
begin
    select  guizuno,guizu,feiyongno,feiyong,
            feiyongjine,jiesuanno,beizhu,
            shenhe,caiwu,shenheren,
            dbo.getDayStr(zdriqi) as zdriqi,
            jiesuanover,fukuan,
            dbo.getTimeStr(zdtime) as zdtime,
            serno,
            dbo.getDayStr(riqi1) as riqi1,
            dbo.getDayStr(riqi2) as riqi2,
            dbo.getDayStr(dFill) as dFill
   from    guizufeiyong
   where jiesuanno=@jiesuanno

end

GO
