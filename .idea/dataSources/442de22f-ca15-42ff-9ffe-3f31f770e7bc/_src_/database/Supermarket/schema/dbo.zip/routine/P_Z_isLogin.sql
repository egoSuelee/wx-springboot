create     procedure P_Z_isLogin
  @guizuno varchar(16),
  @password varchar(32),
  @userID int output
as
begin
  select guizuno
  from guizu
  where 
      guizuno=@guizuno
  and   
     isnull(password_guizu,'')=isnull(@password,'')

  if @@rowcount>0
  begin
      set @userID=1
  end else
  begin
      set @userID=0
  end
end


GO
