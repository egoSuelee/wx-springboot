
create  PROCEDURE P_Z_tabletest

AS
BEGIN

  if  (select object_id('tempdb..##t_Guizuis')) is not null
	drop table ##t_Guizuis
  
  select guizuno,guizu
  into ##t_Guizuis
  from guizu


END

GO
