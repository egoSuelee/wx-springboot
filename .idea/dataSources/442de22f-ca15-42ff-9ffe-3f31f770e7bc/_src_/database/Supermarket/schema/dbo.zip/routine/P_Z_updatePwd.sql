

create     procedure P_Z_updatePwd
  @guizuno varchar(16),
  @password varchar(32),
  @userID int output
as
  update guizu
  set password_guizu=@password
  where 
      guizuno=@guizuno
  if @@rowcount>0
  begin
      set @userID=1
  end else
  begin
      set @userID=0
  end


GO
