create  function f_GetClientID_chen
(@zoneId varchar(32)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   declare @strTemp varchar(32)
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cClientID) from t_Client
                  where ((cZoneID=@zoneId)
                  or (substring(cClientID,0,PatIndex('%-%',cClientID))=@zoneId))
                   )
   if @cMaxSerno is null 
   begin
     set @strTemp=@zoneId+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp=@zoneId+'-'+@cMaxSerno
   end
   return  @strTemp

end
--print dbo.f_GetClientID_chen ('11271')


GO
