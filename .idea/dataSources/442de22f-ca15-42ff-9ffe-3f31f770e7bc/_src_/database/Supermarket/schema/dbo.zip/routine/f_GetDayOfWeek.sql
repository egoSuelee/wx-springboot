create  function f_GetDayOfWeek
(@dDatetime datetime) returns int
as
begin
return 
	case when datepart(dw,@dDatetime)=1 
						 then 7 
						 else datepart(dw,@dDatetime)-1
	end
end

GO
