


create        function f_GetMainSheetNo
(@cYear varchar(4),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   declare @strTemp varchar(32)
	 declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cMainSheetNo) from dbo.t_Account_supplier
                  where (gysNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear
												)
												or
												(substring(cMainSheetNo,4,PatIndex('%-%',cMainSheetNo)-4)=@cSupplierNo
												 and datename(yyyy,dDate)=@cYear	
												)
                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp=@cYear+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp=@cYear+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end



--select dbo.f_GetMainSheetNo('2009','123')


GO
