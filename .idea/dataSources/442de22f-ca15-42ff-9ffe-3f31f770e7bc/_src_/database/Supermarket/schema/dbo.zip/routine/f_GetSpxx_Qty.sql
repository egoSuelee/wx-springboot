create function f_GetSpxx_Qty
(@spno varchar(32)) returns Money
as
begin
  declare @belong varchar(32)
  declare @fQty Money
  declare @fQty_tmp money
  set @belong=(select top 1 belong from spxx where spno=@spno)
	set @fQty=(select sum(isnull(fQty,0)) from spxx where (belong=@belong) and @belong is not null )
	set @fQty_tmp=(select sum(isnull(fQty_wanted,0)) from Spxx_Store_Qty_temp 
								where spno in (select spno from spxx where belong=@belong) and @belong is not null )
  return isnull(@fQty,0)-isnull(@fQty_tmp,0)

end
GO
