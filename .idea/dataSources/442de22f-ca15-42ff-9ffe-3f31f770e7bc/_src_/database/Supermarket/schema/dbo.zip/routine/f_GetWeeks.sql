
CREATE   function f_GetWeeks
(@dDatetime datetime) returns int
as
begin
return 
case when datepart(dw,@dDatetime)=1 
					 then (case when datepart(wk,@dDatetime)>1 then datepart(wk,@dDatetime)-1 else datepart(wk,@dDatetime) end) 
					 else datepart(wk,@dDatetime) 
			end
end


GO
