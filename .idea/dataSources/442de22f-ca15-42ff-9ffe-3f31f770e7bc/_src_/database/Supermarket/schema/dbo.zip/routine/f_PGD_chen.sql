
create  function f_PGD_chen
(@cYear varchar(4),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
	 --declare @iPatIndex int
   declare @strTemp varchar(32)
	 declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(SheetNo_Install) from t_Installation
                  where (guizuno=@cSupplierNo
                        and datename(yyyy,dDatetime)=@cYear
												)
												or
												(substring(SheetNo_Install,8,PatIndex('%-%',SheetNo_Install)-8)=@cSupplierNo
												 and datename(yyyy,dDatetime)=@cYear	
												)
                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp='PGD'+@cYear+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp='PGD'+@cYear+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end
--print dbo.f_PGD_chen ('2009','18016')


GO
