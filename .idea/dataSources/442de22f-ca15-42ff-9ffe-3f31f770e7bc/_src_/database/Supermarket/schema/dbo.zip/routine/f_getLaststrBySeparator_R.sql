create function f_getLaststrBySeparator_R
(
@cString varchar(1024),
@cSeparator char
) returns varchar(1024)
as 
begin
  declare @iLen int
  declare @iPos int
  declare @strtemp varchar(1024)
  set @strtemp=@cString
  set @iLen=DATALENGTH(@strtemp)
  set @iPos=PATINDEX('%'+@cSeparator+'%',@strtemp)
  while @iPos>0 
  begin
    set @strtemp=right(@strtemp,@iLen-@iPos)
		set @iLen=DATALENGTH(@strtemp)
		set @iPos=PATINDEX('%'+@cSeparator+'%',@strtemp)
  end
  return @strtemp
end
GO
