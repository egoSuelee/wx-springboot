





CREATE     function dbo.getTimeStr
(@theDatetime datetime) returns varchar(16)
as
begin
    return(
           case when len(datename(hh,@theDatetime))=1
                then '0'+datename(hh,@theDatetime)
                else datename(hh,@theDatetime)
            end


+':'+
           case when len(datename(n,@theDatetime))=1
                then '0'+datename(n,@theDatetime)
                else datename(n,@theDatetime)
            end
            +':'+
            case when len(datename(ss,@theDatetime))=1
                 then  '0'+datename(ss,@theDatetime)
                 else datename(ss,@theDatetime)
            end
           )
end


GO
