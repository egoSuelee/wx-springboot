
/*
drop table #jiesuanNoList
select jiesuanno into #jiesuanNoList from guizu_jiesuan

declare @s1 varchar(1000)
declare @s2 varchar(1000)
declare @s3 varchar(1000)
exec guizuJiesuanPrint2010 '天兰尾货六里桥店对账单', @s1 output,@s2 output,@s3 output
select @s1+@s2+@s3
select @s1
select @s2
select @s3
*/
create  proc guizuJiesuanPrint2010
@PageTit varchar(60),
@tit_1 varchar(1000) output,
@tit_2 varchar(1000) output,
@tit_3 varchar(1000) output
as
--declare @tit_1 varchar(1000)
--declare @tit_2 varchar(1000)
--declare @tit_3 varchar(1000)
select @tit_1='',@tit_2='',@tit_3=''
--if (select OBJECT_ID('tempdb..#jiesuanNoList'))is not null
--drop table #jiesuanNoList
--select jiesuanno into #jiesuanNoList from guizu_jiesuan

if (select OBJECT_ID('tempdb..#jiesuan_detail'))is not null
drop table #jiesuan_detail
select b.jiesuanno,a.guizuno,a.detail,a.shishou,a.jstype
into #jiesuan_detail
from jiesuan_byguizu a,lsd b
where a.zdriqi=b.Zdriqi and b.LsdNo=(a.sheetno+'-'+a.guizuno)
and ISNULL(b.jiesuanover,0)=1 
and b.jiesuanno in(select jiesuanno from #jiesuanNoList)

if (select OBJECT_ID('tempdb..#jiesuan_type'))is not null
drop table #jiesuan_type
select distinct detail 
into #jiesuan_type
from #jiesuan_detail

if (select OBJECT_ID('tempdb..##jiesuan_Money'))is not null
drop table ##jiesuan_Money

declare @sql varchar(7000)

set @sql=''
set @sql='select jiesuanno_tmp1=jiesuanno'
select @sql=@sql+','+detail+'=round(isnull(sum(case detail when '''+detail+''' then isnull(shishou,0)  else 0 end),0),2)'
from #jiesuan_type
set @sql=@sql+',销售金额=round(sum(isnull(shishou,0)),2)'
set @sql=@sql+' into ##jiesuan_Money from #jiesuan_detail group by jiesuanno'

exec(@sql)

set @sql=''
select @sql=@sql+detail+','
from #jiesuan_type
set @tit_1=@sql+'销售金额'
--柜组费用
if (select OBJECT_ID('tempdb..#jiesuan_feiyong'))is not null
drop table #jiesuan_feiyong
if (select OBJECT_ID('tempdb..#jiesuan_feiyongType'))is not null
drop table #jiesuan_feiyongType
if (select OBJECT_ID('tempdb..##jiesuan_feiyonginfo'))is not null
drop table ##jiesuan_feiyonginfo
select jiesuanno,guizuno,guizu,feiyongno,feiyong,feiyongjine  
into #jiesuan_feiyong
from guizufeiyong
where ISNULL(jiesuanover,0)=1 and jiesuanno in(select jiesuanno from #jiesuanNoList )

select distinct feiyong
into #jiesuan_feiyongType
from #jiesuan_feiyong

set @sql=''
set @sql='select jiesuanno_tmp2=jiesuanno'
select @sql=@sql+','+feiyong+'=isnull(sum(case feiyong when '''+feiyong+''' then isnull(feiyongjine,0) else 0 end),0)'
from #jiesuan_feiyongType
set @sql=@sql+',扣点金额=cast(0 as money),其他=cast(0 as money),扣款合计=sum(isnull(feiyongjine,0))'
set @sql=@sql+' into ##jiesuan_feiyonginfo from #jiesuan_feiyong group by jiesuanno'

exec(@sql)

set @sql=''
select @sql=@sql+feiyong+','
from #jiesuan_feiyongType
set @tit_2=@sql+'扣点金额,其他'


if (select OBJECT_ID('tempdb..#jiesuan_last_tmp'))is not null
drop table #jiesuan_last_tmp
select 结算号=a.jiesuanno,组别=b.guizuno,经营品牌=b.guizu,销售数量=0,c.*,d.*,
实返金额=b.jiesuanjine,备注=b.beizhu,
cDate=@PageTit+'('+CONVERT(varchar(10),b.riqi1,102)+'-'+CONVERT(varchar(10),b.riqi2,102)+')'
into #jiesuan_last_tmp
from #jiesuanNoList a left join guizu_jiesuan b
on a.jiesuanno=b.jiesuanno
left join ##jiesuan_Money c
on a.jiesuanno=c.jiesuanno_tmp1
left join ##jiesuan_feiyonginfo d
on a.jiesuanno=d.jiesuanno_tmp2 and c.jiesuanno_tmp1=d.jiesuanno_tmp2



update a
set a.扣点金额=b.koudianjine
from #jiesuan_last_tmp a,guizu_jiesuan b
where a.结算号=b.jiesuanno

update #jiesuan_last_tmp set 扣款合计=isnull(扣款合计,0)+isnull(扣点金额,0)

update a
set a.其他=b.qita
from #jiesuan_last_tmp a,guizu_jiesuan b
where a.结算号=b.jiesuanno

alter table #jiesuan_last_tmp  
drop column jiesuanno_tmp1,jiesuanno_tmp2

update a
set a.销售数量=b.fQty
from #jiesuan_last_tmp a,
(
  select jiesuanno,fQty=SUM(Shuliang)
  from lsdsp
  where ISNULL(jiesuanover,0)=1 and jiesuanno in(select jiesuanno from #jiesuanNoList)
  group by jiesuanno
)b
where a.结算号=b.jiesuanno


update #jiesuan_last_tmp
set 扣款合计=0
where 扣款合计 is null

update #jiesuan_last_tmp
set 实返金额=0
where 实返金额 is null

update #jiesuan_last_tmp
set 扣点金额=0
where 扣点金额 is null

update #jiesuan_last_tmp
set 其他=0
where 其他 is null

declare cur_type cursor for
select feiyong from #jiesuan_feiyongType

open cur_type
declare @upType varchar(100)
fetch next from cur_type into  @upType
while @@FETCH_STATUS=0
begin
  exec('update #jiesuan_last_tmp
  set '+@upType+'=0
  where '+@upType+' is null ')
  fetch next from cur_type into  @upType
end
close cur_type
deallocate cur_type

--alter table #jiesuan_last_tmp  
--drop column 结算号

set @tit_1='结算号,组别,经营品牌,销售数量,'+@tit_1
set @tit_2=@tit_2
set @tit_3='扣款合计,实返金额,备注,cDate'
select * from #jiesuan_last_tmp

--print @tit_1
--print @tit_2
--print @tit_3


GO
