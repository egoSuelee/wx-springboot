
/*
[p_Account_Receiver_SumByPeriod] '','2012-01-01','2012-01-03'
go
[p_Account_Receiver] '','2012-01-01','2012-01-03'
*/

CREATE   procedure [dbo].[p_Account_Receiver_SumByPeriod]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime
as
begin
  /*生成报表的列*/

  select fMoney_Save=sum(isnull(fMoney_Save,0)),cOpertorNo,cOperName,dSaleDate=dbo.getdaystr(@date1)+'至'+dbo.getdaystr(@date2)
	into #temp_t_Vip_Save
	from t_Vip_Save
  where dSaleDate between @date1 and  @date2 and isnull(fMoney_Save,0)<>0
  group by cOpertorNo,cOperName

--select * from #temp_t_Vip_Save
  select detail,sum(shishou) shishou 
  into #jiesuan_detail0
	from jiesuan
  where  zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
  group by detail


  select detail,shishou 
  into #jiesuan_detail
	from #jiesuan_detail0
  union all
  select detail='电子钱包',shishou=sum(isnull(fMoney_Save,0))
  from #temp_t_Vip_Save
  
  
  
  --where ISNULL(bZeng,0)=0
 

  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     收银员No varchar(32) COLLATE Chinese_PRC_CI_AS ,
     收银员 varchar(32) COLLATE Chinese_PRC_CI_AS ,
     结算日期 varchar(32) COLLATE Chinese_PRC_CI_AS 
	)

  declare @cAddFields varchar(2000)
  set @cAddFields=''
  declare @strtmp varchar(2000)
  set @strtmp=''
  declare @strtmp_group varchar(2000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(2000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+'合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+'合计=cast(sum(cast(合计 as money)) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+'合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

   --select * into ##account_detail from #account_detail



	select shouyinyuanno,shouyinyuanmc,detail,zdriqi=dbo.getdaystr(@date1)+'至'+dbo.getdaystr(@date2),
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,sum(shishou) shishou
  into #jiesuan
	from jiesuan
	where zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
	group by  shouyinyuanno,shouyinyuanmc,detail
  union all
	select shouyinyuanno=cOpertorNo,shouyinyuanmc=cOperName,detail='电子钱包',zdriqi=dbo.getdaystr(@date1)+'至'+dbo.getdaystr(@date2),
	 mianzhi=sum(fMoney_Save),zhaoling=0, shishou=sum(fMoney_Save)
	from #temp_t_Vip_Save
	where dSaleDate between @date1 and  @date2
	group by  cOpertorNo,cOperName


	order by shouyinyuanno,shouyinyuanmc,zdriqi
 
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,zdriqi,shishou=cast(shishou as char(32))
  from #jiesuan
  order by zdriqi,shouyinyuanno,shouyinyuanmc,detail
  
  select sheetno,shouyinyuanno,shouyinyuanmc,zdriqi=dbo.getdaystr(@date1)+'至'+dbo.getdaystr(@date2),shishou=SUM(isnull(shishou,0))
  into #jiesuan_01
  from jiesuan
  where zdriqi between @date1 and  @date2
  group by sheetno,shouyinyuanno,shouyinyuanmc

 
  select shouyinyuanno,shouyinyuanmc,zdriqi=dbo.getdaystr(@date1)+'至'+dbo.getdaystr(@date2),shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  group by shouyinyuanno,shouyinyuanmc
  

  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou


  while @@fetch_status=0
  begin
		if (select 收银员No from #account_detail 
				where 收银员No=@shouyinyuanno and 收银员=@shouyinyuanmc and 结算日期=@zdriqi) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','''+@zdriqi+''','+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 收银员No='''+@shouyinyuanno+'''  and 收银员='''+@shouyinyuanmc+'''  and 结算日期='''+@zdriqi+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc and a.结算日期=b.zdriqi


 
  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
		+' if not exists 
		 ( 
		 select column_name from information_schema.columns  
		 where table_name=''#account_detail_last'' and column_name=''收款'' 
		 )   
		 begin  
			 alter table #account_detail_last add 收款 money,退款  money 
		 end 

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a left join
		(select shouyinyuanno,shouyinyuanmc,zdriqi,shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		group by zdriqi,shouyinyuanno,shouyinyuanmc	) b
		on a.结算日期=b.zdriqi and a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a ,
		(select shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		) b
		where  a.收银员No=''总计''
	 '
 
    +' select * from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 收银员No='''+@guizuno+''' '+'
    
    union all
    select 收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail where 收银员No='''+@guizuno+''' '
    +@strtmp_Clear
		+' if not exists 
		 ( 
		 select column_name from information_schema.columns  
		 where table_name=''#account_detail_last'' and column_name=''收款'' 
		 )   
		 begin  
			 alter table #account_detail_last add 收款 money,退款  money 
		 end 

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a left join
		(select shouyinyuanno,shouyinyuanmc,zdriqi,shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		group by zdriqi,shouyinyuanno,shouyinyuanmc	) b
		on a.结算日期=b.zdriqi and a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc
		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a ,
		(select shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		) b
		where  a.收银员No=''总计''
	 '
    +' select * from #account_detail_last')
  end

end


GO
