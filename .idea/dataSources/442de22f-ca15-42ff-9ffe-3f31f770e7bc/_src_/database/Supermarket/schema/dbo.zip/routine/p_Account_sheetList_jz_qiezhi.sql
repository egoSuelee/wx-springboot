



CREATE     procedure [dbo].[p_Account_sheetList_jz_qiezhi]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime
as
begin

   /*生成报表的列*/
	  set @guizuno=dbo.trim(@guizuno)
	  select detail,sum(shishou) shishou 
	  into #jiesuan_detail
		from jiesuan
    where  (jiaozhang=0 or jiaozhang is null) and (shouyinyuanno=@guizuno or @guizuno='') and zdriqi <= @date2
    group by detail
 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (  结算单号 varchar(32),
     结算日期 varchar(32),
     收银员No varchar(32),
     收银员 varchar(32)
	)

  declare @cAddFields varchar(2000)
  set @cAddFields=''
  declare @strtmp varchar(2000)
  set @strtmp=''
  declare @strtmp_group varchar(2000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(2000)
 -- set @strtmp_Clear='update #account_detail_last set '
  set @strtmp_Clear='update #account_detail set '
  while @@fetch_status=0
  begin
    set @detail=dbo.trim(@detail) 
    set @cAddFields=@cAddFields+@detail+' varchar(32),'+@detail+'找零 varchar(32),'+@detail+'实收 varchar(32),'
    set @strtmp=@strtmp+'''0'',''0'',''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
																	 +@detail+'找零=cast(sum(cast('+@detail+'找零 as money)) as varchar(32)),'
																	 +@detail+'实收=cast(sum(cast('+@detail+'实收 as money)) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
																	 +@detail+'找零=case when cast('+@detail+'找零 as money)=0 then ''-'' else '+@detail+'找零 end,'
																	 +@detail+'实收=case when cast('+@detail+'实收 as money)=0 then ''-'' else '+@detail+'实收 end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(sum(cast(合计 as money)) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'

--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

	select sheetno,shouyinyuanno,shouyinyuanmc,detail,zdriqi=dbo.getdaystr(zdriqi),
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,sum(shishou) shishou
  into #jiesuan
	from jiesuan
	where  (jiaozhang=0 or jiaozhang is null) and (shouyinyuanno=@guizuno or @guizuno='') and zdriqi <= @date2
	group by  sheetno,shouyinyuanno,shouyinyuanmc,detail,zdriqi
	order by sheetno,shouyinyuanno,shouyinyuanmc
  
  declare jiesuan_cursor cursor
  for
  select sheetno,shouyinyuanno,shouyinyuanmc,detail,zdriqi,mianzhi=cast(mianzhi as char(32))
         ,zhaoling=cast(zhaoling as char(32)),shishou=cast(shishou as char(32))
  from #jiesuan
  order by sheetno,shouyinyuanno,shouyinyuanmc,detail,zdriqi
 
  select sheetno,shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  group by sheetno
  

  declare @sheetno varchar(32)
  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @mianzhi varchar(32)
  declare @zhaoling varchar(32)
  declare @shishou varchar(32)
  declare @zdriqi varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @sheetno,@shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@mianzhi,@zhaoling,@shishou

--print @strtmp
/*
  insert into #account_detail (结算单号)
  select sheetno from #jiesuan_heji
*/
  while @@fetch_status=0
  begin

		if (select 结算单号 from #account_detail 
				where 结算单号=@sheetno) is null
    begin
      exec('insert into #account_detail select '''+@sheetno+''','''+@zdriqi+''','''
						+@shouyinyuanno+''','''+@shouyinyuanmc+''','+@strtmp)
    end
/*
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 结算单号='''+@sheetno+'''')

*/
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@mianzhi
					+'''),'+@detail+'找零=dbo.trim('''+@zhaoling+'''),'+@detail+'实收=dbo.trim('''+@shishou+''') where 结算单号='''+@sheetno+'''')

    fetch next from jiesuan_cursor
    into @sheetno,@shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@mianzhi,@zhaoling,@shishou
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.结算单号=b.sheetno


--return

print 'hello 001'
print @strtmp_Clear

  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 结算单号=''总计'',结算日期=null,收银员No=null,收银员=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select * from #account_detail_last')
  end else
  begin
    --exec(@strtmp_Clear)
    
    exec('
    select * into #account_detail_last from #account_detail where 收银员No='''+@guizuno+''' '+'
    
    union all
    select 结算单号=''总计'',结算日期=null,收银员No=null,收银员=null,'+@strtmp_group
    +' from #account_detail where 收银员No='''+@guizuno+''' '
    +@strtmp_Clear
    +' select * from #account_detail_last
    
    ')
    
    
  end

end

/*
#account_detail_last
*/



GO
