













CREATE              procedure [dbo].[p_CompareByDay]
--@quno varchar(32),
--@guizuno varchar(32),
--@spno varchar(32),
@date1 datetime,
@date2 datetime,
@tempTableQu varchar(32),
@tempTableGuizu varchar(32),
@tempTableSpno varchar(32)
as
begin
	declare @datePre datetime
	set @datePre=@date1-1
exec('
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,fCost,jingyingfangshi
  into #tempSpxx_Qu
	from dbo.v_Spxx_Qu '
	+' where quno in (select quno=cQuyuNo from '+@tempTableQu+') or '
	+'  guizuno in (select guizuno=cGuizuNo from '+@tempTableGuizu+') or '
	+'  spno in (select spno=cSpNo from '+@tempTableSpno+') '

	+'
	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,Profits=cast(0 as money),a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,
				 wk=dbo.f_GetWeeks(b.lsriqi),dw=dbo.f_GetDayOfWeek(b.lsriqi),b.lsriqi,
				 iPreWeek=case when b.lsriqi<'''+@date1+''' then 1 else 0 end
	into #tempLsdsp
	from #tempSpxx_Qu a left join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsdno=c.lsdno
	where b.Lsriqi between '''+@datePre+''' and '''+ @date2+''' and c.zdriqi between '''+@datePre+''' and '''+ @date2+'''
				and a.spno is not null

  update #tempLsdsp
	set Profits=case when isnull(fCost,0)<>0 then shishou-fCost else fRatio*shishou/100.00 end

	select wk,dw,shuliang=sum(Shuliang),shishou=sum(shishou),profits=round(sum(Profits),2),iPreWeek,lsriqi
	into #tempLsdsp_group0	
	from #tempLsdsp
	group by wk,dw,lsriqi,iPreWeek
--	order by wk,dw

  select a.wk,a.dw,a.lsriqi,shuliang=sum(a.Shuliang),shishou=sum(a.shishou),profits=sum(a.profits),
	shishiou_wk=(select shishiou_wk=sum(b.shishou) from #tempLsdsp_group0 b where b.iPreWeek=0),
	profits_wk=(select profits_wk=sum(b.profits) from #tempLsdsp_group0 b where  b.iPreWeek=0),
	iDays=(select iDays=count(b.dw) from #tempLsdsp_group0 b where  b.iPreWeek=0),iHoliday=case when a.dw in (6,7) then 1 else 0 end,
	a.iPreweek
	into #tempLsdsp_group1
	from #tempLsdsp_group0 a
	group by a.wk,a.dw,a.lsriqi,a.iPreWeek

  select wk,dw,lsriqi,shuliang,shishou,profits,shishiou_wk,
				 shishiou_wk_avg=round(shishiou_wk/iDays,2),profits_wk,profits_wk_avg=round(profits_wk/iDays,2),iDays,iHoliday,iPreweek
	into #tempLsdsp_group2
	from #tempLsdsp_group1


	select a.wk,a.dw,a.lsriqi,a.shuliang,a.shishou,a.profits,
	a.shishiou_wk,a.shishiou_wk_avg,a.profits_wk,a.profits_wk_avg,
	ringRatio_shishou=round(((select a.shishou/(case when b.shishou=0 then null else b.shishou end) from #tempLsdsp_group2 b where b.lsriqi=a.lsriqi-1 )-1)*100,3),
	iHoliday,fHoliday_No=(select sum(b.shishou) from #tempLsdsp_group2 b where b.iHoliday=0 and b.iPreWeek=0) ,
	fHoliday=(select sum(b.shishou) from #tempLsdsp_group2 b where   b.iHoliday=1 and b.iPreWeek=0),
	iDays_Holiday_no=(select count(b.shishou) from #tempLsdsp_group2 b where  b.iHoliday=0 and b.iPreWeek=0),

	iDays_Holiday=(select count(b.shishou) from #tempLsdsp_group2 b where  b.iHoliday=1 and b.iPreWeek=0),

  iPreweek
	into #tempLsdsp_group3
	from #tempLsdsp_group2 a

  select wk,dw,lsriqi,shuliang,shishou,profits,shishiou_wk,shishiou_wk_avg,profits_wk,profits_wk_avg,
				 ringRatio_shishou,iHoliday,fHoliday_No,fHoliday,iDays_Holiday_no,iDays_Holiday,
				 NormalSale_avg=round(shishiou_wk/cast((iDays_Holiday_no+iDays_Holiday) as money),2),	
				 NormalProfits_avg=round(profits_wk/cast((iDays_Holiday_no+iDays_Holiday) as money),2),
				 fRatio_NormalSale=round(case when shishiou_wk<>0 then ((shishou-(shishiou_wk/cast((iDays_Holiday_no+iDays_Holiday) as money)))/
													 (shishiou_wk/cast((iDays_Holiday_no+iDays_Holiday) as money)))*100 else null end,3),	
				 fRatio_NormalProfits=round(case when profits_wk<>0 then ((profits-(profits_wk/cast((iDays_Holiday_no+iDays_Holiday) as money)))/
													 (profits_wk/cast((iDays_Holiday_no+iDays_Holiday) as money)))*100 else null end,3),
	
				 shishiou_wk_NoHoliday_avg=round(fHoliday_No/cast(iDays_Holiday_no as money),2),	 
				 shishiou_wk_Holiday_avg=round(fHoliday/cast(iDays_Holiday as money),2),wk_disp=wk,dw_disp=dw,lsriqi_disp=lsriqi,iPreweek
  into #tempLsdsp_group4
	from #tempLsdsp_group3
	

	select dw_firstday=min(lsriqi)
	into #tempWk_firstDay
	from #tempLsdsp_group4	
  where iPreweek=0 

  declare @dw_firstday as datetime 
	set @dw_firstday=(select top 1 dw_firstday from #tempWk_firstDay)
	--update #tempLsdsp_group4 set wk_disp=null where lsriqi_disp='''+@date1+'''

	update a set a.lsriqi_disp=b.dw_firstday
	from #tempLsdsp_group4 a
	left join  #tempWk_firstDay b
	on  a.lsriqi=b.dw_firstday
	where lsriqi<>'''+@date1+'''

--select * from #tempLsdsp_group4

  update #tempLsdsp_group4 set shishiou_wk_NoHoliday_avg=null,shishiou_wk_Holiday_avg=null,fHoliday_No=null,fHoliday=null,
				shishiou_wk=null,shishiou_wk_avg=null,profits_wk=null,profits_wk_avg=null,NormalProfits_avg=null,NormalSale_avg=null
  where lsriqi_disp is null

  select wk,dw,lsriqi,shuliang,shishou,profits,shishiou_wk,shishiou_wk_avg,profits_wk,profits_wk_avg,
				 ringRatio_shishou,iHoliday,fHoliday_No,fHoliday,iDays_Holiday_no,iDays_Holiday,
				 shishiou_wk_NoHoliday_avg,shishiou_wk_Holiday_avg,wk_disp,dw_disp,lsriqi_disp=dbo.getDayStr(lsriqi_disp),iPreweek,
				 NormalSale_avg,NormalProfits_avg,fRatio_NormalSale,fRatio_NormalProfits
  into #tempLsdsp_group5
  from #tempLsdsp_group4 
	where iPreweek=0
	union all
  select wk=null,dw=null,lsriqi=''2099-01-01'',shuliang=sum(shuliang),shishou=sum(shishou),
				 profits=sum(profits),shishiou_wk=null,shishiou_wk_avg=null,profits_wk=null,profits_wk_avg=null,
				 ringRatio_shishou=null,iHoliday=null,fHoliday_No=null,fHoliday=null,iDays_Holiday_no=null,iDays_Holiday=null,
				 shishiou_wk_NoHoliday_avg=null,shishiou_wk_Holiday_avg=null,wk_disp=null,dw_disp=null,lsriqi_disp=''本期总结'',iPreweek=null,
				 NormalSale_avg=null,NormalProfits_avg=null,fRatio_NormalSale=null,fRatio_NormalProfits=null
  from #tempLsdsp_group4 
	where iPreweek=0
  
--select * from #tempLsdsp_group5
  update #tempLsdsp_group5 
	set 
	shishiou_wk=(select shishiou_wk from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	shishiou_wk_avg=(select shishiou_wk_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	profits_wk=(select profits_wk from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	profits_wk_avg=(select profits_wk_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	fHoliday_No=(select fHoliday_No from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	fHoliday=(select fHoliday from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	iDays_Holiday_no=(select iDays_Holiday_no from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	iDays_Holiday=(select iDays_Holiday from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	shishiou_wk_NoHoliday_avg=(select shishiou_wk_NoHoliday_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	shishiou_wk_Holiday_avg=(select shishiou_wk_Holiday_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday),
  NormalProfits_avg=(select NormalProfits_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday),
	NormalSale_avg=(select NormalSale_avg from #tempLsdsp_group5 where lsriqi=@dw_firstday)
  where lsriqi_disp=''本期总结''


  update #tempLsdsp_group5 
	set 
	shishiou_wk=null,
	shishiou_wk_avg=null,
	profits_wk=null,
	profits_wk_avg=null,
	fHoliday_No=null,
	fHoliday=null,
	iDays_Holiday_no=null,
	iDays_Holiday=null,
	shishiou_wk_NoHoliday_avg=null,
	shishiou_wk_Holiday_avg=null,
  NormalSale_avg=null,
	NormalProfits_avg=null
  where lsriqi=@dw_firstday

  update #tempLsdsp_group5 
	set lsriqi_disp=dbo.getDayStr(lsriqi)
	where lsriqi_disp is null 
  
  update #tempLsdsp_group5
  set 
	ringRatio_shishou=round((select sum(abs(ringRatio_shishou))/count(ringRatio_shishou) from #tempLsdsp_group5 where ringRatio_shishou is not null ),3),
  fRatio_NormalSale=round((select sum(abs(fRatio_NormalSale))/count(fRatio_NormalSale) from #tempLsdsp_group5 where fRatio_NormalSale is not null ),3),
	fRatio_NormalProfits=round((select sum(abs(fRatio_NormalProfits))/count(fRatio_NormalProfits) from #tempLsdsp_group5 where fRatio_NormalProfits is not null ),3)  
  where lsriqi_disp=''本期总结''
  
  
  

  select * from #tempLsdsp_group5
	order by lsriqi desc,wk,dw

'  )
end


GO
