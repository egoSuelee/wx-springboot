


CREATE    procedure p_CompareByMonth
--@quno varchar(32),
--@guizuno varchar(32),
--@spno varchar(32),
@date1 datetime,
@date2 datetime,
@tempTableQu varchar(32),
@tempTableGuizu varchar(32),
@tempTableSpno varchar(32)
as
begin
	declare @Year1 varchar(4)
	declare @Month1 varchar(2)
	set @Year1=cast(datepart(yyyy,@date1) as varchar(4))
	set @Month1=cast(datepart(mm,@date1) as varchar(2))
	declare @Year2 varchar(4)
	declare @Month2 varchar(2)
	set @Year2=cast(datepart(yyyy,@date2) as varchar(4))
	set @Month2=cast(datepart(mm,@date2) as varchar(2))

	declare @YearPre varchar(4)
	declare @MonthPre varchar(2)
	set @YearPre=case when datepart(mm,@date1)=1 then cast(datepart(yyyy,@date1)-1 as varchar(4))
									 else cast(datepart(yyyy,@date1) as varchar(4)) end
	set @MonthPre=case when datepart(mm,@date1)=1 then '12' else cast(datepart(mm,@date1)-1 as varchar(2)) end

exec('
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,fCost,jingyingfangshi
  into #tempSpxx_Qu
	from dbo.v_Spxx_Qu '
	+' where quno in (select quno=cQuyuNo from '+@tempTableQu+') or '
	+'  guizuno in (select guizuno=cGuizuNo from '+@tempTableGuizu+') or '
	+'  spno in (select spno=cSpNo from '+@tempTableSpno+') '

	+'
	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,Profits=cast(0 as money),a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,b.lsriqi,
				 wk=datepart(yyyy,b.lsriqi),dw=datepart(mm,b.lsriqi),
				 iPreWeek=case when datepart(yyyy,b.lsriqi)='''+@YearPre+''' and datepart(mm,b.lsriqi)='''+@MonthPre+'''  then 1 else 0 end
	into #tempLsdsp
	from #tempSpxx_Qu a left join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsdno=c.lsdno
	where b.Lsriqi between '''+@YearPre+'-'+@MonthPre+'-'+'01'+''' and '''+ @date2+'''
				and a.spno is not null


  update a set a.fCost=b.fCostPrice*a.Shuliang
  from #tempLsdsp a ,t_SaleSheet_Day b
	where a.lsriqi=b.dDate and b.cSpNo=a.spno


  update #tempLsdsp
	set Profits=case when isnull(fCost,0)<>0 then shishou-fCost else fRatio*shishou/100.00 end

	select wk,dw,shuliang=sum(Shuliang),shishou=sum(shishou),profits=round(sum(isnull(Profits,0)),2),iPreWeek,lsriqi
	into #tempLsdsp_group0	
	from #tempLsdsp
	group by wk,dw,lsriqi,iPreWeek
--	order by wk,dw


  select a.wk,a.dw,shuliang=sum(a.Shuliang),shishou=sum(a.shishou),profits=sum(a.profits),
	shishiou_wk=(select shishiou_wk=sum(b.shishou) from #tempLsdsp_group0 b where b.wk=a.wk),
	profits_wk=(select profits_wk=sum(b.profits) from #tempLsdsp_group0 b where b.wk=a.wk),
	iDays=(select iDays=count(b.dw) from #tempLsdsp_group0 b where b.wk=a.wk),iHoliday=0,
	iMonthDays=count(a.lsriqi),
	a.iPreweek
	into #tempLsdsp_group1
	from #tempLsdsp_group0 a
	group by a.wk,a.dw,a.iPreWeek

--select iDays,iMonthDays from #tempLsdsp_group1

  select wk,dw,shuliang,shishou,profits,shishiou_wk,
				 shishiou_wk_avg=shishiou_wk/iDays,profits_wk,profits_wk_avg=profits_wk/iDays,iDays,iHoliday,iPreweek,iMonthDays
	into #tempLsdsp_group2
	from #tempLsdsp_group1



	select a.wk,a.dw,iMonthDays,a.shuliang,a.shishou,a.profits,
	a.shishiou_wk,a.shishiou_wk_avg,a.profits_wk,a.profits_wk_avg,
	ringRatio_shishou=((select a.shishou/(case when b.shishou=0 then null else b.shishou end) 
											from #tempLsdsp_group2 b where (b.wk=a.wk and b.dw=a.dw-1) or (b.wk=(a.wk-1) and a.dw=1 and b.dw=12))-1
										)*100,
	iHoliday,fHoliday_No=(select sum(b.shishou) from #tempLsdsp_group2 b where b.wk=a.wk  and b.iHoliday=0) ,
	fHoliday=(select sum(b.shishou) from #tempLsdsp_group2 b where b.wk=a.wk  and b.iHoliday=1),
	iDays_Holiday_no=(select count(b.shishou) from #tempLsdsp_group2 b where b.wk=a.wk  and b.iHoliday=0),
	iDays_Holiday=(select count(b.shishou) from #tempLsdsp_group2 b where b.wk=a.wk  and b.iHoliday=1),iPreweek
	into #tempLsdsp_group3
	from #tempLsdsp_group2 a


  select wk,dw,shuliang,shishou,profits,shishiou_wk,shishiou_wk_avg,profits_wk,profits_wk_avg,
				 ringRatio_shishou,iHoliday,fHoliday_No,fHoliday,iDays_Holiday_no,iDays_Holiday,
				 shishiou_wk_NoHoliday_avg=fHoliday_No/cast(iDays_Holiday_no as money),	 
				 shishiou_wk_Holiday_avg=fHoliday/cast(iDays_Holiday as money),wk_disp=wk,dw_disp=dw,iPreweek,
				 iMonthDays,shishou_MonthDays=shishou/cast(iMonthDays as money),profits_MonthDays=profits/cast(iMonthDays as money)
  into #tempLsdsp_group4
	from #tempLsdsp_group3
	

	select wk,dw_firstday=min(dw)
	into #tempWk_firstDay
	from #tempLsdsp_group4	 
  group by wk

	update a set a.wk_disp=b.wk
	from #tempLsdsp_group4 a
	left join  #tempWk_firstDay b
	on a.wk=b.wk and a.dw=b.dw_firstday
	


  update #tempLsdsp_group4 set shishiou_wk_NoHoliday_avg=null,shishiou_wk_Holiday_avg=null,
				shishiou_wk=null,shishiou_wk_avg=null,profits_wk=null,profits_wk_avg=null
  where wk_disp is null

  select wk=cast(wk as varchar(4)),dw,shuliang,shishou,profits,shishiou_wk,shishiou_wk_avg,profits_wk,profits_wk_avg,
				 ringRatio_shishou,iHoliday,fHoliday_No,fHoliday,iDays_Holiday_no,iDays_Holiday,
				 shishiou_wk_NoHoliday_avg,shishiou_wk_Holiday_avg,wk_disp=cast(wk_disp as varchar(4)),dw_disp,iPreweek
  from #tempLsdsp_group4 
	where iPreweek=0
	union all
  select wk=''合计'',dw=null,shuliang=sum(shuliang),shishou=sum(shishou),
				 profits=sum(profits),shishiou_wk=null,shishiou_wk_avg=null,profits_wk=null,profits_wk_avg=null,
				 ringRatio_shishou=null,iHoliday=null,fHoliday_No=null,fHoliday=null,iDays_Holiday_no=null,iDays_Holiday=null,
				 shishiou_wk_NoHoliday_avg=null,shishiou_wk_Holiday_avg=null,wk_disp=''合计'',dw_disp=null,iPreweek=null
  from #tempLsdsp_group4 
	where iPreweek=0
	order by wk desc,dw
'  )
end


GO
