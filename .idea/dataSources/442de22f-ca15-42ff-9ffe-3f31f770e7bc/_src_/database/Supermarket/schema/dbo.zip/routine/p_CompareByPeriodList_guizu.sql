




CREATE      procedure p_CompareByPeriodList_guizu
as
begin
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,jingyingfangshi,fCost,cGoodsTypeno,cGoodsTypename
  into #tempSpxx_Qu
	from dbo.v_Spxx_Qu 
	where quno in (select quno=cQuyuNo from #temp_quyu ) or 
	  guizuno in (select guizuno=cGuizuNo from #temp_guizu) or 
	  spno in (select spno=cSpNo from #temp_shangping)
/*
	select spno,Mingcheng,guizuNo,guizu,quno,qu,fRatio,jingyingfangshi,cGoodsTypeno,cGoodsTypename
	into #tempSpxx_Qu
	from v_Spxx_Qu

  select cPeriod=dbo.getDayStr(dDate1 )+'至'+dbo.getDayStr(dDate2),dDate1,dDate2,
		shuliang=null,shishou=null,profits=null 
	from #tempPeriodList
*/	
	declare @cBaseNo varchar(32)
	declare @minDate datetime
	declare @maxDate datetime
	set @minDate=(select min(dDate1) from #tempPeriodList)
	set @maxDate=(select max(dDate2) from #tempPeriodList)
	set @cBaseNo=(select top 1 cPeriodNo from #tempPeriodList where bBaseCompare=1)
	if @cBaseNo is null
	begin
		set @cBaseNo=(select top 1 cPeriodBelongNo from #tempPeriodList)--如果没有指定基准时段，则默认分析时段
 	end

	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,Profits=cast(0 as money),a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,b.lsriqi,b.Pnumber
	into #tempLsdsp
	from #tempSpxx_Qu a left join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsdno=c.lsdno
	where b.Lsriqi between @minDate and @maxDate
				and a.spno is not null

--  select spno,danwei,shuliang=sum(shuliang),

  select cPeriodRegion=dbo.getDayStr(dDate1 )+'至'+dbo.getDayStr(dDate2),
				 cPeriodNo,cPeriodName,dDate1,dDate2,cPeriodBelongNo,bBaseCompare
	into #tempPeriodList0
	from #tempPeriodList

  select a.cPeriodNo,b.spno,b.shuliang,b.danjia,b.shishou,b.yingshou,b.chongjian,b.zhekoulv,b.fCost,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,b.shoukuanyuanno,b.shoukuanyuan,b.lsriqi,b.lsdno,b.Pnumber
  into #tempPeriodList1
	from #tempPeriodList0 a 
	left join #tempLsdsp b on b.lsriqi between a.dDate1 and a.dDate2
	where b.spno is not null

	select distinct b.spno,b.shuliang,b.danjia,b.shishou,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,b.shoukuanyuanno,b.shoukuanyuan,b.lsriqi,b.lsdno,b.Pnumber
  into #tempPeriodList_distinct
	from #tempPeriodList1 b

  select cPeriodNo,spno,shuliang=sum(shuliang),shishou=sum(shishou)
  into #tempGroup0
  from #tempPeriodList1
	group by cPeriodNo,spno
/*
  union all 
	select cPeriodNo='时段合计',spno=null,shuliang=sum(shuliang),shishou=sum(shishou)
	from #tempPeriodList_distinct
*/
	  
 	select a.cPeriodNo,c.cPeriodRegion,cPeriodDetail=c.cPeriodName,a.spno,a.shuliang,a.shishou,
			   b.Mingcheng,b.guizuNo,b.guizu,b.quno,b.qu,b.fRatio,b.jingyingfangshi,b.cGoodsTypeno,b.cGoodsTypename,
				 fCost=b.fCost*a.shuliang,
				 fConsultMoney=(select sum(shishou) from #tempGroup0 where cPeriodNo=@cBaseNo and spno=a.spno),
				 fConsultQty=(select sum(shuliang) from #tempGroup0 where cPeriodNo=@cBaseNo and spno=a.spno),
				 fPeriodMoney=(select sum(shishou) from #tempPeriodList_distinct where spno=a.spno),
				 fPeriodQty=(select sum(shuliang) from #tempPeriodList_distinct where spno=a.spno),
				 profits=null,
				 fConsultMoneyRatio=null,fPeriodMoneyRatio=null,
				 fConsultQtyRatio=null,fPeriodQtyRatio=null,
				 iFlag= case when a.cPeriodNo=@cBaseNo 
										 then 1 
										 else 0 
								end 	
/*
				 iFlag= case when
										 (select cPeriodNo from #tempGroup0 where cPeriodNo=a.cPeriodNo and cPeriodNo=@cBaseNo) then 1 
										 else 0 
								end 	
*/         
  into #tempGroup1	
	from #tempGroup0 a left join #tempSpxx_Qu b on a.spno=b.spno
	left join #tempPeriodList0 c on a.cPeriodNo=c.cPeriodNo
	
  update #tempGroup1	
	set 
	profits=case when isnull(fCost,0)<>0 then shishou-fCost else fRatio*shishou/100.00 end,
	fConsultMoneyRatio=round(shishou/case when fConsultMoney=0 then null else cast(fConsultMoney as money) end,4)*100,
	fPeriodMoneyRatio=round(shishou/case when fPeriodMoney=0 then null else cast(fPeriodMoney as money) end,4)*100,
	fConsultQtyRatio=round(shuliang/case when fConsultQty=0 then null else cast(fConsultQty as money) end,4)*100,
	fPeriodQtyRatio=round(shuliang/case when fPeriodQty=0 then null else cast(fPeriodQty as money) end,4)*100

/*
  select cPeriodNo,spno into #t1 from #tempGroup1 where spno not in (select spno from #tempGroup1 where iFlag=1)
  select spno,cPeriodNo=min(cPeriodNo) into #t2 from #t1 group by spno

  update a set a.iFlag=1
	from #tempGroup1 a 
	left join #t2 b
	on a.spno=b.spno and a.cPeriodNo=b.cPeriodNo
	where b.cPeriodNo is not null
*/
/*
  select cPeriodNo,cPeriodRegion,cPeriodDetail,spno,shuliang,shishou,
			   Mingcheng,guizuNo,guizu,quno,qu,fRatio,jingyingfangshi,cGoodsTypeno,cGoodsTypename,
				 fConsultMoney,fConsultQty,fPeriodMoney,fPeriodQty,profits,fConsultMoneyRatio,fPeriodMoneyRatio,
				 fConsultQtyRatio,fPeriodQtyRatio,iFlag
	from #tempGroup1
	order by spno,iFlag desc,cPeriodNo
*/
	select guizuno,guizu,cPeriodNo,cPeriodRegion,cPeriodDetail,iFlag,shuliang=sum(shuliang),shishou=sum(shishou),profits=sum(profits),
	fConsultMoney=sum(fConsultMoney),fPeriodMoney=sum(fPeriodMoney),fConsultQty=sum(fConsultQty),fPeriodQty=sum(fPeriodQty),
  fConsultMoneyRatio=null,fPeriodMoneyRatio=null,fConsultQtyRatio=null,fPeriodQtyRatio=null
  into #tempGroupByGuizu	
	from #tempGroup1
	group by guizuno,guizu,cPeriodNo,cPeriodRegion,cPeriodDetail,iFlag

  update #tempGroupByGuizu	
	set 
	fConsultMoneyRatio=round(shishou/case when fConsultMoney=0 then null else cast(fConsultMoney as money) end,4)*100,
	fPeriodMoneyRatio=round(shishou/case when fPeriodMoney=0 then null else cast(fPeriodMoney as money) end,4)*100,
	fConsultQtyRatio=round(shuliang/case when fConsultQty=0 then null else cast(fConsultQty as money) end,4)*100,
	fPeriodQtyRatio=round(shuliang/case when fPeriodQty=0 then null else cast(fPeriodQty as money) end,4)*100

  select * from #tempGroupByGuizu
	order by guizuno,iFlag desc,cPeriodNo
end


GO
