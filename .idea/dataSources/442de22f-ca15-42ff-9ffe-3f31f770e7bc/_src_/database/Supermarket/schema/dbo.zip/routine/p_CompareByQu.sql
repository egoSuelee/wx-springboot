










CREATE     procedure p_CompareByQu
--@quno varchar(32),
--@guizuno varchar(32),
--@spno varchar(32),
@date1 datetime,
@date2 datetime,
@tempTableQu varchar(32)
as
begin
exec('
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,fCost,jingyingfangshi
  into #tempSpxx_Qu
	from dbo.v_Spxx_Qu '
	+' where quno in (select quno=cQuyuNo from '+@tempTableQu+') '

	+'
	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,Profits=cast(0 as money),a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,b.lsriqi
	into #tempLsdsp
	from #tempSpxx_Qu a left join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsdno=c.lsdno
	where b.Lsriqi between '''+@date1+''' and '''+ @date2+'''
				and a.spno is not null


	select quno,qu,shuliang=sum(Shuliang),shishou=sum(shishou),profits=sum(case when isnull(fCost,0)<>0 then (shishou-fCost) else fRatio*shishou/100.00 end)
	into #tempLsdsp_group0	
	from #tempLsdsp
	group by quno,qu

  select quno,qu,shuliang,shishou,profits
	from #tempLsdsp_group0
	union
	select quno=''合计'',qu=null,shuliang=sum(shuliang),shishou=sum(shishou),profits=sum(profits)
	from #tempLsdsp_group0
	order by shishou


'  )
end


GO
