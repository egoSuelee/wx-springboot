

create  procedure p_CreateTableOfWeek
@cYear char(4)
as
begin
		declare @date1 datetime
		declare @date2 datetime
		declare @i int
		declare @iDays int
		set @date1=@cYear+'-01-01'
		set @date2=@cYear+'-12-31'
		set @i=1
		select @iDays=datediff(day,@date1,@date2)+1
		while @i<=@iDays
		begin
			if not exists(select cYear from dbo.t_WeekOfYear 
					where cYear=@cYear and iWeekNo=dbo.f_GetWeeks(@date1)
				 )
			begin
				insert into dbo.t_WeekOfYear(cYear,iWeekNo,cWeekName1,cWeekName2,dDate1,dDate2)
				values(@cYear,dbo.f_GetWeeks(@date1),DATENAME(dw,@date1),DATENAME(dw,@date1),@date1,@date1)

			end else
			begin
				update dbo.t_WeekOfYear set dDate2=@date1,cWeekName2=DATENAME(dw,@date1)
				where cYear=@cYear and iWeekNo=dbo.f_GetWeeks(@date1)

			end
/*
		  print dbo.f_GetWeeks(@date1)
		  print dbo.f_GetDayOfWeek(@date1)
*/
		  set @date1=dateadd(day,1,@date1) 
			set @i=@i+1
		end
  	update dbo.t_WeekOfYear set iDays=datediff(day,dDate1,dDate2)+1

end

/*

p_CreateTableOfWeek '2006'
*/


GO
