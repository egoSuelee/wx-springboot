



CREATE          procedure [dbo].[p_CulGuizuProfitsByCondition]
--@quno varchar(32),
--@guizuno varchar(32),
--@spno varchar(32),
@date1 datetime,
@date2 datetime,
@tempTableQu varchar(32),
@tempTableGuizu varchar(32),
@tempTableSpno varchar(32)
as
begin
exec('
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,fCost,jingyingfangshi
  into #tempSpxx_Qu
	from dbo.v_Spxx_Qu where '
/*
	+' quno in (select quno=cQuyuNo from '+@tempTableQu+') or '
	+'  guizuno in (select guizuno=cGuizuNo from '+@tempTableGuizu+') or '
*/
	+'  spno in (select spno=cSpNo from '+@tempTableSpno+') '

	+'
	select d.pinpai,a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,fProfits=cast(0 as money)
				 ,a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,
				 b.lstime,b.lsriqi
	into #tempLsdsp
	from #tempSpxx_Qu a right join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsriqi=c.zdriqi and b.lsdno=c.lsdno
	left join spxx d on a.spno=d.spno

	where b.Lsriqi between '''+@date1+''' and '''+ @date2+''' and
	      c.zdriqi  between '''+@date1+''' and '''+ @date2+''' and a.spno is not null

  update #tempLsdsp
	set fProfits=case when isnull(fCost,0)<>0 then shishou-fCost else fRatio*shishou/100.00 end

  select pinpai,quno,qu,guizuno,guizu,lsdno,spno,Mingcheng,Shuliang,Danjia,shishou,fRatio,
	fProfits,lstime,lsriqi,
				 shoukuanyuanno,shoukuanyuan,daogouyuanno,daogouyuan	 
	--into #tempLsdsp_last
	from #tempLsdsp
	union all
  select pinpai,quno,qu,guizuno,guizu,lsdno=null,spno=''品牌小计'',Mingcheng=null,Shuliang=sum(shuliang),
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null	 
	from #tempLsdsp
	group by quno,qu,guizuno,guizu,pinpai	
	union all
  select pinpai=null,quno,qu,guizuno,guizu,lsdno=null,spno=''小计'',Mingcheng=null,Shuliang=sum(shuliang),
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null	 
	from #tempLsdsp
	group by quno,qu,guizuno,guizu	
	union all
  select pinpai=null,quno,qu,guizuno=''合计'',guizu=null,lsdno=null,spno=null,Mingcheng=null,Shuliang=sum(shuliang),
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null	 
	from #tempLsdsp
	group by quno,qu	
	union all
  select pinpai=null,quno=''总计'',qu=null,guizuno=null,guizu=null,lsdno=null,spno=null,Mingcheng=null,Shuliang=sum(shuliang),
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null	 
	from #tempLsdsp
  order by quno,guizuno,spno,pinpai,lstime

'  )
end


GO
