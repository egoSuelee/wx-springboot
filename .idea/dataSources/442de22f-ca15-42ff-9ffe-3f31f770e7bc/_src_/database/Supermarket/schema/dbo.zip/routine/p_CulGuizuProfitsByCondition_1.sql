CREATE        procedure p_CulGuizuProfitsByCondition_1   
@date1 datetime,     
@date2 datetime,      
@tempTableQu varchar(32),  
@tempTableGuizu varchar(32), 
@tempTableSpno varchar(32) 
as    
begin   --2007-07-2999 
exec('               
	select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,fCost,jingyingfangshi  
  into #tempSpxx_Qu  
	from dbo.v_Spxx_Qu '
	+' where  guizuno in (select guizuno=cGuizuNo from '+@tempTableGuizu+') ' 
	+'    
	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,fCost=a.fCost*b.shuliang,fProfits=cast(0 as money) 
				 ,a.jingyingfangshi,       
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,
				 b.lstime,b.lsriqi       
	into #tempLsdsp                
	from #tempSpxx_Qu a right join dbo.lsdsp b on a.spno=b.spno  
	left join lsd c on b.lsdno=c.lsdno       
	where b.Lsriqi between '''+@date1+''' and '''+ @date2+''' 
				and a.spno is not null      
  select a.dDate,spno=b.spno,a.fCostPrice,a.fRatio
	into #tempSalesheet_day   
	from t_salesheet_day a right join spxx b
	on b.belong=a.cSpno      
	where a.dDate>='''+@date1+''' and a.dDate<='''+ @date2+'''
	update a set a.fCost=b.fCostPrice*a.shuliang,a.fRatio=b.fRatio 
	from #tempLsdsp a,#tempSalesheet_day b 
	where a.lsriqi=b.dDate and a.Spno=b.Spno 
  update #tempLsdsp 
	set fProfits=case when isnull(fCost,0)<>0 then shishou-fCost else fRatio*shishou/100.00 end 
  select quno,qu,guizuno,guizu,lsdno,spno,Mingcheng,Shuliang,Danjia,shishou,fRatio,
	fProfits,lstime,lsriqi,
				 shoukuanyuanno,shoukuanyuan,daogouyuanno,daogouyuan,fCost=isnull(shishou,0)-isnull(fProfits,0) 
--	into #tempLsdsp_last  
	from #tempLsdsp  
	union all 
  select quno,qu,guizuno,guizu,lsdno=null,spno=''小计'',Mingcheng=null,Shuliang=sum(shuliang), 
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null    
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null,fCost=sum(isnull(shishou,0)-isnull(fProfits,0))
	from #tempLsdsp   
	group by quno,qu,guizuno,guizu
	union all   
  select quno,qu,guizuno=''合计'',guizu=null,lsdno=null,spno=null,Mingcheng=null,Shuliang=sum(shuliang), 
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null,fCost=sum(isnull(shishou,0)-isnull(fProfits,0)) 
	from #tempLsdsp 
	group by quno,qu  
	union all 
  select quno=''总计'',qu=null,guizuno=null,guizu=null,lsdno=null,spno=null,Mingcheng=null,Shuliang=sum(shuliang),
				 Danjia=null,shishou=sum(shishou),fRatio=null,fProfits=sum(fProfits),lstime=null,lsriqi=null 
				 ,shoukuanyuanno=null,shoukuanyuan=null,daogouyuanno=null,daogouyuan=null,fCost=sum(isnull(shishou,0)-isnull(fProfits,0))
	from #tempLsdsp     
  order by quno,guizuno,spno,lstime   
'  )
end
GO
