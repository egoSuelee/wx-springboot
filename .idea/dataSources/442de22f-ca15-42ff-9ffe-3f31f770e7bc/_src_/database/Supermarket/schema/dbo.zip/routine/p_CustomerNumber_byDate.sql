

create  procedure [dbo].[p_CustomerNumber_byDate]
@datetime1 datetime,
@datetime2 datetime,
@orderbyField varchar(64)
as
begin
--	select sheetno,detail,shishou,jstime,zdriqi
	select sheetno,shishou=1,jstime,zdriqi
  into #jiesuan_temp
  from dbo.jiesuan 
	where zdriqi between @datetime1 and @datetime2
	group by sheetno,jstime,zdriqi 
	union all
	select sheetno,shishou=1,jstime,zdriqi='1900-01-01'
  from dbo.jiesuan 
	where zdriqi between @datetime1 and @datetime2
	group by sheetno,jstime
		
	declare @iSheetCount int
	declare @fSheetMoneyCount Money
	set @iSheetCount=1
	set @fSheetMoneyCount=isnull((select sum(isnull(shishou,0)) from #jiesuan_temp),0)

	select lsdno=a.sheetno,shishou=a.shishou,zdriqi=a.zdriqi,PosID=dbo.getDayStr(a.zdriqi),
				 Hourpart=datepart(hh,a.jstime) 
	into #lsd_temp 
	from #jiesuan_temp a 
	where a.zdriqi between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)
	union all
	select lsdno=a.sheetno,shishou=a.shishou,zdriqi=a.zdriqi,PosID=dbo.getDayStr(a.zdriqi),
				 Hourpart=datepart(hh,a.jstime) 
	from #jiesuan_temp a 
	where a.zdriqi ='1900-01-01'	


	select a.PosID,PosSales=round(isnull((select sum(isnull(shishou,0)) from #lsd_temp where PosID=a.PosID),0),2),
				 a.Hourpart,HourPartSales=sum(isnull(a.shishou,0))
	into #lsd_temp_1
	from #lsd_temp a  
	group by a.PosID,a.Hourpart


--select * from #lsd_temp_1 order by PosID,Hourpart

	create table #CubeList
	(
		PosID varchar(32),PosSales money,TotalSales money,H0 money,H1 money,H2 money,H3 money,H4 money,H5 money,H6 money,
		H7 money,H8 money,H9 money,H10 money,H11 money,H12 money,H13 money,H14 money,H15 money,H16 money,
		H17 money,H18 money,H19 money,H20 money,H21 money,H22 money,H23 money
	) 
  declare @PosID varchar(32) 
  declare @PosSales Money
	declare @HourPart int
	declare @HourPartSales money

	declare crCubeList cursor
	for
	select PosID,PosSales,Hourpart,HourPartSales from #lsd_temp_1 
	order by PosID,Hourpart



  open crCubeList
	fetch next from crCubeList
	into @PosID,@PosSales,@Hourpart,@HourPartSales

	declare @strtmpPosID varchar(32)
	declare @strtmpPosSales varchar(32)
	declare @strtmpHourpart varchar(2)
	declare @strtmpHourPartSales varchar(32)

--select * from #lsd_temp_1
   
	while @@fetch_status=0 
	begin
		if (select count(PosID) from #CubeList where PosID=@PosID)=0
		begin
			insert into #CubeList (PosID,PosSales) values (@PosID,@PosSales)
		end

		  set @strtmpHourpart=dbo.trim(cast(@Hourpart as varchar(2)))
		  set @strtmpPosID=@PosID
		  set @strtmpPosSales=cast(@PosSales as varchar(32))
		  set @strtmpHourPartSales=cast(@HourPartSales as varchar(32))

     -- select @PosID,@strtmpHourpart,@strtmpHourPartSales

    	exec('update #CubeList set H'+@strtmpHourpart+'='+@strtmpHourPartSales+'
              where PosID='''+@PosID+'''

					')
		fetch next from crCubeList
		into @PosID,@PosSales,@Hourpart,@HourPartSales
	end
 -- update #CubeList set TotalSales=(select sum(PosSales) from #CubeList)
  close crCubeList
  DEALLOCATE crCubeList

  exec(' select PosID=case PosID when ''1900-01-01'' then ''合计'' else PosID end  ,PosSales,TotalSales,H0,H1,H2,H3,H4,H5,H6,
		H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,
		H17,H18,H19,H20,H21,H22,H23 from  #CubeList order by '+@orderbyField)



end


GO
