






CREATE        procedure p_FIFO
@cangkuno varchar(32),
@date datetime

as
begin
/*
  select spno,mingcheng,tiaoma,belong,danwei,guige,shangxian,xiaxian
	into #tempSpxx
	from spxx
	where cast(isnull(Selected,'0') as int)=1  /*查询出管理库存的商品信息*/
*/

  create Table #tempResult
	(iLineNo int,DateTitle_disp datetime,DateTitle datetime,cSheetNo varchar(32),cGoodsNo varchar(32),iSerno int,
	cSummary varchar(64),fPrice_In money,fQty_In money,fMoney_In money,fPrice_Out money,fQty_Out money,
	fMoney_Out money,fQty_Left money,fPrice_Left money,fMoney_Left money,dDate datetime,dDateTime datetime,fMoney_Out_total_sale money
	)


  declare cur_spxx cursor
  for
	select spno=cSpNo
	from #temp_shangping  

	declare @spno varchar(32)

  open cur_spxx
  fetch next from cur_spxx
  into @spno

	while @@Fetch_status=0
	begin
    
    insert into #tempResult
    (iLineNo ,DateTitle_disp ,DateTitle ,cSheetNo ,cGoodsNo ,iSerno ,
		cSummary ,fPrice_In ,fQty_In ,fMoney_In ,fPrice_Out ,fQty_Out ,
		fMoney_Out ,fQty_Left ,fPrice_Left ,fMoney_Left ,dDate ,dDateTime,fMoney_Out_total_sale )
    exec dbo.p_Fifo_test @spno,@cangkuno,@date

	  fetch next from cur_spxx
	  into @spno

	end
	

	close cur_spxx
  deallocate cur_spxx

  select a.iLineNo ,a.DateTitle_disp ,a.DateTitle ,a.cSheetNo ,a.cGoodsNo ,b.mingcheng,a.iSerno ,
		a.cSummary ,a.fPrice_In ,a.fQty_In ,a.fMoney_In ,a.fPrice_Out ,a.fQty_Out ,
		a.fMoney_Out ,a.fQty_Left ,a.fPrice_Left ,a.fMoney_Left ,a.dDate ,dDateTime=dbo.gettimestr(a.dDateTime),a.fMoney_Out_total_sale
  into #tempResul_last
	from #tempResult a,spxx b
  where a.cGoodsNo=b.spno
--	order by a.cGoodsNo,a.iLineNo

  select iLineNo ,DateTitle_disp ,DateTitle ,cSheetNo ,cGoodsNo ,mingcheng,iSerno ,
		cSummary ,fPrice_In ,fQty_In ,fMoney_In ,fPrice_Out ,fQty_Out ,
		fMoney_Out ,fQty_Left ,fPrice_Left ,fMoney_Left ,dDate ,dDateTime,fMoney_Out_total_sale

	from #tempResul_last

  union all
  select iLineNo='999999999',DateTitle_disp=@date ,DateTitle=@date,cSheetNo=null,cGoodsNo='总计',mingcheng=null,iSerno=null,
		cSummary='' ,fPrice_In=null ,fQty_In=sum(isnull(fQty_In,0)) ,fMoney_In=sum(fMoney_In) ,fPrice_Out=null,fQty_Out=sum(fQty_Out),
		fMoney_Out=sum(fMoney_Out),fQty_Left=sum(isnull(fQty_Left,0)) ,fPrice_Left=null,fMoney_Left=sum(fMoney_Left) ,dDate=null,dDateTime=null,fMoney_Out_total_sale=sum(fMoney_Out_total_sale)
	from #tempResul_last
  where iLineNo='888888888'
	order by cGoodsNo,iLineNo
end


GO
