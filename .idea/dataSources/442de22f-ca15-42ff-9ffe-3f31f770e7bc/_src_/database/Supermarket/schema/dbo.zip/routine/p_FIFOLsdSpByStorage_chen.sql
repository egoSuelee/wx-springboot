/*
取得某天销售情况（无安装配送、管理库存的商品）
p_FIFOLsdSpByStorage_chen '2010-05-25'
select * from #tmpFIFOLsdsp
*/
CREATE proc p_FIFOLsdSpByStorage_chen
@dDate datetime
as
set xact_abort on
if (select object_id('tempdb..#tmpFIFOLsdsp'))is not null
drop table #tmpFIFOLsdsp
if (select object_id('tempdb..##tmpFIFOLsSpStorage'))is not null
drop table ##tmpFIFOLsSpStorage
if (select object_id('tempdb..#tmpFIFOLsSpStorageLast'))is not null
drop table #tmpFIFOLsSpStorageLast
if (select object_id('tempdb..##ToDelphiLsSpStorage'))is not null
drop table ##ToDelphiLsSpStorage

select a.Lsriqi,a.LsdNo,a.Pnumber,a.Spno,a.Shuliang,a.danjia,a.Jine,a.Cangkuno,b.iPayoff,
bAccount=isnull(a.bAccount,0)
into #tmpFIFOLsdsp
from lsdsp a left join 
(
  select distinct zdriqi,sheetno=sheetno+'-'+guizuno,guizuno,iPayoff=isnull(iPayoff,0)
  from jiesuan_byguizu
  where zdriqi=@dDate and isnull(bCancel,0)<>1 and isnull(iPayoff,0)=0
)b
on a.Lsriqi=b.zdriqi and a.LsdNo=b.sheetno and a.guizuno=b.guizuno
where a.Lsriqi=@dDate and isnull(a.bCancel,0)<>1
and isnull(a.bAccount,0)<>1 and b.iPayoff=0

select a.Lsriqi,a.LsdNo,a.Pnumber,a.Spno,a.Shuliang,a.danjia,a.Jine,a.Cangkuno,a.iPayoff,
a.bAccount
into ##tmpFIFOLsSpStorage
from #tmpFIFOLsdsp a,spxx b
where a.spno=b.spno and isnull(b.Selected,0)=1

select Lsriqi,typeNo='销售',pnumber=0,spno,shuliang=sum(isnull(shuliang,0)),
jine=sum(isnull(jine,0)),cangkuno,iPayoff,price=case when sum(isnull(shuliang,0))<>0 then sum(isnull(jine,0))/sum(isnull(shuliang,0))
                                                          else 0 end
into #tmpFIFOLsSpStorageLast
from ##tmpFIFOLsSpStorage
group by Lsriqi,spno,cangkuno,iPayoff

select a.Lsriqi,a.typeNo,a.spno,b.mingcheng,a.jine,a.cangkuno,b.danwei,b.guige,b.dw1,
a.shuliang,a.price
into ##ToDelphiLsSpStorage
from #tmpFIFOLsSpStorageLast a left join spxx b
on a.spno=b.spno and b.danwei is not null

select Lsriqi,spno,mingcheng,shuliang,jine,cangkuno,danwei,guige,price
from ##ToDelphiLsSpStorage

GO
