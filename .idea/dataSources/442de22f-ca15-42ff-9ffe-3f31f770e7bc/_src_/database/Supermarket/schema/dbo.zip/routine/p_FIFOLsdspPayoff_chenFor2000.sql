/*
   所有未记账的挂账单据,进行补充或强行记账
   

  p_FIFOLsdspPayoff_chenFor2000 '2009-12-12'
*/

CREATE proc p_FIFOLsdspPayoff_chenFor2000
@dDate datetime
as
--所有未记账的挂账单据
if (select object_id('tempdb..#tmpFIFOLsdsp_Payoff'))is not null
drop table #tmpFIFOLsdsp_Payoff
if (select object_id('tempdb..##ToDelphiLsdSp_Payoff'))is not null
drop table ##ToDelphiLsdSp_Payoff

select a.Lsriqi,a.LsdNo,a.Pnumber,a.Spno,a.Shuliang,a.danjia,a.Jine,a.Cangkuno,b.iPayoff,
bAccount=isnull(a.bAccount,0),a.SheetNO_Install,a.SheetNo_Deliver
into #tmpFIFOLsdsp_Payoff
from lsdsp a left join 
(
  select distinct zdriqi,sheetno=sheetno+'-'+guizuno,guizuno,iPayoff=isnull(iPayoff,0)
  from jiesuan_byguizu
  where zdriqi<=@dDate and isnull(bCancel,0)<>1 
)b
on a.Lsriqi=b.zdriqi and a.LsdNo=b.sheetno and a.guizuno=b.guizuno
where a.Lsriqi<=@dDate and isnull(a.bCancel,0)<>1
and isnull(a.bAccount,0)<>1 
and isnull(a.SheetNO_Install,'')='' and isnull(a.SheetNo_Deliver,'')=''


select id=identity(int,1,1),a.bAccount,a.Lsriqi,a.LsdNo,a.Pnumber,a.Spno,b.mingcheng,b.dw1,a.Shuliang,a.danjia,a.jine,
a.CangKuNo,a.iPayoff,a.SheetNo_Install,a.SheetNo_Deliver,b.guizuno,b.guizu
into ##ToDelphiLsdSp_Payoff
from #tmpFIFOLsdsp_Payoff a left join spxx b
on a.spno=b.spno and b.danwei is not null
where isnull(b.Selected,0)=1
order by Lsriqi,LsdNo,Pnumber

select id,bAccount,Lsriqi,LsdNo,Pnumber,Spno,mingcheng,dw1,Shuliang,danjia,jine,
CangKuNo,iPayoff,SheetNo_Install,SheetNo_Deliver,guizuno,guizu
from ##ToDelphiLsdSp_Payoff
order by Lsriqi,LsdNo,Pnumber
GO
