/*
系统初始化
declare @i int
 exec p_FIFOPdBGIN_PermitNegativeStock_chen 'IN20099044-000004',@i output
select @i
select * from dbo.wh_InWarehouseDetail
select * from t_wh_form
*/

create proc p_FIFOSysInit_chen
@cSheetNo varchar(32),
@return int output,
@bPermitNegativeStock int  --(0:不允许负库存 1：允许负库存)
as

set xact_abort on

set @return=-1
begin tran

if (select object_id('tempdb..#tmpInWareHouse'))is not null
drop table #tmpInWareHouse
if (select object_id('tempdb..#tmpNegativeStock'))is not null
drop table #tmpNegativeStock
--盘点溢出

select cSheetNo=a.pdBaoGaoNo,dDate=cast(Right(a.pdBaoGaoNo,len('2009-01-01')) as datetime),
cGoodsNo=a.spno,cGoodsName=a.mingcheng,fInPrice=a.bzjj,fQuantity=isnull(a.pdsl,0),fInMoney=a.pdjine,
cSupplierNo=b.guizuno,cSupplier=b.guizu,cWhNo=a.cangkuno,iLineNo=0,
fQty_tmpIn=cast(0 as money)
into #tmpInWareHouse
from t_pandianbaogao a left join spxx b
on a.spno=b.spno and isnull(b.Selected,0)=1 and b.danwei is not null
where a.pdBaoGaoNo=@cSheetNo
and isnull(a.pdsl,0)>0 and isnull(a.bAccount,0)=0

--商品负库存情况
select distinct a.cGoodsNo,a.iSerNo,a.cWhNo,fQtyLeft=a.fQty_Out-a.fQty_in
into #tmpNegativeStock
from t_wh_form a,#tmpInWareHouse b
where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo
and a.fQty_Out-a.fQty_in>0

declare  NegativeInWh cursor
for
select distinct cGoodsNo,iSerNo,cWhNo,fQtyLeft
from #tmpNegativeStock
order by iserNo


open NegativeInWh

declare @CurGoodsNo varchar(32)
declare @CurSerno money
declare @CurWhNo varchar(32)
declare @CurFqty money
select @CurGoodsNo='',@CurSerno=0,@CurWhNo='',@CurFqty=0
fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty
--select @CurGoodsNo+'  '+cast(@CurSerno as varchar(10))+'   '+cast(@CurFqty as varchar(10))
while @@fetch_status=0
begin
	declare @spare float --剩余库存 
	select @spare=sum(fQuantity)
	from #tmpInWareHouse 
	where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	group by cGoodsNo

    set @spare=isnull(@spare,0)

   if(@spare>=@CurFqty) 
   begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
		update a 
		set a.fQty_tmpIn= 
		case when 
			( select @CurFqty-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo and iLineNo <=a.iLineNo and cWhNo=@CurWhNo
			)>=0 
		then a.fQuantity
		else 
			case when 
				(select @CurFqty-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo and cWhNo=@CurWhNo
				)<0 then 0 
			else 
			   (select @CurFqty-isnull(sum(fQuantity),0)
				from #tmpInWareHouse 
				where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo  and cWhNo=@CurWhNo
               ) 
			end 
        end
		from #tmpInWareHouse a 
		where a.cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
    end else
    begin
	   --负库存 
	  declare @MaxRow int
	  declare @tmpLeafSum money
	  select @MaxRow=max(iLineNo) from #tmpInWareHouse where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	 -- select @tmpLeafSum=fQuantity from #tmpInWareHouse where cGoodsNo=@cGoodsNo and cWhNo=@CurWhNo and iSerNo=@MaxRow
	 -- if @tmpLeafSum>=0 
	 -- begin
          update a
		  set a.fQty_tmpIn=@CurFqty-(
                                      select isnull(sum(fQuantity),0) 
                                      from #tmpInWareHouse 
                                      where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
                                     )
		  from #tmpInWareHouse a
		  where a.cGoodsNo=@CurGoodsNo and iLineNo=@MaxRow and cWhNo=@CurWhNo

		  update #tmpInWareHouse
		  set fQty_tmpIn=fQuantity  
		  where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
	 -- end else
	 -- begin
	--	 update #tmpWhForm
	--	 set fQty_Out=fQty_Out+@QtyOut
	--	 where cGoodsNo=@cGoodsNo and iSerNo=@MaxRow and cWhNo=@CurWhNo
	--  end
   end
   fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty
end

close NegativeInWh
deallocate NegativeInWh

update a
set a.fQty_Out=a.fQty_in,fMoney_Out=a.fMoney_in,a.fPrice_out=a.fPrice_in,
    a.fQty_left=0,a.fPrice_left=a.fPrice_in,a.fMoney_left=0
from t_wh_form a,#tmpNegativeStock b
where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo and a.cWhNo=b.cWhNo

insert into t_wh_form
(
  cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cSummary,fPrice_in,fQty_in,fMoney_in,
  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
  cSupplierNo,cSupplier,iserNo
)
select cGoodsNo,dDate,cSheetNo,iLineNo,16,'系统初始化',fInPrice,fQuantity,fInMoney,
fPrice_out=fInPrice,fQty_out=fQty_tmpIn,fMOney_out=fQty_tmpIn*fInPrice,
fInPrice,fQty_left=fQuantity-fQty_tmpIn,fMoney_left=(fQuantity-fQty_tmpIn)*fInPrice,
cWhNo,cSupplierNO,cSupplier,0
from #tmpInWareHouse 

update t_wh_form
set iSerNo=iMyIdentity
where iAttribute=16 and cSheetNo=@cSheetNo and isnull(iSerNo,0)=0

if @bPermitNegativeStock=1
begin
            
            --声明一刚插入成本表中行的游标
            declare  CurCostTable cursor
            for
            select cGoodsNo,iSerNo,fPrice_In,cWhNo,fQty_In,iAttribute
            from t_wh_form
            where iAttribute=16 and cSheetNo=@cSheetNo and fQty_in>0 and fQty_out>0
            order by iserNo
            
            open CurCostTable
            
            declare @cGoodsNo varchar(32)
            declare @iLineNo int
            declare @fPrice_In Money
            declare @fQty_In_Orient money
            declare @iSerno_Orient bigint
            declare @cWhNo varchar(32)
            declare @iAttribute_orient int
            
            declare @id bigint
            declare @fQty_Cost money
            declare @fQty_Pre money
            declare @iAttribute int
            declare @dDate_Sheet datetime
            declare @iLineNo_Orient bigint
            
            declare @fQty_leiji money
            declare @fQty_left money
            
            fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
            while @@fetch_status=0 
            begin
                
            
            /*
            	set @fQty_In_Orient=(select top 1 fQty_in from #t_wh_form where cSheetno=@cSheetno and cGoodsNo=@cGoodsNo and iLineno=@iLineNo)
            	set @iSerno_Orient=(select  top 1 iSerno from #t_wh_form where cSheetno=@cSheetno and cGoodsNo=@cGoodsNo and iLineno=@iLineNo)
            	set @fPrice_In=(select  top 1 fPrice_In from #t_wh_form where cSheetno=@cSheetno and cGoodsNo=@cGoodsNo and iLineno=@iLineNo)
            */
            	--以下解决负库存的成本分配问题
            	if (select object_id('tempdb..#temp_Record_Preview'))is not null
            	drop table #temp_Record_Preview
            	if (select object_id('tempdb..#temp_Record_null'))is not null
            	drop table #temp_Record_null
            
            	select id,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo
            	into #temp_Record_Preview--需要处理的不合法成本分配记录
            	from t_cost_distribute
            	where isnull(bDone,0)=0 and fQty<fQty_Cost and cWhNo=@cWhNo and cGoodsNo=@cGoodsNo
            
            	select id=cast(null as bigint),bDone_set=cast(0 as bit),dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo
            	into #temp_Record_null--存放已处理完毕待插入成本分配表的  原来不合法成本分配记录
            	from t_cost_distribute
            	where 1<>1
            
            	set @fQty_leiji=0
            	set @fQty_left=@fQty_In_Orient
            
            	declare  Cur_Record_Preview cursor
            	for
            	select id,fQty_Cost,fQty_Pre=fQty,iAttribute,dDate_Sheet,iLineNo
            	from #temp_Record_Preview
            	order by id
            
            	open Cur_Record_Preview
            	fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient
            	while @@fetch_status=0 
            	begin
            --     when a.iAttribute=0 then '入库'     
            --     when a.iAttribute=1 then '出库'
            --     when a.iAttribute=2 then '返厂'
            --     when a.iAttribute=3 then '客退'
            --     when a.iAttribute=4 then '调拨'
            --     when a.iAttribute=5 then '报损'
            --     when a.iAttribute=6 then '报溢'
            --     when a.iAttribute=7 then '差价'
            --     when a.iAttribute=8 then '原料出库'
            --     when a.iAttribute=9 then '加工入库'
            --     when a.iAttribute=10 then '日结'
            --     when a.iAttribute=11 then '盘点溢出'
            --     when a.iAttribute=12 then '盘点报损'
            --     when a.iAttribute=13 then 'Pos客退'
                    --print '@fQty_Pre:'+cast(@fQty_Pre as varchar(32))
                    --print '@fQty_left-001:'+cast(@fQty_left as varchar(32))
            	     --   print '@fQty_Cost-001:'+cast(@fQty_Cost as varchar(32))
                    if @fQty_Pre>0
                    begin
            		  update a
                      set fQty_Cost=fQty 
                      from t_cost_distribute a
                      where id=@id 
            		  insert into #temp_Record_null
            		  (id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo)
            		  values
            		  (@id,0,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost-@fQty_Pre,@fPrice_In*(@fQty_Cost-@fQty_Pre),@iAttribute,@cSheetno,@iLineNo_Orient,@fQty_left,0,@cWhNo)
                      --set @fQty_left=@fQty_left-@fQty_Pre	  
                      	set @fQty_left=@fQty_left-(@fQty_Cost-@fQty_Pre)				
            	        --print '@fQty_Cost-002:'+cast(@fQty_Cost as varchar(32))
            	        --print '@fQty_left-002:'+cast(@fQty_left as varchar(32))
                    end else
                    begin
            			insert into #temp_Record_null
            			(id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo)
            			values
            			(@id,1,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost,@fPrice_In*@fQty_Cost,@iAttribute,@cSheetno,@iLineNo_Orient,@fQty_left,0,@cWhNo)
            	       -- print '@fQty_left-003:'+cast(@fQty_left as varchar(32))
            	       -- print '@fQty_Cost-003:'+cast(@fQty_Cost as varchar(32))
            			set @fQty_left=@fQty_left-@fQty_Cost
            	       -- print '@fQty_left-004:'+cast(@fQty_left as varchar(32))
                    end
            	   
            
            	  fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient
            	end
            	close Cur_Record_Preview
            	deallocate Cur_Record_Preview
            
            	update a
            	set a.bDone=b.bDone_set
            	from t_cost_distribute a,#temp_Record_null b
            	where a.id=b.id
            
            	insert into t_cost_distribute
            	(dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,dDate_Account,cWhNo)
            	select dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,getdate(),cWhNo
            	from #temp_Record_null
            
            --以上解决负库存的成本分配问题
            
            fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
            end
            close CurCostTable
            deallocate CurCostTable
            
            
end


--update t_CheckTast
--set bAccount=1
--where cCheckTaskNo=@cSheetNo

commit tran
set @return=0


/*
declare @i int
exec p_FIFOPDIN_PermitNegativeStock_chen '001',@i output
select @i

*/
GO
