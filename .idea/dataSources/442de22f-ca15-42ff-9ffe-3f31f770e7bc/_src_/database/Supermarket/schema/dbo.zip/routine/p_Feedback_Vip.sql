
/*
p_Feedback_Vip '001'
*/
create procedure p_Feedback_Vip
@cActivityNo varchar(32)
as
begin
	select iCumulateValue_Mp,fModValue_MP,fRetMoney_Mp
	into #tempActivity_Mp
	from dbo.card_activity
	where cActivityNo=@cActivityNo
	order by iCumulateValue_Mp

	select iCumulateValue_Pos,fModValue_Pos,fRetMoney_Pos
	into #tempActivity_Pos
	from dbo.card_activity
	where cActivityNo=@cActivityNo
	order by iCumulateValue_Pos

	select a.cardno,a.curvalue_Mp,b.iCumulateValue_Mp
	into #tempBelongActivity_MP_all
	from dbo.Card_DateSetted a
	left join #tempActivity_Mp b on a.curvalue_Mp>=b.iCumulateValue_Mp
	where b.iCumulateValue_Mp is not null

  select cardno,curvalue_Mp,iCumulateValue_Mp=max(iCumulateValue_Mp)
	into #tempBelongActivity_Mp_max
  from #tempBelongActivity_Mp_all
	group by cardno,curvalue_Mp

	select a.cardno,a.curvalue_Pos,b.iCumulateValue_Pos
	into #tempBelongActivity_Pos_all
	from dbo.Card_DateSetted a
	left join #tempActivity_Pos b on a.curvalue_Pos>=b.iCumulateValue_Pos
	where b.iCumulateValue_Pos is not null

  select cardno,curvalue_Pos,iCumulateValue_Pos=max(iCumulateValue_Pos)
	into #tempBelongActivity_Pos_max
  from #tempBelongActivity_Pos_all
	group by cardno,curvalue_Pos
  

	select distinct Mp.cardno,Mp.curvalue_Mp,Mp.iCumulateValue_Mp,Mp.fModValue_MP,Mp.fRetMoney_Mp,
				 Pos.curvalue_Pos,Pos.iCumulateValue_Pos,Pos.fModValue_Pos,Pos.fRetMoney_Pos
	from
	(
		select a.cardno,a.curvalue_Mp,a.iCumulateValue_Mp,
					 b.fModValue_MP,b.fRetMoney_Mp 
		from #tempBelongActivity_Mp_max a left join #tempActivity_Mp b 
		on a.iCumulateValue_Mp=b.iCumulateValue_Mp
	) Mp
	left join 
	(
		select a.cardno,a.curvalue_Pos,a.iCumulateValue_Pos,
					 b.fModValue_Pos,b.fRetMoney_Pos 
		from #tempBelongActivity_Pos_max a left join #tempActivity_Pos b
		on a.iCumulateValue_Pos=b.iCumulateValue_Pos
	) Pos
	on Mp.cardno=Pos.cardno
end

GO
