

/*
p_Feedback_Vip_Ini '001'
*/
create  procedure p_Feedback_Vip_Ini
@cActivityNo varchar(32)
as
begin
	select iCumulateValue_Mp,fModValue_MP,fRetMoney_Mp
	into #tempActivity_Mp
	from dbo.card_activity
	where cActivityNo=@cActivityNo
	order by iCumulateValue_Mp

	select iCumulateValue_Pos,fModValue_Pos,fRetMoney_Pos
	into #tempActivity_Pos
	from dbo.card_activity
	where cActivityNo=@cActivityNo
	order by iCumulateValue_Pos

	select a.cardno,curvalue_Mp=a.curvalue,b.iCumulateValue_Mp
	into #tempBelongActivity_MP_all
	from dbo.Card a
	left join #tempActivity_Mp b on a.curvalue>=b.iCumulateValue_Mp
	where b.iCumulateValue_Mp is not null

  select cardno,curvalue_Mp,iCumulateValue_Mp=max(iCumulateValue_Mp)
	into #tempBelongActivity_Mp_max
  from #tempBelongActivity_Mp_all
	group by cardno,curvalue_Mp

	select a.cardno,a.curvalue_Pos,b.iCumulateValue_Pos
	into #tempBelongActivity_Pos_all
	from dbo.Card a
	left join #tempActivity_Pos b on a.curvalue_Pos>=b.iCumulateValue_Pos
	where b.iCumulateValue_Pos is not null

  select cardno,curvalue_Pos,iCumulateValue_Pos=max(iCumulateValue_Pos)
	into #tempBelongActivity_Pos_max
  from #tempBelongActivity_Pos_all
	group by cardno,curvalue_Pos
  

	select distinct Mp.cardno,Mp.curvalue_Mp,Mp.iCumulateValue_Mp,Mp.fModValue_MP,Mp.fRetMoney_Mp,
				 Pos.curvalue_Pos,Pos.iCumulateValue_Pos,Pos.fModValue_Pos,Pos.fRetMoney_Pos,
				 fRetMoney_Mp_total=floor(floor(Mp.curvalue_Mp)/Mp.fModValue_MP)*Mp.fRetMoney_Mp,
				 fRetMoney_Pos_total=floor(floor(Pos.curvalue_Pos)/Pos.fModValue_Pos)*Pos.fRetMoney_Pos
	
	into #tempBelongActivity_Mp_Pos_list
	from
	(
		select a.cardno,a.curvalue_Mp,a.iCumulateValue_Mp,
					 b.fModValue_MP,b.fRetMoney_Mp 
		from #tempBelongActivity_Mp_max a left join #tempActivity_Mp b 
		on a.iCumulateValue_Mp=b.iCumulateValue_Mp
	) Mp
	left join 
	(
		select a.cardno,a.curvalue_Pos,a.iCumulateValue_Pos,
					 b.fModValue_Pos,b.fRetMoney_Pos 
		from #tempBelongActivity_Pos_max a left join #tempActivity_Pos b
		on a.iCumulateValue_Pos=b.iCumulateValue_Pos
	) Pos
	on Mp.cardno=Pos.cardno

	select cardno,curvalue_Mp,iCumulateValue_Mp,fModValue_MP,fRetMoney_Mp,
				 curvalue_Pos,iCumulateValue_Pos,fModValue_Pos,fRetMoney_Pos,fRetMoney_Mp_total,fRetMoney_Pos_total
	into #tempBelongActivity_Mp_Pos_list_detail
	from #tempBelongActivity_Mp_Pos_list
	union all
  select cardno='合计',curvalue_Mp=null,iCumulateValue_Mp=null,fModValue_MP=null,fRetMoney_Mp=null,
				 curvalue_Pos=null,iCumulateValue_Pos=null,fModValue_Pos=null,fRetMoney_Pos=null,
				 fRetMoney_Mp_total=sum(isnull(fRetMoney_Mp_total,0)),
				 fRetMoney_Pos_total=sum(isnull(fRetMoney_Pos_total,0))
	from #tempBelongActivity_Mp_Pos_list

  select a.cardno,b.name,b.sex,IDno=b.zhiwu,b.home,b.tel,a.curvalue_Mp,a.iCumulateValue_Mp,a.fModValue_MP,a.fRetMoney_Mp,
				 a.curvalue_Pos,a.iCumulateValue_Pos,a.fModValue_Pos,a.fRetMoney_Pos,a.fRetMoney_Mp_total,a.fRetMoney_Pos_total
	from #tempBelongActivity_Mp_Pos_list_detail a
	left join card b on a.cardno=b.cardno
  

end


GO
