

/*

p_Feiyong_jiesuan '','2009-05-01','2009-08-30'

*/


CREATE     procedure p_Feiyong_jiesuan
@guizuno varchar(32),
@date1 datetime,
@date2 datetime
as
begin
  /*生成报表的列*/
  select detail=feiyong,sum(feiyongjine) shishou 
  into #jiesuan_detail
	from guizufeiyong
  where  zdriqi between @date1 and  @date2
         and (dbo.trim(jiesuanno)<>'' and jiesuanno is not null)
  group by feiyong
 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     商户编号 varchar(32),
     商户名称 varchar(64),
		 合作方式 varchar(64)
	)

  declare @cAddFields varchar(8000)
  set @cAddFields=''
  declare @strtmp varchar(8000)
  set @strtmp=''
  declare @strtmp_group varchar(8000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(8000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+'['+@detail+'] varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+'['+@detail+']=cast(sum(cast(['+@detail+'] as money)) as varchar(32)),'
--    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
    set @strtmp_Clear=@strtmp_Clear+'['+@detail+']=case when cast(['+@detail+'] as money)=0 then ''0.00'' else ['+@detail+'] end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(sum(cast(合计 as money)) as varchar(32))'
--  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''0.00'' else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

	select shouyinyuanno=guizuno,shouyinyuanmc=guizu,detail=feiyong,
	       sum(feiyongjine) shishou
  into #jiesuan
	from guizufeiyong
	where zdriqi between @date1 and  @date2
         and (dbo.trim(jiesuanno)<>'' and jiesuanno is not null)
	group by  guizuno,guizu,feiyong
	order by guizuno,guizu,feiyong
  
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,shishou=cast(shishou as char(32))
  from #jiesuan
  order by shouyinyuanno,shouyinyuanmc,detail
 
  select shouyinyuanno,shouyinyuanmc,shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  group by shouyinyuanno,shouyinyuanmc
  

  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou

  while @@fetch_status=0
  begin
		if (select 商户编号 from #account_detail 
				where 商户编号=@shouyinyuanno and 商户名称=@shouyinyuanmc) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''',null,'+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 商户编号='''+@shouyinyuanno+''' and 商户名称='''+@shouyinyuanmc+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.商户编号=b.shouyinyuanno and a.商户名称=b.shouyinyuanmc 
 
--  print @strtmp_Clear
  if  (select object_id('tempdb..##account_detail_last')) is not null 
  drop table ##account_detail_last

  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 商户编号=''总计'',商户名称=null,合作方式=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select * into ##account_detail_last from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 商户编号='''+@guizuno+''' '+'
    
    union all
    select 商户编号=''总计'',商户名称=null,合作方式=null,'+@strtmp_group
    +' from #account_detail where 商户编号='''+@guizuno+''' '
    +@strtmp_Clear
    +' select * into ##account_detail_last  from #account_detail_last')
  end

	update a set a.合作方式=b.jingyingfangshi
	from ##account_detail_last a,guizu b where a.商户编号=b.guizuno
  --exec(@strtmp_Clear)

end


GO
