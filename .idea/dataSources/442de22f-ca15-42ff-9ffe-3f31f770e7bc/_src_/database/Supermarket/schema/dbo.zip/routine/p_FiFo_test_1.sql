

CREATE   procedure p_FiFo_test_1
@spno varchar(32),
@cangkuno varchar(32),
@Date datetime
as
begin
  set nocount on
	select cSheetNo,cGoodsNo,iSerno,cSummary,fPrice_In,fQty_In,fMoney_In,fPrice_Out,fQty_Out,
	fMoney_Out,fQty_Left,fPrice_Left,fMoney_Left,dDate=dbo.getdaystr(dDatetime),dDateTime
	into #tempWH_Form0 
	from dbo.T_WH_Form
	where cGoodsNo=@spno and cWhNo=@cangkuno and dbo.getdaystr(dDateTime)<=@Date
	and isnull(bJiecun,0)=0


  select distinct dDate 
	into #tempDate0
	from  #tempWH_Form0

	select DateTitle=b.dDate,a.dDate
	into #tempDate1
	from #tempDate0 a full outer join #tempDate0 b 
  on a.dDate<=b.dDate
	order by b.dDate,a.dDate
  
  select iLineNo=0,DateTitle_disp=b.DateTitle,b.DateTitle,a.cSheetNo,a.cGoodsNo,a.iSerno,a.cSummary,a.fPrice_In,a.fQty_In,a.fMoney_In,a.fPrice_Out,a.fQty_Out,
	a.fMoney_Out,a.fQty_Left,a.fPrice_Left,a.fMoney_Left,a.dDate,a.dDateTime
	into #tempWH_Form
	from #tempWH_Form0 a left join #tempDate1 b
	on a.dDate=b.dDate
--  order by b.DateTitle,a.dDate,a.dDateTime
	order by b.DateTitle,a.dDate,a.dDateTime,a.cSheetNo,a.iSerno

	update #tempWH_Form set cSummary=null,fQty_Left=fQty_In,fPrice_Left=fPrice_In,fMoney_Left=fMoney_In,
	fQty_In=null,fPrice_In=null,fMoney_In=null
	where DateTitle<>dDate
  
	update #tempWH_Form set fQty_Left=fQty_In,fPrice_Left=fPrice_In,fMoney_Left=fMoney_In
	where DateTitle=dDate

  select a.*,LeftSubFactor=cast(0 as money) into #tempWH_Form_ex from #tempWH_Form a

	select spno,mingcheng,cSummary=cast(' ' as varchar(32)),lsriqi,shuliang=sum(shuliang) 
	into #tempLsdsp
	from lsdsp 
	where lsriqi<=@Date and spno=@spno
	group by spno,mingcheng,lsriqi 

  update a set a.cSummary='销售'+dbo.trim(cast(a.shuliang as varchar(32)))+b.danwei
  from #tempLsdsp a,spxx b
  where a.spno=b.spno
	
	select spno,mingcheng,cSummary,shuliang,lsriqi
	into #tempOut
	from #tempLsdsp
	union all
	select a.spno,a.mingcheng,cSummary='发出'+dbo.trim(cast(a.shuliang as varchar(32)))+b.danwei,
	a.shuliang,zdriqi
	from dbo.ckd_sp a ,spxx b
  where a.spno=@spno and a.cangkuno=@cangkuno and dbo.getdaystr(a.zdriqi)<=@Date 
				and  a.spno=b.spno
	union all
	select a.spno,a.mingcheng,cSummary='报损'+dbo.trim(cast(a.shuliang as varchar(32)))+b.danwei,
	a.shuliang,zdriqi
	from dbo.syd_sp a ,spxx b
  where a.spno=@spno and a.cangkuno=@cangkuno and dbo.getdaystr(a.zdriqi)<=@Date 
				and  a.spno=b.spno


	declare @fQty_Out_P money
	declare @fQty_Out money
	select @fQty_Out=sum(shuliang) from #tempOut
	set	@fQty_Out=isnull(@fQty_Out,0) /*期间发出数量*/	
	set @fQty_Out_P=@fQty_Out
--print cast(@fQty_Out as varchar(32))
	
	declare @Outriqi datetime
	declare @OutQty money

	declare @cSheetno varchar(32)
	declare @DateTitle datetime
	declare @iSerno int
	declare @fQty_Left money

	declare @cSheetno_old varchar(32)
	declare @DateTitle_old datetime
	declare @iSerno_old int

	declare cursor_In cursor
	for
	select DateTitle,cSheetNo,iSerno,fQty_Left
	from #tempWH_Form_ex
	order by DateTitle,dDate,dDateTime,cSheetNo,iSerno

	open cursor_In

	fetch next from cursor_In
	into @DateTitle,@cSheetno,@iSerno,@fQty_Left

	while @@Fetch_status=0
	begin
		if @fQty_Out>0 
		begin
			if (@fQty_Left>@fQty_Out)  
			begin
				update #tempWH_Form_ex
				set fQty_Out=@fQty_Out,fQty_Left=fQty_Left-@fQty_Out,fPrice_Out=fPrice_In,fMoney_Out=@fQty_Out*fPrice_In,
				fMoney_Left=(fQty_Left-@fQty_Out)*fPrice_Left
				where DateTitle=@DateTitle and cSheetno=@cSheetno and iSerno=@iSerno
			
				update #tempWH_Form_ex
				set fQty_Out=0,fQty_Left=fQty_Left-@fQty_Out
				where DateTitle>@DateTitle and cSheetno=@cSheetno and iSerno=@iSerno

			end else
			begin

				update #tempWH_Form_ex
				set fQty_Out=fQty_Left,fQty_Left=0,fPrice_Out=fPrice_In,fMoney_Out=fQty_Left*fPrice_In,
				fMoney_Left=0
				where DateTitle=@DateTitle and cSheetno=@cSheetno and iSerno=@iSerno
	
				delete from #tempWH_Form_ex 
				where DateTitle>@DateTitle and cSheetno=@cSheetno and iSerno=@iSerno 

			end
	  end
    
		fetch next from cursor_In
		into @DateTitle,@cSheetno,@iSerno,@fQty_Left

  	select  @fQty_Left=fQty_Left
		from #tempWH_Form_ex
		where Datetitle=@DateTitle and cSheetno=@cSheetno and iSerno=@iSerno
		set @fQty_Left=isnull(@fQty_Left,0)

  	select  @fQty_Out=@fQty_Out_P-isnull(sum(isnull(fQty_Out,0)),0)
		from #tempWH_Form_ex

		set @cSheetno_old =@cSheetno
		set @DateTitle_old =@DateTitle
		set @iSerno_old =@iSerno

	end

	close cursor_In
	deallocate cursor_In

  declare @i int
	set @i=0
  update #tempWH_Form_ex
	set @i=iLineNo=@i+1 
 
  update a
	set a.DateTitle_disp=null
	from #tempWH_Form_ex a ,
	(
		  select DateTitle,iLineNo=min(iLineNo)
		  from #tempWH_Form_ex
		  group by DateTitle
	) b
	where a.DateTitle=b.DateTitle and a.iLineNo<>b.iLineNo	

  select * from #tempWH_Form_ex --where dateTitle=@Date
--	order by DateTitle,dDate,dDateTime,cSheetNo,iSerno
	


end
/*

p_FiFo_test_1 '110141001','001','2007-03-10'

*/


GO
