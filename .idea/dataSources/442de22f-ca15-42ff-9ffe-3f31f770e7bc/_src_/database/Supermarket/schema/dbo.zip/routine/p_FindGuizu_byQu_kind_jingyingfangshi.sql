CREATE procedure p_FindGuizu_byQu_kind_jingyingfangshi
@quno varchar(32),
@jingyingfangshi varchar(32),
@kind varchar(32)
as
begin

    select a.guizuno,a.guizu from guizu a

    where (a.quno=@quno or @quno='<全部>' )
          and (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' )
          and a.guizuno in (select distinct guizuno from spxx 
                            where kind=@kind or @kind='<全部>' )

end
GO
