CREATE proc [dbo].[p_GetGuizuInfor]
@guizuNo varchar(32),
@telCode varchar(256)
as
begin
	select a.guizu, a.guizuno,a.quno,a.qu,a.leixing,b.TelCode  from guizu a,GuizuNo_TelCode b
	where a.guizuno=@guizuNo and b.TelCode=@telCode and a.guizuno=b.guizuno
end
GO
