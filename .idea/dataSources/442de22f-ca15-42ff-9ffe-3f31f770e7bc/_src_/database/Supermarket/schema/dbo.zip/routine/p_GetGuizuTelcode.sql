CREATE proc [dbo].[p_GetGuizuTelcode]
@telCode varchar(64),
@guizuNo varchar(32),
@guizuPwd varchar(32)
as
begin


     --GuizuNo_TelCode
     if not exists (select top 1 a.guizuno 
                    from  dbo.guizu a,GuizuNo_TelCode b 
                    where a.guizuno=b.guizuno and b.TelCode=@telCode)  -- 标识当前手机标识未对应到柜组
     begin        
        if exists(select b.TelCode from guizu a,GuizuNo_TelCode b  where a.guizuno=@guizuNo and  a.guizuno=b.guizuNo and isnull(password_guizu,'')=@guizuPwd)  -- 表示柜组、密码对上。
        begin
             -- 判断当前柜组是否绑定手机       
			 declare @Code varchar(64)
		     set @Code=(select b.TelCode 
		                from  dbo.guizu a,GuizuNo_TelCode b 
		                where a.guizuno=@guizuNo AND a.guizuno=b.guizuno
		                AND b.TelCode=@telCode
		                and isnull(password_guizu,'')=@guizuPwd)
             if ISNULL(@Code,'')<>''
             begin
                select bCode=3  ---当前手机为新手机，柜组已设置对应手机、不能多次设置 
                select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
                where 1<>1                
             end else
             begin
                select bCode=1   ---设置成功
                
                select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
                where guizuno=@guizuNo
                
                --update  dbo.guizu set TelCode=@telCode
                --where guizuno=@guizuNo and isnull(password_guizu,'')=@guizuPwd
                insert INTO dbo.GuizuNo_TelCode(guizuno,TelCode,dDate)
                VALUES(@guizuNo,@telCode,getdate())
               
             end
        end  else
        begin
            select bCode=2   ---柜组密码错误
            select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
            where 1<>1
        end    
     end else
     begin 
         if exists(select b.TelCode from guizu a ,GuizuNo_TelCode b where  a.guizuno=@guizuNo and   a.guizuno=b.guizuNo and isnull(password_guizu,'')=@guizuPwd)  -- 表示柜组、密码对上。
		 begin
			 declare @TelCode0 varchar(32)
			 set @TelCode0=(select b.TelCode from guizu a,GuizuNo_TelCode b 
			 where a.guizuno=@guizuNo AND a.guizuno=b.guizuno
			 AND b.TelCode=@telCode
			 and isnull(password_guizu,'')=@guizuPwd)
	         
			 if @TelCode0=@telCode
			 begin
					select bCode=1    --- 匹配成功
					select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
					where  guizuno=@guizuNo
			 end else
			 begin          
					select bCode=4   --表示当前柜组信息与的手机标识不一致
					select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
					where 1<>1
			 end
         end else
         begin
            select bCode=2   ---柜组密码错误
            select gonghao,guizu,guizuno,mingcheng,Pass from guizu_yuangong
            where 1<>1
         end
     end
 
end
GO
