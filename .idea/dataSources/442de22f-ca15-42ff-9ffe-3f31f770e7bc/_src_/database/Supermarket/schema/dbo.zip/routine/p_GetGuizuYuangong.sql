CREATE proc [dbo].[p_GetGuizuYuangong]
@guizuNo varchar(32),
@telCode varchar(256)
as
begin
	select gonghao,b.guizuno,b.guizu,mingcheng,Pass 
	from guizu_yuangong a,guizu b ,GuizuNo_TelCode c
	where a.guizuno=b.guizuno and b.guizuno=@guizuNo
	and c.TelCode=@telCode and b.guizuno=c.guizuno
end
GO
