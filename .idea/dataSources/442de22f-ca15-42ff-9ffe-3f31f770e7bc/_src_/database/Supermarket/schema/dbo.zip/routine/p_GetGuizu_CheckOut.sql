
CREATE     procedure [dbo].[p_GetGuizu_CheckOut]
@date1 datetime,
@date2 datetime,
@cMode varchar(64)
as
begin
  
  select guizuno,sheetno=lsdno
  into #guizu_NotShenhe
  from lsd
  where (zdriqi between @date1 and @date2) and (shenhe is null or shenhe=0)
  union all
  select guizuno,sheetno=cast(serno as varchar(32))
  from guizufeiyong
  where (zdriqi between @date1 and @date2) and (shenhe is null or shenhe=0)
   
  select distinct guizuno,guizu
  into #guizu0
  from lsd
  where (zdriqi between @date1 and @date2)
  union all
  select distinct guizuno,guizu
  from guizufeiyong
  where (zdriqi between @date1 and @date2)

 
  select distinct a.guizuno,a.guizu
  into #guizu
--  from guizu
  from 
		(
     select guizuno,guizu=mingcheng
     from shanghu_hetong
     where 	/*从商户合同里面查找商户进驻的日期*/
       @date2>=cast(dbo.getDayStr(qixian1) as datetime)


		) a
  where a.guizuno not in (select guizuno from #guizu_NotShenhe)
  
--  select * from #guizu
 
  drop table #guizu0
  drop table #guizu_NotShenhe

/*
  declare @startdate datetime
  set @startdate=(select top 1 startdate from t_company_init)   
  if @startdate is not null and @date1=@startdate
  begin
*/

  select a.guizuno,b.riqi2,b.jiesuanno 
	into #guizu_jiesuan 
	from #guizu a left join guizu_jiesuan b on a.guizuno=b.guizuno 
/*
  select * from #guizu
  select * from #guizu_jiesuan
*/
  select c.guizuno,lastriqi=max(c.riqi2)
  into #lastriqi_jiesuan
  from #guizu_jiesuan c 
  group by c.guizuno

  select guizuno,lastjiesuanno=max(jiesuanno)
  into #lastjiesuanno_jiesuan
  from #guizu_jiesuan 
  group by guizuno

  select a.guizuno,a.lastriqi,b.lastjiesuanno,c.guizu
  into #lastInformation
  from #lastriqi_jiesuan a
  left join #lastjiesuanno_jiesuan b
  on a.guizuno=b.guizuno
  left join guizu c
  on a.guizuno=c.guizuno

  drop table #lastriqi_jiesuan
  drop table #lastjiesuanno_jiesuan
  
--  select * from #lastInformation
  select guizuno,guizu,lastriqi,lastjiesuanno
  from #lastInformation
  where (@date1=DATEADD(day, 1, lastriqi) or lastriqi is null) and guizu is not null
       and guizuno in (select guizuno from #guizu)
  and guizuno in 
  ( select guizuno
		from shanghu_hetong
		where isnull(_cbb_Mode,'')=ltrim(@cMode)
  )
    
end


GO
