
create     procedure [dbo].[p_GetPath_GoodsType]
as
begin
/*
  set nocount on
	if(select object_id('tempdb..#tempSpxx_quno')) is not null
	begin
		drop table 	#tempSpxx_quno
	end 
  
  select guizuno=cGoodsTypeno,guizu=cGoodsTypename,quno=cGoodsTypeno,qu=cGoodsTypename,
	selected=1
  into #spxx
  from dbo.t_GoodsType

  select guizuno=cGoodsTypeno,guizu=cGoodsTypename,quno=cGoodsTypeno,qu=cGoodsTypename
  into #guizu
  from dbo.t_GoodsType

  select cGoodsTypeNo,cParentNo,diquno=cGoodsTypeNo,diqumc=cGoodsTypename
  into #diqu
  from t_GoodsType

	select c.guizuno,c.guizu,c.quno,c.qu
	into #tempSpxx_quno
	from #spxx d left join	#guizu c
	on d.guizuno=c.guizuno
	where isnull(d.selected,0)=1
	
	
	if(select object_id('tempdb..#temp_t_GoodsType')) is not null
	begin
		drop table 	#temp_t_GoodsType
	end 
	select 
	cGoodsTypeNo=diquno, cParentNo=cParentNo
	into #temp_t_GoodsType
	from #diqu	


	if(select object_id('tempdb..#tempLevel')) is not null
	begin
		drop table 	#tempLevel
	end 
  create table #tempLevel (cGoodsTypeNo varchar(32),cPath varchar(1024),iLevel int )

	if(select object_id('tempdb..#tempLeaf')) is not null
	begin
		drop table 	#tempLeaf
	end 

	select a.cGoodsTypeNo,a.cParentNo
	into #tempLeaf
	from #temp_t_GoodsType a left join #temp_t_GoodsType b
	on   a.cGoodsTypeNo =b.cParentNo 
	where b.cGoodsTypeNo is  null
	order by a.cParentNo,a.cGoodsTypeNo

	declare @cGoodsTypeNo varchar(32)
	declare @cParentNo varchar(32)
	declare @cPath varchar(1024)
	declare @iPathlevel int


	declare @cGoodsTypeNo_var varchar(32)

	declare crGoodsTypeNo cursor for
  select cGoodsTypeNo,cParentNo from #tempLeaf
	order by cParentNo,cGoodsTypeNo
  
  open crGoodsTypeNo

	fetch next from crGoodsTypeNo
	into @cGoodsTypeNo,@cParentNo
	
	set @cGoodsTypeNo_var=@cGoodsTypeNo
  set @cPath=''
	set @iPathlevel=1
	while @@Fetch_Status=0
	begin
		while isnull((select top 1 cParentNo from #temp_t_GoodsType 
									where cGoodsTypeNo=@cGoodsTypeNo_var 
												and @cGoodsTypeNo_var is not null
									)
									,''
								)<>'--'
		begin
			set @iPathlevel=@iPathlevel+1
			set @cPath= '.'+@cGoodsTypeNo_var+@cPath
			set @cGoodsTypeNo_var=
							isnull((select top 1 cParentNo from #temp_t_GoodsType 
											where cGoodsTypeNo=@cGoodsTypeNo_var 
														and @cGoodsTypeNo_var is not null
											),'')
		end				
    set @cPath='--.'+@cGoodsTypeNo_var+@cPath
		--print @cGoodsTypeNo

    insert into #tempLevel (cGoodsTypeNo,cPath,iLevel)
	  values (@cGoodsTypeNo,@cPath,@iPathlevel)

		fetch next from crGoodsTypeNo
		into @cGoodsTypeNo,@cParentNo
		set @cGoodsTypeNo_var=@cGoodsTypeNo
	  set @cPath=''
		set @iPathlevel=1
	end
  
CLOSE crGoodsTypeNo
DEALLOCATE crGoodsTypeNo

	if(select object_id('tempdb..#tempResult0')) is not null
	begin
		drop table 	#tempResult0
	end 

	select 
	 distinct a.cGoodsTypeno,a.cPath,a.iLevel,b.guizuno,b.guizu,b.quno,b.qu
	into #tempResult0
	from #tempLevel a left join #tempSpxx_quno b
	on a.cGoodsTypeNo=b.quno
	
	--select * from #tempSpxx_quno
	
	select distinct a.diquno,a.diqumc,a.cParentNo,b.cPath
	into #temp_guizuxx
	from #diqu a,#tempResult0 b
	where b.cPath+'.' like '%.'+a.diquno+'.%' 



	if(select object_id('tempdb..#temp_guizu')) is not null
	begin
		drop table 	#temp_guizu
	end 

	select distinct guizuno,guizu
	into #temp_guizu
	from #spxx
	where isnull(selected,0)='1'



	select diquno,diqumc,cParentNo=dbo.trim(cParentNo),cPath
	from #temp_guizuxx
*/

		declare @bFlag bit
		set @bFlag=0
		update diqu set cPath=diquno
			
			declare @cGoodsTypeno varchar(32)
			declare @cParentNo varchar(32)
			declare @cPath varchar(1028)
			declare @cPath_temp varchar(1028)
			
			
		while exists (select diquno,cParentNo,cPath
			from diqu
			where patindex('%--%',isnull(cPath,''))=0)
		begin
		  
			declare GoodsType_cursor cursor
			for
			select diquno,cParentNo,cPath
			from diqu
			where patindex('%--%',isnull(cPath,''))=0

			open GoodsType_cursor
			fetch next from GoodsType_cursor
			into @cGoodsTypeno,@cParentNo,@cPath
		  
			while @@fetch_status=0
			begin

				set @cPath_temp=(select top 1 cPath from diqu where diquno=@cParentNo)
				set @cPath_temp=case when @cPath_temp is null then '--' else @cPath_temp end
			
				update diqu 
				set cPath= @cPath_temp+'.'+@cGoodsTypeno
				       
				where diquno=	@cGoodsTypeno

				fetch next from GoodsType_cursor
				into @cGoodsTypeno,@cParentNo,@cPath
			end

			close GoodsType_cursor
			deallocate GoodsType_cursor
		end	
	update diqu set cPath=cPath+'.'	
	update a
	set a.cPath=b.cPath
	from weizhi a,diqu b
	where a.WeizhiNo=b.diquno
	/*	
	select diquno,diqumc,cParentNo,cPath
	from diqu
	*/
end


GO
