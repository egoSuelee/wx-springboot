

--select * from dbo.t_Proprietor_House_Weizhi

CREATE     procedure p_GetPath_house
as
begin
/*
select * from guizu

--select * from weizhi
select * from diqu
*/
  set nocount on
	if(select object_id('tempdb..#tempSpxx_quno')) is not null
	begin
		drop table 	#tempSpxx_quno
	end 
/*
	select d.spno,d.mingcheng,d.selected,c.guizuno,c.guizu,c.quno,c.qu
	into #tempSpxx_quno
	from spxx d left join 
	(
	
			select a.guizuno,a.guizu,a.quno,a.qu
			from guizu a left join diqu b
			on a.quno=b.diquno
	) c
	
*/
	select c.guizuno,c.guizu,c.quno,c.qu
	into #tempSpxx_quno
	from spxx d left join	guizu c
	on d.guizuno=c.guizuno
	where isnull(d.selected,0)=1
	
	
	--select * from #tempSpxx_quno
	
	if(select object_id('tempdb..#temp_t_GoodsType')) is not null
	begin
		drop table 	#temp_t_GoodsType
	end 
	select 
	cGoodsTypeNo=weizhino, cParentNo=cParentNo
	into #temp_t_GoodsType
	from t_Proprietor_House_Weizhi	


	if(select object_id('tempdb..#tempLevel')) is not null
	begin
		drop table 	#tempLevel
	end 
  create table #tempLevel (cGoodsTypeNo varchar(32),cPath varchar(1024),iLevel int,cParentNo varchar(32) )

	if(select object_id('tempdb..#tempLeaf')) is not null
	begin
		drop table 	#tempLeaf
	end 

	select a.cGoodsTypeNo,a.cParentNo
	into #tempLeaf
	from #temp_t_GoodsType a 
/*
left join #temp_t_GoodsType b
	on   a.cGoodsTypeNo =b.cParentNo 
	where b.cGoodsTypeNo is  null
	order by a.cParentNo,a.cGoodsTypeNo
*/
	declare @cGoodsTypeNo varchar(32)
	declare @cParentNo varchar(32)
	declare @cPath varchar(1024)
	declare @iPathlevel int
--  select * from diqu

	declare @cGoodsTypeNo_var varchar(32)

	declare crGoodsTypeNo cursor for
  select cGoodsTypeNo,cParentNo from #tempLeaf
	order by cParentNo,cGoodsTypeNo
  
  open crGoodsTypeNo

	fetch next from crGoodsTypeNo
	into @cGoodsTypeNo,@cParentNo
	
	set @cGoodsTypeNo_var=@cGoodsTypeNo
  set @cPath=''
	set @iPathlevel=1
	while @@Fetch_Status=0
	begin
/*
		while isnull((select top 1 cParentNo from #temp_t_GoodsType 
									where cGoodsTypeNo=@cGoodsTypeNo_var 
												and @cGoodsTypeNo_var is not null
									)
									,''
								)<>'--'
		begin
			set @iPathlevel=@iPathlevel+1
			set @cPath= '.'+@cGoodsTypeNo_var+@cPath
			set @cGoodsTypeNo_var=
							isnull((select top 1 cParentNo from #temp_t_GoodsType 
											where cGoodsTypeNo=@cGoodsTypeNo_var 
														and @cGoodsTypeNo_var is not null
											),'')
		end			
*/	
    set @cPath='--.'+@cGoodsTypeNo_var+@cPath
		--print @cGoodsTypeNo

    insert into #tempLevel (cGoodsTypeNo,cPath,iLevel)
	  values (@cGoodsTypeNo,@cPath,@iPathlevel)

		fetch next from crGoodsTypeNo
		into @cGoodsTypeNo,@cParentNo
		set @cGoodsTypeNo_var=@cGoodsTypeNo
	  set @cPath=''
		set @iPathlevel=1
	end
  
CLOSE crGoodsTypeNo
DEALLOCATE crGoodsTypeNo
update a set a.cParentNo=b.cParentNo
from #tempLevel a,dbo.t_Proprietor_House_Weizhi b
where a.cGoodsTypeNo=b.weizhino

select diquno=a.cGoodsTypeNo,diqumc=b.weizhi,a.cParentNo,a.cPath
from #tempLevel a left join dbo.t_Proprietor_House_Weizhi b
on a.cGoodsTypeNo=b.WeizhiNo

	--select diquno=cGoodsTypeNo,diqu=null,cParentNo,cPath from #tempLevel

end


GO
