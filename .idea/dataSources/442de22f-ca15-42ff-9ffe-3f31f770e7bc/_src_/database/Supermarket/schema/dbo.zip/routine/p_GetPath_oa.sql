create proc p_GetPath_oa
as
if(select object_id('tempdb..#type')) is not null 	drop table 	#type
select diquno,diqumc,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) into #type 
from diqu
update #type set cpath=cParentNo+'.'+diquno

declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #type where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #type a left join #type b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	
	select @num=COUNT(*) from #type where cpath not like '%--%'
end
select * from #type
GO
