CREATE proc [dbo].[p_GetPinpai]
@guizuNo varchar(32),
@telCode varchar(256)
as
begin
    select pinpai,pinpaino,b.guizuNo,b.guizu 
    from t_pinpai a,guizu b,GuizuNo_TelCode c
	where a.guizuno=b.guizuno and b.guizuno=@guizuNo
	and c.TelCode=@telCode and c.guizuno=b.guizuno
end
GO
