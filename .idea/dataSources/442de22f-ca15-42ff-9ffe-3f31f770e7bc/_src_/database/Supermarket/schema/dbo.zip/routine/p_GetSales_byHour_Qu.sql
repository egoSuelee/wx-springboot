







create      procedure p_GetSales_byHour_Qu
@datetime1 datetime,
@datetime2 datetime,
@tempTableQu varchar(32)
as
begin
  create table #tempSpxx_Qu
	(spno varchar(32),
	Mingcheng varchar(64),
	guizuno varchar(32),
	guizu varchar(64),
	quno varchar(32),
	qu varchar(64),
	fRatio money,
	jingyingfangshi varchar(64))
  
  create table #tempLsdsp
	(spno varchar(32),
	Mingcheng varchar(64),
	guizuno varchar(32),
	guizu varchar(64),
	quno varchar(32),
	qu varchar(64),
	fRatio money,
	jingyingfangshi varchar(64),
  LsdNo varchar(32),Danwei varchar(32),Shuliang money ,Danjia money,shishou money,yingshou money,chongjian money,zhekoulv money,
	hyzhekoulv money,daogouyuanno varchar(32),daogouyuan varchar(32),
	shoukuanyuanno varchar(32),shoukuanyuan varchar(32),lsriqi datetime,lstime datetime
	)
exec('
	insert into #tempSpxx_Qu
  select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,jingyingfangshi
	from dbo.v_Spxx_Qu '
	+' where quno in (select quno=cQuyuNo from '+@tempTableQu+') '

	+'
	insert into #tempLsdsp
  (
	spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,jingyingfangshi,
	LsdNo,Danwei,Shuliang,Danjia,shishou,yingshou,chongjian,zhekoulv,
	hyzhekoulv,daogouyuanno,daogouyuan,shoukuanyuanno,shoukuanyuan,lsriqi,lstime
	)
	select a.spno,a.Mingcheng,a.guizuno,a.guizu,a.quno,a.qu,a.fRatio,a.jingyingfangshi,
				 b.LsdNo,b.Danwei,b.Shuliang,b.Danjia,shishou=b.jine,b.yingshou,b.chongjian,b.zhekoulv,
				 b.hyzhekoulv,b.daogouyuanno,b.daogouyuan,shoukuanyuanno=c.xsyno,shoukuanyuan=c.xsy,b.lsriqi,b.lstime
	from #tempSpxx_Qu a left join dbo.lsdsp b on a.spno=b.spno
	left join lsd c on b.lsdno=c.lsdno
	where b.Lsriqi between '''+@datetime1+''' and '''+ @datetime2+'''
				and a.spno is not null
')
  select cSaleSheetno=quno,fLastSettle=sum(isnull(shishou,0)),dSaleDate=Lsriqi,cSaleTime=lstime
	into #jiesuan
	from #tempLsdsp
	where Lsriqi between @datetime1 and @datetime2
	group by quno,Lsriqi,lstime

	select lsdno=a.cSaleSheetno,shishou=a.fLastSettle,zdriqi=a.dSaleDate,PosID=b.diquno,
				 Hourpart=datepart(hh,cast('2000-01-01 '+a.cSaleTime as datetime)) 
	into #lsd_temp 
	from #jiesuan a left join dbo.diqu b
							 on cSaleSheetno=b.diquno
	where a.dSaleDate between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)

	select a.PosID,PosSales=isnull((select sum(shishou) from #lsd_temp where PosID=a.PosID),0),
				 a.Hourpart,HourPartSales=sum(a.shishou)
	into #lsd_temp_1
	from #lsd_temp a  
	group by a.PosID,a.Hourpart

--select * from #lsd_temp_1 order by PosID,Hourpart

	create table #CubeList
	(
		PosID varchar(32),PosName varchar(64),PosSales money,TotalSales money,H0 money,H1 money,H2 money,H3 money,H4 money,H5 money,H6 money,
		H7 money,H8 money,H9 money,H10 money,H11 money,H12 money,H13 money,H14 money,H15 money,H16 money,
		H17 money,H18 money,H19 money,H20 money,H21 money,H22 money,H23 money
	) 
  declare @PosID varchar(32) 
  declare @PosSales Money
	declare @HourPart int
	declare @HourPartSales money

	declare crCubeList cursor
	for
	select PosID,PosSales,Hourpart,HourPartSales from #lsd_temp_1 

  open crCubeList
	fetch next from crCubeList
	into @PosID,@PosSales,@Hourpart,@HourPartSales

	declare @strtmpPosID varchar(32)
	declare @strtmpPosSales varchar(32)
	declare @strtmpHourpart varchar(2)
	declare @strtmpHourPartSales varchar(32)
   
	while @@fetch_status=0 
	begin
		if (select count(PosID) from #CubeList where PosID=@PosID)=0
		begin
			insert into #CubeList (PosID,PosSales) values (@PosID,@PosSales)
		end 

		  set @strtmpHourpart=dbo.trim(cast(@Hourpart as varchar(2)))
		  set @strtmpPosID=@PosID
		  set @strtmpPosSales=cast(@PosSales as varchar(32))
		  set @strtmpHourPartSales=cast(@HourPartSales as varchar(32))

    	exec('update #CubeList set H'+@strtmpHourpart+'='+@strtmpHourPartSales+'
              where PosID='''+@PosID+'''

					')
		
		fetch next from crCubeList
		into @PosID,@PosSales,@Hourpart,@HourPartSales
	end

 	CLOSE crCubeList
  DEALLOCATE crCubeList

  update a set a.TotalSales=(select sum(PosSales) from #CubeList),a.PosName=b.diqumc
	from #CubeList a left join diqu b on a.PosID=b.diquno

  exec(' select PosID,PosName,PosSales,TotalSales,H0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,'
					+'H11,H12,H13,H14,H15,H16,H17,H18,H19,H20,H21,H22,H23 from  #CubeList '
					+'union all '
					+'select PosID=''合计'',PosName=''合计'',PosSales=sum(PosSales),TotalSales=(select sum(PosSales) from #CubeList), '
					+'H0=sum(isnull(H0,0)),H1=sum(isnull(H1,0)),H2=sum(isnull(H2,0)),H3=sum(isnull(H3,0)),H4=sum(isnull(H4,0)),H5=sum(isnull(H5,0)),H6=sum(isnull(H6,0)),'
					+'H7=sum(isnull(H7,0)),H8=sum(isnull(H8,0)),H9=sum(isnull(H9,0)),H10=sum(isnull(H10,0)),H11=sum(isnull(H11,0)),'
					+'H12=sum(isnull(H12,0)),H13=sum(isnull(H13,0)),H14=sum(isnull(H14,0)),H15=sum(isnull(H15,0)),H16=sum(isnull(H16,0)),'
					+'H17=sum(isnull(H17,0)),H18=sum(isnull(H18,0)),H19=sum(isnull(H19,0)),H20=sum(isnull(H20,0)),H21=sum(isnull(H21,0)),'
					+'H22=sum(isnull(H22,0)),H23=sum(isnull(H23,0))'

					+'from #CubeList ')
end


GO
