

/*
[p_GetSales_byHour_guizu] '2012-01-01','2012-01-31',''
*/




CREATE       procedure [dbo].[p_GetSales_byHour_guizu]
@datetime1 datetime,
@datetime2 datetime,
@orderbyField varchar(32)
as
begin
  select cSaleSheetno=guizuno,fLastSettle=sum(isnull(Jine,0)),dSaleDate=Lsriqi,cSaleTime=lstime
	into #jiesuan
	from lsdsp
	where Lsriqi between @datetime1-1 and @datetime2+1
	group by guizuno,Lsriqi,lstime

	select lsdno=a.cSaleSheetno,shishou=a.fLastSettle,zdriqi=a.dSaleDate,PosID=a.cSaleSheetno,
				 Hourpart=datepart(hh,cast('2000-01-01 '+a.cSaleTime as datetime)) 
	into #lsd_temp 
	from #jiesuan a 
	where a.dSaleDate between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)

	select a.PosID,PosSales=isnull((select sum(shishou) from #lsd_temp where PosID=a.PosID),0),
				 a.Hourpart,HourPartSales=sum(a.shishou)
	into #lsd_temp_1
	from #lsd_temp a  
	group by a.PosID,a.Hourpart

--select * from #lsd_temp_1 order by PosID,Hourpart

	create table #CubeList
	(
		PosID varchar(32),PosSales money,TotalSales money,H0 money,H1 money,H2 money,H3 money,H4 money,H5 money,H6 money,
		H7 money,H8 money,H9 money,H10 money,H11 money,H12 money,H13 money,H14 money,H15 money,H16 money,
		H17 money,H18 money,H19 money,H20 money,H21 money,H22 money,H23 money
	) 
  declare @PosID varchar(32) 
  declare @PosSales Money
	declare @HourPart int
	declare @HourPartSales money

	declare crCubeList cursor
	for
	select PosID,PosSales,Hourpart,HourPartSales from #lsd_temp_1 

  open crCubeList
	fetch next from crCubeList
	into @PosID,@PosSales,@Hourpart,@HourPartSales

	declare @strtmpPosID varchar(32)
	declare @strtmpPosSales varchar(32)
	declare @strtmpHourpart varchar(2)
	declare @strtmpHourPartSales varchar(32)
   
	while @@fetch_status=0 
	begin
		if (select count(PosID) from #CubeList where PosID=@PosID)=0
		begin
			insert into #CubeList (PosID,PosSales) values (@PosID,@PosSales)
		end 

		  set @strtmpHourpart=dbo.trim(cast(@Hourpart as varchar(2)))
		  set @strtmpPosID=@PosID
		  set @strtmpPosSales=cast(@PosSales as varchar(32))
		  set @strtmpHourPartSales=cast(@HourPartSales as varchar(32))

    	exec('update #CubeList set H'+@strtmpHourpart+'='+@strtmpHourPartSales+'
              where PosID='''+@PosID+'''

					')
		
		fetch next from crCubeList
		into @PosID,@PosSales,@Hourpart,@HourPartSales
	end

 	CLOSE crCubeList
  DEALLOCATE crCubeList

  update #CubeList set TotalSales=(select sum(PosSales) from #CubeList)


  if dbo.trim(@orderbyField)<>'' 
  begin
 		exec(' select a.PosID,mingcheng=b.guizu,a.PosSales,a.TotalSales,a.H0,a.H1,a.H2,a.H3,a.H4,a.H5,a.H6,a.H7,a.H8,a.H9,a.H10,'
					+'a.H11,a.H12,a.H13,a.H14,a.H15,a.H16,a.H17,a.H18,a.H19,a.H20,a.H21,a.H22,a.H23 from  #CubeList a left join guizu b on a.PosID=b.guizuno '
					+'union all '
					+'select PosID=''合计'',mingcheng=null,PosSales=sum(PosSales),TotalSales=(select sum(PosSales) from #CubeList), '
					+'H0=sum(isnull(H0,0)),H1=sum(isnull(H1,0)),H2=sum(isnull(H2,0)),H3=sum(isnull(H3,0)),H4=sum(isnull(H4,0)),H5=sum(isnull(H5,0)),H6=sum(isnull(H6,0)),'
					+'H7=sum(isnull(H7,0)),H8=sum(isnull(H8,0)),H9=sum(isnull(H9,0)),H10=sum(isnull(H10,0)),H11=sum(isnull(H11,0)),'
					+'H12=sum(isnull(H12,0)),H13=sum(isnull(H13,0)),H14=sum(isnull(H14,0)),H15=sum(isnull(H15,0)),H16=sum(isnull(H16,0)),'
					+'H17=sum(isnull(H17,0)),H18=sum(isnull(H18,0)),H19=sum(isnull(H19,0)),H20=sum(isnull(H20,0)),H21=sum(isnull(H21,0)),'
					+'H22=sum(isnull(H22,0)),H23=sum(isnull(H23,0))'

					+'from #CubeList order by '+@orderbyField)
  end else
	begin
 		exec(' select a.PosID,mingcheng=b.guizu,a.PosSales,a.TotalSales,a.H0,a.H1,a.H2,a.H3,a.H4,a.H5,a.H6,a.H7,a.H8,a.H9,a.H10,'
					+'a.H11,a.H12,a.H13,a.H14,a.H15,a.H16,a.H17,a.H18,a.H19,a.H20,a.H21,a.H22,a.H23 from  #CubeList a left join guizu b on a.PosID=b.guizuno '
					+'union all '
					+'select PosID=''合计'',mingcheng=null,PosSales=sum(PosSales),TotalSales=(select sum(PosSales) from #CubeList), '
					+'H0=sum(isnull(H0,0)),H1=sum(isnull(H1,0)),H2=sum(isnull(H2,0)),H3=sum(isnull(H3,0)),H4=sum(isnull(H4,0)),H5=sum(isnull(H5,0)),H6=sum(isnull(H6,0)),'
					+'H7=sum(isnull(H7,0)),H8=sum(isnull(H8,0)),H9=sum(isnull(H9,0)),H10=sum(isnull(H10,0)),H11=sum(isnull(H11,0)),'
					+'H12=sum(isnull(H12,0)),H13=sum(isnull(H13,0)),H14=sum(isnull(H14,0)),H15=sum(isnull(H15,0)),H16=sum(isnull(H16,0)),'
					+'H17=sum(isnull(H17,0)),H18=sum(isnull(H18,0)),H19=sum(isnull(H19,0)),H20=sum(isnull(H20,0)),H21=sum(isnull(H21,0)),'
					+'H22=sum(isnull(H22,0)),H23=sum(isnull(H23,0))'
 
					+'from #CubeList order by PosID')
  end
end


GO
