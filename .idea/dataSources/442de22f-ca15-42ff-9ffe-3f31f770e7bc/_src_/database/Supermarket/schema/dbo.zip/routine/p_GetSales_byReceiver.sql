




CREATE    procedure [dbo].[p_GetSales_byReceiver]
@datetime1 datetime,
@datetime2 datetime,
@orderbyField varchar(32)
as
begin
  select lsdno=sheetno,shishou=sum(isnull(shishou,0)),xsyno=shouyinyuanno,xsy=shouyinyuanmc,zdriqi
	into #jiesuan
	from jiesuan
	where zdriqi between @datetime1-1 and @datetime2+1
	group by sheetno,shouyinyuanno,shouyinyuanmc,zdriqi 


/*
	select a.lsdno ,a.shishou ,a.zdriqi,PosID=b.PosName,a.xsyno,a.xsy
	into #lsd_temp 
	from v_lsd a left join dbo.t_posstation b
							 on substring(a.lsdno,1,2)=b.posid
	where a.zdriqi between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)
*/
	select a.lsdno ,a.shishou ,a.zdriqi,PosID=b.PosName,a.xsyno,a.xsy
	into #lsd_temp 
	from #jiesuan a left join dbo.posstation b
							 on substring(a.lsdno,1,2)=b.posid
	where a.zdriqi between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)

	select xsyno,xsy,PosID,shishou=sum(shishou),TotalSales=cast(0.0 as money)
	into #lsd_temp_1
	from #lsd_temp
	group by xsyno,xsy,PosID 

  update #lsd_temp_1 set TotalSales=isnull((select sum(isnull(shishou,0)) from #lsd_temp_1),0)

  if dbo.trim(@orderbyField)<>'' 
  begin
	  exec(' select * from  #lsd_temp_1 order by '+@orderbyField)
  end else
	begin
	  exec(' select * from  #lsd_temp_1 order by  xsyno')
	end

end


GO
