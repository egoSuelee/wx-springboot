CREATE proc [dbo].[p_GetSpxx]
@guizuNo varchar(32) ,
@telCode varchar(256)
as
begin
 
 select b.guizu,
 b.guizuno,
 pinpai,
 pinpaino,
 cSpno_POS, -- 专区内部码
 Dw1, -- 货号
 SpNo,
 Mingcheng,
 Bzjj, -- 进价
 Bzlsj,-- 零售价
 Danwei,
 guige
 from spxx a,guizu b,GuizuNo_TelCode c
	where a.guizuno=b.guizuno and b.guizuno=@guizuNo and c.guizuno=b.guizuno
	and c.TelCode=@telCode
end
GO
