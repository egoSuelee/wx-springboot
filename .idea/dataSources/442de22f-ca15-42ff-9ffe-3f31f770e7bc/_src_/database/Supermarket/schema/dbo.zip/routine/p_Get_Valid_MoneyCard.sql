create procedure p_Get_Valid_MoneyCard
@CardNo varchar(32),
@cPsw varchar(32)
as
begin
 select a.iCheckDigit,a.cardtype,a.cPsw,a.bOld,a.iLineNo,a.cLockStr,a.cLockSeed,a.pidno,a.cardno,
 a.cardtype,a.name ,a.sex,a.birthday,a.danwei,a.zhiwu,a.home,a.tel,a.yhl,a.curvalue,a.usehyj,
 a.orientmoney,a.custmoney,a.leftmoney,bLimitPrice=isnull(b.bLimitPrice,0),fLimitPrice=isnull(b.fLimitPrice,0)
  from supermarket.dbo.moneycard a 
  left join supermarket.dbo.moneycard_type b on a.iCardtypeID=b.iCardtypeID
  where isnull(a.Deleted,0)=0 and isnull(a.bSaled,0)=1 and isnull(a.bReturned,0)=0 and isnull(a.locked,0)=0
  and a.cardno=@CardNo and a.cPsw=@cPsw
         and dbo.getDayStr(getdate()) between cast(a.date1 as datetime) and cast(a.date2 as datetime)
end
GO
