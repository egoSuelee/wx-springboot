/*
  p_GetquPinpai_paihang '2011-03-01','2011-03-01','d8d21c08a448c63a'
*/

CREATE PROCEDURE [dbo].[p_GetquPinpai_paihang]
@date1 datetime,
@date2 datetime,
@qu varchar(64)--,
--@strserver varchar(32)  '+@strserver+'.
AS
BEGIN
--if (select object_id('tempdb..#tempQu')) is not null
--   drop table #tempQu
--  select F1 as quno into #tempQu from dbo.SplitStr(@qu,'@')
exec(
'if (select object_id(''tempdb..#tempQu''))is not null
			drop table #tempQu 
			select guizuno as quno into #tempQu  from Temp_SupKey.dbo.temp_TypeTree'+@qu+'

if (select object_id(''tempdb..#tempQuPinpai'')) is not null
drop table #tempQuPinpai
if (select object_id(''tempdb..#tempPinpaiShuliang'')) is not null
drop table #tempPinpaiShuliang
select  a.quno,a.qu,b.pinpaino,b.pinpai
into #tempQuPinpai
from guizu a left join t_pinpai b 
on a.guizuno=isnull(b.guizuno,'''')
where a.quno in(
               select quno from #tempQu
               )
select pinpaino,quno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #tempPinpaiShuliang
from v_lsdsp_qu
where lsriqi between '''+@date1+''' and '''+@date2+'''
and quno in(
               select quno from #tempQu
            )
group by quno,pinpaino

select a.quno as 区域编号,a.qu as 区域名称,a.pinpaino as 品牌编号,a.pinpai as 品牌名称,isnull(b.shuliang,0) as 销售数量,
isnull(b.jine,0) as 销售金额

from #tempQuPinpai a left join #tempPinpaiShuliang b
on a.quno=b.quno and a.pinpaino=b.pinpaino
order by a.quno,b.shuliang desc,a.pinpaino
')

END
GO
