/*
  p_GetquPinpai_xiaoshou_web '2010-03-28','2011-03-28','8d21c08a448c63a'
*/

CREATE PROCEDURE [dbo].[p_GetquPinpai_xiaoshou_web]
@date1 datetime,
@date2 datetime,
@qu varchar(64)--,
--@strserver varchar(32)'+@strserver+'.
AS
BEGIN
--if (select object_id('tempdb..#tempQu')) is not null
--   drop table #tempQu
--  select F1 as quno into #tempQu from dbo.SplitStr(@qu,'@')
exec(
'if (select object_id(''tempdb..#tempQu''))is not null
			drop table #tempQu 
			----------------------------------------服务器名
			select guizuno as quno into #tempQu  from Temp_SupKey.dbo.temp_TypeTree'+@qu+'
			
			--select quno from #tempQu
			union
            select diquno as quno from v_diqu_guizu where cParentNo in (select guizuno from Temp_SupKey.dbo.temp_TypeTree'+@qu+')


--select * from v_diqu_guizu
--select * from temp_supkey.dbo.temp_TypeTreed8d21c08a448c63a
if (select object_id(''tempdb..#tempPinpaiGuizushuliang'')) is not null
drop table #tempPinpaiGuizushuliang
select pinpaino,guizuno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #tempPinpaiGuizushuliang
from v_lsdsp_qu
where lsriqi between '''+@date1+''' and '''+@date2+'''
and guizuno in(
               select quno from #tempQu
              )
group by guizuno,pinpaino



select a.guizuno as 商户编号,a.guizu as 商户名称,a.pinpaino as 品牌编号,a.pinpai as 品牌名称,isnull(b.shuliang,0) as 销售数量,isnull(b.jine,0) as 销售金额
from t_pinpai a left join #tempPinpaiGuizushuliang b
on a.pinpaino=b.pinpaino and a.guizuno=b.guizuno
where a.guizuno in(
               select quno from #tempQu
                   )
order by a.guizuno,shuliang desc,a.pinpaino
')
END
GO
