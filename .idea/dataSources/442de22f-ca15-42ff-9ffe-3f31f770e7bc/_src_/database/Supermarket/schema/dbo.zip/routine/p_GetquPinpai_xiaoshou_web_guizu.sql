/*
  p_GetquPinpai_xiaoshou_web_guizu '2010-03-28','2011-03-28','20402'
*/

CREATE PROCEDURE [dbo].[p_GetquPinpai_xiaoshou_web_guizu]
@date1 datetime,
@date2 datetime,
@qu varchar(32)  --guizuno
AS
BEGIN
--if (select object_id('tempdb..#tempQu')) is not null
--   drop table #tempQu
--  select F1 as quno into #tempQu from dbo.SplitStr(@qu,'@')
exec(
'
if (select object_id(''tempdb..#tempPinpaiGuizushuliang'')) is not null
drop table #tempPinpaiGuizushuliang
select pinpaino,guizuno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #tempPinpaiGuizushuliang
from v_lsdsp_qu
where lsriqi between '''+@date1+''' and '''+@date2+'''
and guizuno='''+@qu+'''
group by guizuno,pinpaino



select a.guizuno as 商户编号,a.guizu as 商户名称,a.pinpaino as 品牌编号,a.pinpai as 品牌名称,isnull(b.shuliang,0) as 销售数量,isnull(b.jine,0) as 销售金额
from t_pinpai a left join #tempPinpaiGuizushuliang b
on a.pinpaino=b.pinpaino and a.guizuno=b.guizuno
where a.guizuno='''+@qu+'''
order by a.guizuno,shuliang desc,a.pinpaino
')
END
GO
