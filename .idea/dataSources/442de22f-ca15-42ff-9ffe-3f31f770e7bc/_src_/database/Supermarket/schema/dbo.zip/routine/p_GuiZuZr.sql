/*
exec p_GuiZuZr '01','F1-1002'
exec p_GuiZuZr '02','B2-2002'

exec p_GuiZuZr '03','B2-2002'
*/

create proc [dbo].[p_GuiZuZr]
@type varchar(16),
@guizuno varchar(32)
as
begin

	if(@type='01')  --- 转租
	begin
		if exists (select top 1 guizuno from guizu_Zhuanrang where serno=@guizuno order by qianyueriqi desc)
		begin
		select  top 1  a.serno,a.guizu,guizuno=a.serno,a.themanager,a.thetel,a.shenfenzheng,a.dianhua,jyfw=a.jytype,a.mianji,
		 qixian1=convert(varchar(100),a.qixian1,23),qixian2=convert(varchar(100),a.qixian2,23),a.leixing,qimanager=b.guizu  
		 from guizu_Zhuanrang a,guizu b  where a.serno=b.guizuno and  a.serno=@guizuno order by qianyueriqi desc
		 end 
		 else 
		 begin
		 select serno=a.guizuno,b.guizu,b.guizuno,b.themanager,b.thetel,shenfenzheng='',a.dianhua,jyfw=a.jingyingfanwei,
		 a.mianji,qixian1=convert(varchar(100),a.qixian1,23),qixian2=convert(varchar(100),a.qixian2,23) ,leixing='--',qimanager=guizu   from shanghu_hetong a,guizu b 
		 where a.serno=b.serno and b.guizuno=@guizuno
		 end
	end
	if(@type='02')  --- 转让
	begin
		if exists (select top 1 serno from guizu_Zr where serno=@guizuno order by id desc)
		begin
		select  top 1  a.serno,guizu=a.NewName,b.guizuno,themanager=a.NewName,thetel=a.NewTel,shenfenzheng=a.NewShenfenzheng,dianhua=a.NewTel,jyfw=a.jytype,mianji=b.mianji,
		 qixian1=convert(varchar(100),b.qixian1,23),qixian2=convert(varchar(100),b.qixian2,23),b.leixing,qimanager=b.mingcheng
		from guizu_Zr a,shanghu_hetong b   where a.serno=b.guizuno and  a.serno=@guizuno order by id desc
		
		--select * from guizu_Zr order by id desc
		--select * from shanghu_hetong where guizuno='F1-1001'
		 end 
		 else 
		 begin
		 select serno=b.guizuno,b.guizu,b.guizuno,b.themanager,b.thetel,shenfenzheng='',a.dianhua,jyfw=a.jingyingfanwei,
		 a.mianji,qixian1=convert(varchar(100),a.qixian1,23),qixian2=convert(varchar(100),a.qixian2,23) ,leixing='--',qimanager=b.guizu   from shanghu_hetong a,guizu b 
		 where a.serno=b.serno and b.guizuno=@guizuno
		end
	end
	if(@type='03')  --- 自营
	begin	
		 select serno=b.guizuno,b.guizuno,b.guizu,b.themanager,b.thetel,shenfenzheng='',a.dianhua,jyfw=a.jingyingfanwei,
		 a.mianji,a.qixian1,a.qixian2 ,leixing='--',qimanager=b.guizu    from shanghu_hetong a,guizu b 
		 where a.serno=b.serno and b.guizuno=@guizuno
	end
end

/*
select  top 1  serno,guizu,guizuno,themanager,thetel,shenfenzheng,dianhua,jyfw=jytype,mianji,
		 qixian1,qixian2,leixing,qimanager   
		 from guizu_Zhuanrang  order by qianyueriqi desc
 select top 1  serno=a.guizuno,b.guizu,b.guizuno,b.themanager,b.thetel,shenfenzheng='',a.dianhua,jyfw=a.jingyingfanwei,
		 a.mianji,a.qixian1,a.qixian2 ,leixing='--',qimanager=guizu   from shanghu_hetong a,guizu b 
		 where a.serno=b.serno
select  top 1  a.serno,guizu=a.NewName,b.guizuno,themanager=a.NewName,thetel=a.NewTel,shenfenzheng=a.NewShenfenzheng,dianhua=a.NewTel,jyfw=a.jytype,mianji=b.mianji,
		 b.qixian1,b.qixian2,b.leixing,qimanager=a.OldName
		from guizu_Zr a,shanghu_hetong b   where a.serno=b.guizuno order by id desc
	 select top 1 serno=b.guizuno,b.guizuno,b.guizu,b.themanager,b.thetel,shenfenzheng='',a.dianhua,jyfw=a.jingyingfanwei,
		 a.mianji,a.qixian1,a.qixian2 ,leixing='--',qimanager=b.guizu   from shanghu_hetong a,guizu b 
		 where a.serno=b.serno 
		 */
GO
