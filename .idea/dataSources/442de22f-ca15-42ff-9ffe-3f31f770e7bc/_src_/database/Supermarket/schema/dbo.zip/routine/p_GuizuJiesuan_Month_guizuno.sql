


CREATE    procedure p_GuizuJiesuan_Month_guizuno
--@guizuno varchar(32),
@cYear char(4),
@cMonth char(2)
as
begin

	select cYear,cYearEnd,cMonth,dDate1,dDate2,iHolidays,fRight,iDays
	into #tempWeekOfMonth_Finance
	from dbo.t_MonthsOfYearSerno
	where cYear=@cYear and cMonth=@cMonth

	select a.guizuno,a.guizu,a.xiaoshoujine,a.feiyongjine,a.koudianjine,a.xiaoshou_zj,
	a.xiaoshou_tj,a.koudian_zj,a.koudian_tj,a.qita,
	a.jiesuanriqi,a.jiesuanjine,
	b.cYear,b.cYearEnd,b.cMonth
	into #tempGuizuJiesuan
	from 
	(
	  select b.guizuno,b.guizu,b.xiaoshoujine,b.feiyongjine,b.koudianjine,b.xiaoshou_zj,
		b.xiaoshou_tj,b.koudian_zj,b.koudian_tj,b.qita,b.jiesuanjine,
		b.jiesuanriqi
		from guizu_jiesuan b, #temp_guizu c
		where b.guizuno=c.cGuizuNo
	) a,#tempWeekOfMonth_Finance b
	where a.jiesuanriqi between b.dDate1 and b.dDate2 

  select cYear,cYearEnd,cMonth,guizuno,guizu,xiaoshoujine,feiyongjine,koudianjine,xiaoshou_zj,
	xiaoshou_tj,koudian_zj,koudian_tj,qita,jiesuanjine,jiesuanriqi
	from #tempGuizuJiesuan
	union all
	select cYear,cYearEnd,cMonth='期末',guizuno='总计:',guizu=null,xiaoshoujine=sum(xiaoshoujine),
	feiyongjine=sum(feiyongjine),koudianjine=sum(koudianjine),xiaoshou_zj=sum(xiaoshou_zj),
	xiaoshou_tj=sum(xiaoshou_tj),koudian_zj=sum(koudian_zj),koudian_tj=sum(koudian_tj),
	qita=sum(qita),jiesuanjine=sum(jiesuanjine),jiesuanriqi=null
	from #tempGuizuJiesuan
	group by cYear,cYearEnd,cMonth
	order by cYear,cYearEnd,cMonth,guizuno,jiesuanriqi
	

	

end

/*
 p_GuizuJiesuan_Month_guizuno  '210070','2006','06'
*/



GO
