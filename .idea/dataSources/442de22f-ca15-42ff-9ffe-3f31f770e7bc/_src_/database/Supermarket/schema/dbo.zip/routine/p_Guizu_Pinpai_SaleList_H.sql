/*
只能 查询30*3=90天的数据，否则表头过长
*/

/*
exec [p_Guizu_Pinpai_SaleList_H] '','2012-01-01','2012-01-03'
*/

CREATE   procedure [dbo].[p_Guizu_Pinpai_SaleList_H]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime
as
SET  NOCOUNT ON
begin
  /*生成报表的列*/

  select detail='['+dbo.getDayStr(Zdriqi)+']',Shishou=SUM(isnull(shishou,0))
	into #jiesuan_detail
	from lsd
  where Zdriqi between @date1 and  @date2 
  and guizuno in (select guizuno=quno from #tempQu)
  group by Zdriqi

	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='detail_cursor')
	begin
		close detail_cursor
		deallocate detail_cursor
	end 
	
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail
  order by detail


  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail

  create table #account_detail
  (
     柜组编号 varchar(32) COLLATE Chinese_PRC_CI_AS ,
     柜组名称 varchar(64) COLLATE Chinese_PRC_CI_AS 
  
     --,品牌编号 varchar(32) COLLATE Chinese_PRC_CI_AS 
     --,品牌名称 varchar(64) COLLATE Chinese_PRC_CI_AS 
	)

  declare @cAddFields varchar(8000)
  set @cAddFields=''
  declare @strtmp varchar(8000)
  set @strtmp=''
  declare @strtmp_group varchar(8000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(8000)
  set @strtmp_Clear='update #account_detail_last set '



  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+@detail+' money,'
    set @strtmp=@strtmp+'0,'
    set @strtmp_group=@strtmp_group+@detail+'=sum(cast('+@detail+' as money)) ,'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then 0 else '+@detail+' end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+'合计 money'
  set @strtmp=@strtmp+'0'
  set @strtmp_group=@strtmp_group+'合计=sum(isnull(cast(合计 as money),0))'
  set @strtmp_Clear=@strtmp_Clear+'合计=case when cast(合计 as money)=0 then 0 else 合计 end'
--  print @strtmp_group


  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor


   --select * into ##account_detail from #account_detail



	select shouyinyuanno=guizuno,shouyinyuanmc=CAST(null as varchar(64)),
	detail='['+dbo.getdaystr(zdriqi)+']',Shishou=SUM(isnull(shishou,0))
  into #jiesuan
	from lsd
	where zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
  and guizuno in (select guizuno=quno from #tempQu)
	group by  guizuno,zdriqi
	order by zdriqi,guizuno
	
	update a set a.shouyinyuanmc=SUBSTRING(b.guizu,1,64) 
	from #jiesuan a,guizu b
	where a.shouyinyuanno=b.guizuno
 

 
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,shishou=cast(shishou as char(32))
  from #jiesuan
  order by detail,shouyinyuanno,shouyinyuanmc

  
 
  select shouyinyuanno,shouyinyuanmc,shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  group by shouyinyuanno,shouyinyuanmc
  

  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou



  while @@fetch_status=0
  begin
		if (select 柜组编号 from #account_detail 
				where 柜组编号=@shouyinyuanno and 柜组名称=@shouyinyuanmc) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 柜组编号='''+@shouyinyuanno+'''  and 柜组名称='''+@shouyinyuanmc+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.柜组编号=b.shouyinyuanno and a.柜组名称=b.shouyinyuanmc 


 
  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 柜组编号=''总计'',柜组名称=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
 
    +' select * from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 柜组编号='''+@guizuno+''' '+'
    
    union all
    select 柜组编号=''总计'',柜组名称=null,'+@strtmp_group
    +' from #account_detail where 柜组编号='''+@guizuno+''' '
    +@strtmp_Clear
    +' select * from #account_detail_last')
  end

	if (select OBJECT_ID('tempdb..#account_detail'))is not null
	drop table #account_detail
	if (select OBJECT_ID('tempdb..#jiesuan_heji'))is not null
	drop table #jiesuan_heji

	if (select OBJECT_ID('tempdb..#jiesuan'))is not null
	drop table #jiesuan
	
	if (select OBJECT_ID('tempdb..#jiesuan_detail'))is not null
	drop table #jiesuan_detail
	

end


GO
