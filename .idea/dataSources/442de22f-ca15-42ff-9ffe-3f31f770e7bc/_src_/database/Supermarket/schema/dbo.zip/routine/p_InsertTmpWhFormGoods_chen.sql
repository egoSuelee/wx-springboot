create proc p_InsertTmpWhFormGoods_chen
@GoodsTable varchar(32),
@cIp varchar(20)
as

delete t_TmpWhForm where cip=@cIp --and cGoodsNo=@cGoodsNo
exec('
	  insert into t_TmpWhForm
	  (
		 dDate,cGoodsNo,cIp
	  )
	  select dbo.getDayStr(getdate()),cGoodsNo,'''+@cIp+'''
	  from '+@GoodsTable
    )
/*
select * from t_TmpWhForm

create table #tmp
(cgoodsNo varchar(32))
insert into #tmp(cgoodsno) select '10101' union all select '10102'


p_InsertTmpWhFormGoods_chen '#tmp','192.168.1.100'

*/
GO
