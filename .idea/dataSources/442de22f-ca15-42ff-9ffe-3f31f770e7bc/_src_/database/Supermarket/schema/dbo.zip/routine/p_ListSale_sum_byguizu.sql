


/*
select cGuizuNo=guizuno into #temp_guizu from guizu

p_ListSale_sum_byguizu '','2007-05-01','2007-05-30'

*/

CREATE      procedure p_ListSale_sum_byguizu
@guizuno varchar(32),
@date1 datetime,
@date2 datetime
as
begin



  /*生成报表的列*/
	select lsdno='销售',a.guizuno,a.guizu,a.zdriqi,shishou=sum(a.shishou)
	into #templsd
	from lsd a,#temp_guizu b
	where a.zdriqi between @date1 and @date2
				and a.guizuno=b.cGuizuNo-- in (select guizuno=cGuizuNo from #temp_guizu)
	group by guizuno,guizu,zdriqi
	union all
	select lsdno=a.cGuizuno+b.Guizu,guizuno=a.cGuizuNo,b.guizu,zdriqi=@date1,shishou=0
	from 	#temp_guizu a left join guizu b on a.cGuizuNo=b.guizuno		

	select shouyinyuanno=guizuno,shouyinyuanmc=guizu,detail='['+dbo.getdaystr(zdriqi)+']',shishou=sum(shishou)
	into #jiesuan
	from #templsd
	where zdriqi between @date1 and @date2
				and guizuno in (select guizuno=cGuizuNo from #temp_guizu)
	group by guizuno,guizu,zdriqi
	order by guizuno,guizu,zdriqi

	select detail,shishou=sum(shishou)
	into #jiesuan_detail
	from #jiesuan
	group by detail
	order by detail


 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
--  declare @zdriqi varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail

  create table #account_detail
  (
     柜组No varchar(32),
     柜组名称 varchar(64)
	)

  declare @cAddFields varchar(8000)
  set @cAddFields=''
  declare @strtmp varchar(8000)
  set @strtmp=''
  declare @strtmp_group varchar(8000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(8000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
--    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @cAddFields=@cAddFields+@detail+' Money,'

--    set @strtmp=@strtmp+'''0'','
    set @strtmp=@strtmp+'0,'

--    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
--    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
    set @strtmp_group=@strtmp_group+@detail+'=sum(cast('+@detail+' as money)) ,'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when '+@detail+'=0 then null else '+@detail+' end,'

		fetch next from detail_cursor
    into @detail
  end
--  set @cAddFields=@cAddFields+' 合计 varchar(32)'
--  set @strtmp=@strtmp+'''0'''
--  set @strtmp_group=@strtmp_group+' 合计=cast(sum(cast(合计 as money)) as varchar(32))'
--  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'

  set @cAddFields=@cAddFields+' 合计 money'
  set @strtmp=@strtmp+'0'
  set @strtmp_group=@strtmp_group+' 合计=sum(cast(合计 as money))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then null else 合计 end'


  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor
/*
	select shouyinyuanno=guizuno,shouyinyuanmc=guizu,detail='['+dbo.getdaystr(zdriqi)+']',shishou=sum(shishou)
	into #jiesuan
	from lsd
	where zdriqi between @date1 and @date2
	group by guizuno,guizu,zdriqi
	order by guizuno,guizu,zdriqi
*/
  
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,shishou=cast(shishou as char(32))
  from #jiesuan
  order by shouyinyuanno,shouyinyuanmc,detail
 
--  select shouyinyuanno,shouyinyuanmc,shishou=cast(sum(isnull(shishou,0)) as char(32))
  select shouyinyuanno,shouyinyuanmc,shishou=sum(isnull(shishou,0))
  into #jiesuan_heji
  from #jiesuan
  group by shouyinyuanno,shouyinyuanmc
  
  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(64)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou


  while @@fetch_status=0
  begin
		if (select 柜组No from #account_detail 
				where 柜组No=@shouyinyuanno and 柜组名称=@shouyinyuanmc) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','+@strtmp)
    end

--    exec('update #account_detail set '+@detail+'=dbo.LeftAddChar(dbo.trim('''+@shishou
--					+'''),'' '',12) where 柜组No='''+@shouyinyuanno+''' and 柜组名称='''+@shouyinyuanmc+'''')
    exec('update #account_detail set '+@detail+'='+@shishou
					+' where 柜组No='''+@shouyinyuanno+''' and 柜组名称='''+@shouyinyuanmc+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

--  update a set a.合计=dbo.trim(b.shishou)
  update a set a.合计=b.shishou
  from #account_detail a
  left join #jiesuan_heji b
  on a.柜组No=b.shouyinyuanno and a.柜组名称=b.shouyinyuanmc


 
  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 柜组No=''总计'',柜组名称=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select 序号='''', * from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 柜组No='''+@guizuno+''' '+'
    
    union all
    select 柜组No=''总计'',柜组名称=null,'+@strtmp_group
    +' from #account_detail where 柜组No='''+@guizuno+''' '
    +@strtmp_Clear
    +' select 序号='''',* from #account_detail_last')
  end
  --exec(@strtmp_Clear)

end


GO
