CREATE procedure p_Log
@userno varchar(32),
@username varchar(64),
@operation varchar(1024),

@stationname varchar(64)
as
begin
  IF (EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.tables
     WHERE TABLE_NAME ='t_Log'))
  begin
    insert into t_Log(userno ,username,operation,operTime,stationname)
    values (@userno ,@username,@operation,getdate(),@stationname)
	end
end

GO
