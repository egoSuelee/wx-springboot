
/*

drop table ##temp_p_Map_Sale
exec p_Map_Sale '2011-05-13','2011-05-31','',100,'',''

select * from ##temp_p_Map_Sale

*/

CREATE  procedure [dbo].[p_Map_Sale]
@date1 datetime,
@date2 datetime,
@guizuno varchar(32)/*空 表示所有所有商户*/,
@Ratio money,
--@spno varchar(32)/*空 表示所有商品*/
@jingyingfangshi varchar(32),
@kind varchar(32),
@iBest int,
@iBetter int,
@iNormal int,
@iCare int,
@iBad int
as
begin
/*
  if (select object_id('tempdb..#tempTypeNo')) is not null
  drop table #tempTypeNo

  create table #tempTypeNo(typeno varchar(64))

	declare @cNode varchar(64)
	declare @Fieldname varchar(64)
	declare @Fieldname_parent varchar(64)
	declare @TableName varchar(64)
	declare @bBoolean char(1)--是否显示非叶子节点
	set @cNode=dbo.trim(@quno)
	set @Fieldname='diquno'
	set @Fieldname_parent='cParentNo'
	set @TableName='diqu'
	set @bBoolean='1'
	insert into #tempTypeNo(typeno)
  exec supermarket.dbo.p_GetChildren @cNode,@Fieldname,@Fieldname_parent,@TableName,@bBoolean
*/		
  set @jingyingfangshi='<全部>'
  set @kind='<全部>'
  set  @guizuno='<全部>'
  	
    select a.guizuno,a.guizu
    into #guizu
    from guizu a
    where (a.quno in (select dbo.f_getLaststrBySeparator_R(cPath,'.')  from ##tempPath_quno_inner) )
          and (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' )
          and a.guizuno in (select distinct guizuno from spxx 
                            where kind=@kind or @kind='<全部>' )
          and (a.guizuno=@guizuno or @guizuno='<全部>')

  select guizuno,			 
         fSaleMoney=sum(isnull(jine,0.0)) 
  into #lsdsp_sales
	from lsdsp
  where lsriqi between @date1 and @date2
        and (guizuno in (select guizuno from #guizu )) 
  group by guizuno


  set @Ratio=@Ratio/100.0
  
  select fSumSales=isnull(sum(fSaleMoney),1)
  into #lsdsp_sales_sumBySpno
  from #lsdsp_sales

  if (select top 1 fSumSales from #lsdsp_sales_sumBySpno )=0 
  begin
   select guizuno='ZZZZZZZZ'
   return
  end  

  select a.guizuno,a.fSaleMoney,b.fSumSales,
				 Ratio=(a.fSaleMoney/(b.fSumSales/1.0)),Ratio_left=-100.00000000000000000
  into #lsdsp_sales_Ratio
  from #lsdsp_sales a
  left join #lsdsp_sales_sumBySpno b
  on 1=1

  select * 
  into #lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio

  declare cursor_Ratio cursor
  for  
  select guizuno,Ratio
  from #lsdsp_sales_Ratio
  order by fSaleMoney desc

	open cursor_Ratio

  declare @guizuno_old varchar(32)
  declare @Ratio_left money
  set @Ratio_left=@Ratio

 
	declare @guizuno_c varchar(32)
  declare @Ratio_c float

--print '0:'+cast(@Ratio as varchar(32))
  
  Fetch next from cursor_Ratio
  into @guizuno_c,@Ratio_c
  
  while @@Fetch_status = 0
  begin
/*
    if (@iYear_c<>@iYear_old) or (@iMonth_c<>@iMonth_old)
    begin
      set @Ratio_left=@Ratio
    end
*/
    update #lsdsp_sales_Ratio_last set Ratio_left=@Ratio_left-Ratio
    where guizuno=@guizuno_c

      
    set @Ratio_left=@Ratio_left-@Ratio_c            



	  Fetch next from cursor_Ratio
    into @guizuno_c,@Ratio_c
  end  

  close cursor_Ratio	 
  deallocate cursor_Ratio
	
	declare @mianji_total money
  select distinct a.guizuno,b.mianji,a.quno
	into #guizu_mianji
	from guizu a,weizhi b
	where a.quno=b.weizhino
	select @mianji_total=case when sum(isnull(mianji,0))=0 then null else sum(isnull(mianji,0)) end 
	from #guizu_mianji
  

  select 柜组编号=a.guizuno,柜组名称=b.guizu,柜组营业额=a.fSaleMoney,总销售额=a.fSumSales,
				 [销售占比(%)]=a.Ratio*100,iSerno=identity(bigint,1,1)
	into #lsdsp_sales_Ratio_last0
  from #lsdsp_sales_Ratio_last a
  left join guizu b
  on a.guizuno=b.guizuno
  where a.Ratio_left>=0 or (a.Ratio_left<=0  and a.Ratio*8.0/10.0>=abs(a.Ratio_left))
  order by a.fSaleMoney desc
  
  declare @iCount int
  set @iCount=(select COUNT(*) from #lsdsp_sales_Ratio_last0)

	insert into #temp_p_Map_Sale
	(guizuno,guizu,fMoney_guizu,f_Money_Total,
	fRatio_Money,fRatio_Area,cColor,f_01 ,f_02 ,f_03 ,f_04 ,c_01 ,c_02,c_03)
	select guizuno=a.柜组编号,guizu=a.柜组名称,fMoney_guizu=a.柜组营业额,f_Money_Total=a.总销售额,
	fRatio_Money=a.[销售占比(%)],fRatio_Area=b.mianji/@mianji_total*100
	,cColor=case when (cast (a.iSerno as money)/@iCount)<=(@iBest/100.0000)then 'clRed'  -----优质商户
	             when (cast (a.iSerno as money)/@iCount) between (@iBest/100.0000)+0.0001 and (@iBetter/100.0000) then 'clYellow'-----良好商户
	             when (cast (a.iSerno as money)/@iCount) between (@iBetter/100.0000)+0.0001 and (@iNormal/100.0000) then 'clGreen'-----一般商户
	             when (cast (a.iSerno as money)/@iCount) between (@iNormal/100.0000)+0.0001 and (@iCare/100.0000) then 'clBlue'-----观察商户
	             else 'clBtnFace'----落后商户
          end,
  f_01=0 ,f_02=0 ,f_03=0 ,f_04=0 ,c_01=null ,c_02=null,c_03=null         	             
	--into ##temp_p_Map_Sale
	from #lsdsp_sales_Ratio_last0 a,#guizu_mianji b
	where a.柜组编号=b.guizuno
	order by a.柜组营业额 desc
  
end


GO
