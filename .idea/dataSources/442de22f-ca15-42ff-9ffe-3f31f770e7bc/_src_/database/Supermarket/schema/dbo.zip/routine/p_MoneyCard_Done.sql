create procedure p_MoneyCard_Done
@cardno varchar(32),
@fCustmoney money,
@cWHno varchar(32),
@dSaleDate datetime,
@cSaleSheetNo varchar(32),
@cOperNo varchar(32), 
  @dSaleDatetime varchar(32),
  @cPosNo varchar(32),
  @fMoney_o money,
  @fLeftMoney_o money,@fLeftMoney money
as
begin
	update supermarket.dbo.moneycard 
	set custmoney=custmoney+@fCustmoney,
	    leftmoney=leftmoney-@fCustmoney,locked=0
	where isnull(Deleted,0)=0 and isnull(bReturned,0)=0 
	      and cardno=@cardno
	insert into supermarket.dbo.Moneycard_Cust_Log 
	(cWHno,cMoneyNo, dSaleDate, cSaleSheetNo, fMoney, cOperNo, dSaleDatetime, 
	cPosNo,fMoney_o,fLeftMoney_o,fLeftMoney)
	values(
  @cWHno,@cardno,@dSaleDate,@cSaleSheetNo,@fCustmoney,@cOperNo, 
  @dSaleDatetime,@cPosNo,@fMoney_o,@fLeftMoney_o,@fLeftMoney	
	)	      
end
GO
