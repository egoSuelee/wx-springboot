
/*
  p_OA_Hetong_BM '22105'   --651009
  
  select * from qp_Messages
  select * from qp_AddWorkFlow
  select * from Supermarket.dbo.guizu where quno='221'
  select * from Supermarket.dbo.shanghu_hetong where serno='34102'
  select * from qp_MyReminded
  insert into qp_MyReminded
  select '是','3000',username,realname from qp_username
  select * from qp_username
  select Supermarket.dbo.MD5('505',32)
  
  delete qp_MyReminded where id<>6 or id<>4
  select * from qp_IfOpen
delete qp_IfOpen where id<>4
insert into qp_ifopen
select 'rform','1.swf','503','503'
  
*/

create PROCEDURE  [dbo].[p_OA_Hetong_BM]
@serno varchar(32)  -- 合同号
AS
BEGIN
/*
 注意:获取的楼层:如一层、二层;   
 在表单设计下的流程名称(qp_WorkFlowName- FlowName)包含一层、二层 词....
  是为了获取相应楼层的相应流程......
*/
   declare @quno varchar(32)  
   ---柜组所在区。  有柜组所在的区 
   ---然后从select * from supermarket.dbo.user_diqu_chen 获取该区的负责人..
    select @quno=quno from supermarket.dbo.guizu where guizuno=(  --- 获取柜组所在的区.... 
    select guizuno from supermarket.dbo.shanghu_hetong where serno=@serno)  --@serno
    --- 获取地区
	if(select object_id('tempdb..#tmp_diqu')) is not null
	begin
		drop table 	#tmp_diqu
	end
	create table #tmp_diqu
	(
	 diquno varchar(32) null,
	 diqumc varchar(32) null,
	 cParentNo varchar(32) null,
	 cPath varchar(500) null
	)
	declare @diqumc varchar(32)
    declare @diquno varchar(32)
	insert INTO   #tmp_diqu Exec   supermarket.dbo.p_GetPath
	--select @diqumc=diqumc,@diquno=diquno from #tmp_diqu 
	 select top 1 @diqumc=diqumc,@diquno=diquno from #tmp_diqu where 
   (CHARINDEX('.'+@quno,'.'+cPath+'')   >   0 )  and cParentNo='--'
--  select @diqumc,@diquno  ---获取地区名称和编号  。。 
--set @diqumc='三层'
declare @BdId int   --- 表单ID
declare @BdName varchar(32)
select @BdId=id,@BdName=FormName from qp_DIYForm where FormName='合同审核'

-----  获取表单建的所有工作流 begion
declare @FlowNumber varchar(500) --- 表单下对应的相应 流程的FlowNumber 号。。    作为页面传值
declare @FormId int   
set @FormId=@BdId    ------------  表单的单号。。 页面传值 到  AddWorkFlow_add  页面
declare @jkUsername varchar(32)  --- 监控人。。。 
set @jkUsername=null
declare @jkRealname varchar(32)
set @jkRealname=null
   select @FlowNumber=FlowNumber, @jkUsername=JkUsername,@jkRealname=JkRealname  from qp_WorkFlowName where 
   (CHARINDEX(',84,',','+FlowUnitId+',')   >   0 )   --- 84 表示 管理员所在的部门  即 工作默认是有管理员建立
   and  FormId=@BdId and FlowName like ''+@diqumc+'%'   ---- 获取相应楼层的 流程

-----end

-------   -- 一下是到 AddWorkFlow_add 页面开始操作。。 
declare @FlowID varchar(32)

declare @Number varchar(64)  --- 


   --select @jkUsername=JkUsername,@jkRealname=JkRealname from qp_WorkFlowName where id=@FormId 
   --and 
   ---- 插入过程中需要的字段值
declare @NumberT varchar(64)
set @NumberT= DateName(year,GetDate())+DateName(month,GetDate())+
DateName(day,GetDate())+DateName(hour,GetDate())+DateName(minute,GetDate())+
DateName(second,GetDate())+CAST(CEILING(RAND()*100) as varchar(32))
declare @lshid varchar(32)
set @lshid=(select top 1 id from qp_AddWorkFlow order by id desc)
if(@lshid is null)
set @lshid='1'
declare @contcontent varchar(128)  -- 自己设计的表单内容
set @contcontent=(select FormContent from qp_DIYForm where id=@FormId)
-------------
 declare @next_time1 varchar(32)
 --set @next_time1=getdate()
set @next_time1=CONVERT(varchar, getdate(), 120 )
   insert into qp_AddWorkFlow (LcNameId,JkUsername,JkRealname,FormId,FormNumber,
   FormName,FlowId,FlowNumber,FlowName,NodeNumber,NodeNum,NodeName,Number,Sequence,Name,
   [State],FileContent,FqUsername,FqRealname,YJBObjectId,YJBObjecName,WGLObjectId,WGLObjecName,
   GZObjectId,GZObjecName,Username,Realname,Unit,UnitId,QxString,Respon,ResponId,NowTimes,
   UpTimeSet,WtUsername,WtRealname,serno) 
   select '0',@jkUsername,@jkUsername,FormId,FormNumber,FormName,FlowId,FlowNumber,FlowName
   ,NodeNumber,NodeNum,NodeName,@NumberT,@lshid,@diqumc+'商户合同:'+@serno+'('+ @next_time1+')','等待送审',@contcontent,
   'admin','管理员','','','','','','','admin','管理员','管理部','84','aaaaa101a','管理员','11'
   ,@next_time1,@next_time1,'','',@serno from qp_WorkFlowNode 
   where NodeSite='开始' and FlowNumber=@FlowNumber
   ---- 设置下一页面的参数
   declare @next_GqUpNodeNumKey varchar(32)   ---第一个参数  值：2, 或者 2,3,
   declare @next_Number varchar(32)  -- 最后一个
   select @next_GqUpNodeNumKey=UpNodeNum from qp_WorkFlowNode 
   where NodeSite='开始' and FlowNumber=@FlowNumber
   set @next_Number=@NumberT
   declare @next_FlowNumber varchar(500)   --- 第二个
   set @next_FlowNumber=@FlowNumber
   declare @next_FormID bigint   --- 第三个参数
   set @next_FormID=@BdId
   
------------ 以上是由发起人（管理员）开始步骤建立工作、  AddWorkFlow_add

------------ 以下是设置下一个审核人是谁（楼层经理）、、 

--select JBRObjectId from qp_WorkFlowNode where id=''  --- 获取节点的经办人，，，
declare @next_id bigint   --- 相应流程节点的ID
declare @next_NodeName varchar(500) --- 相应流程节点的Name
declare @next_jbrID varchar(300)
declare @next_jbrName varchar(300)
set @next_GqUpNodeNumKey=@next_GqUpNodeNumKey+'0'
----  select   *   from  dbo.SplitStr('8,9,4,',',')  分割字符函数
select @next_id=id,@next_NodeName=NodeName,@next_jbrID=JBRObjectId,@next_jbrName=JBRObjectName  
from qp_WorkFlowNode where  NodeNum  in (select * from  dbo.SplitStr(@next_GqUpNodeNumKey,',')) 
and FlowNumber= @next_FlowNumber order by id desc

 --declare @username varchar(32)   -- 审核人
 --declare @realname varchar(32)  --- 
/*
 ---- 从经办人那获取下一级审核人是谁.. 

 declare @jbrID varchar(254)
 select @jbrID=JBRObjectId from qp_WorkFlowNode where id=@next_id
 select @username=username,@realname=realname from qp_username  where username  
 in (select * from  dbo.SplitStr(@jbrID,','))   --- 获取审核人。。 

 ----设置经办人和审核人一致
--select @username=JBRObjectId,@realname=JBRObjectName from qp_WorkFlowNode 
--where id=@next_id   --- 获取审核人。。 
*/
 ----- 从部门中获取审核人..   也是针对个人、、  即到下一节点审核权限

 --declare @jbrbmID varchar(128)
 --select @jbrbmID=JBBMObjectId from qp_WorkFlowNode where id=@next_id   ---获取所以参与部门的编号
 --select  @username=username,@realname=realname  from 
 --qp_username  where  UnitId  in (select * from  dbo.SplitStr(@jbrbmID,','))
 --and Username in (select [USER] from supermarket.dbo.user_diqu_chen where diquno=@quno ) ---
 
 ------游标 begin
  declare @jbrbmID varchar(128)
   select @jbrbmID=JBBMObjectId from qp_WorkFlowNode where id=@next_id   ---获取所以参与部门的编号
   declare @next_time varchar(32)
	-- set @next_time=getdate()
	 set @next_time=CONVERT(varchar, getdate(), 120 )
--- 根据部门获取经办人
declare @JusernameID varchar(500)
set @JusernameID=''
declare @Jrealname varchar(500)
set @Jrealname=''
  declare Jbr_cursor cursor
  for
 select  username,realname  from 
 qp_username  where  UnitId  in (select * from  dbo.SplitStr(@jbrbmID,','))
 and Username in (select [USER] from supermarket.dbo.user_diqu_chen where diquno=@quno ) ---
 
   declare @username varchar(32)   -- 审核人
   declare @realname varchar(32)  --- 

  open Jbr_cursor
  fetch next from Jbr_cursor
  into @username,@realname

  while @@fetch_status=0
  begin
  
     -----插入消息表中。。 
	 insert into qp_Messages  
	 (title,content,itimes,acceptusername,acceptrealname,sendusername,sendrealname,sfck,url,number) 
	 values 
	 ('有新工作：['+@diqumc+'商户合同编号：'+@serno+'('+ @next_time+')'+']需要办理','有新工作：['+@diqumc+'商户合同编号：'+@serno+'('+ @next_time+')'+']需要办理',
	 @next_time,@username,@realname,'系统消息','系统消息','否',
	 'Superhtfy/WebOAList.aspx?sh=0',
	 DateName(year,GetDate())+DateName(month,GetDate())+
	DateName(day,GetDate())+DateName(hour,GetDate())+DateName(minute,GetDate())+
	DateName(second,GetDate()))
	set @JusernameID=@JusernameID+@username+','
	set @Jrealname=@Jrealname+@realname+','
    fetch next from Jbr_cursor
		into @username,@realname     
  end

  close Jbr_cursor
  deallocate Jbr_cursor 
 ------ end
 

     --- 此用户表与系统用户表一致：即 username 对应的是 user 用户名
 ---   从部门中获取... 
 ----  点击确定、、 

 Update aaa  Set aaa.SpChoice=bbb.SpChoice,
 aaa.State='等待办理',aaa.JBRObjectId=@JusernameID,aaa.JBRObjectName=@Jrealname,
 aaa.JBBMObjectId=bbb.JBBMObjectId,aaa.JBBMObjectName=bbb.JBBMObjectName,
 aaa.SpModle=bbb.SpModle,aaa.EndtimeSet=bbb.EndtimeSet,
 aaa.UpNodeNumber=bbb.NodeNumber,aaa.UpNodeId=bbb.id,
 aaa.UpNodeNum=bbb.NodeNum,aaa.UpNodeName=bbb.NodeName
 from qp_AddWorkFlow aaa,qp_WorkFlowNode bbb 
 where Number=@next_Number and bbb.id=@next_id
 
--  select * from qp_Messages

END
GO
