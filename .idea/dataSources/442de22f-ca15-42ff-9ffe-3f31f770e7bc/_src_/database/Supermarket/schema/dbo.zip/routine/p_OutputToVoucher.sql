

CREATE   procedure p_OutputToVoucher
@date1 datetime,
@date2 datetime,
@serno varchar(16),
@zdr varchar(16),
@guizuno varchar(32)
as
begin
/*
t_zwpzk
t_zwpzfl
t_zwfzys
*/
  declare @F_PZRQ varchar(8)
	set @F_PZRQ=dbo.getDayStr_noseparator(@date2)
  set @serno=dbo.LeftAddChar(dbo.trim(@serno),'0',5)
  insert into t_zwpzk (F_PZRQ,F_PZBH,F_LXBH,F_ZDR,F_BZ)
  values (@F_PZRQ,@serno,'0',@zdr,'0')

--select * from t_zwpzk

  select detail,guizuno,F_JE=round(cast(isnull(sum(isnull(shishou,0)),0) as money),2),spno=space(32),
				F_PZBH=@serno,F_FLBH=space(16),F_KMBH=space(32),F_ZY=space(64),F_JZFX='1',F_YWRQ=@F_PZRQ,bTax=0,
				F_XM01=space(32)
  into #t_zwpzfl_tmp0
	from dbo.jiesuan_byguizu
	where zdriqi between @date1 and @date2 and guizuno=@guizuno
	group by guizuno,detail
  
--select * from #t_zwpzfl_tmp0

  update a set a.F_KMBH=b.F_KMBH,a.F_XM01=b.F_XM01
  from #t_zwpzfl_tmp0 a
  left join jiesuan_def b
  on a.detail=b.detail

  declare @F_JE_sum money
  declare @F_JE_sale money
  declare @F_JE_tax money

  declare @F_KMBH_sale varchar(32)
  declare @F_KMBH_tax varchar(32)
/*
	set @F_JE_sum=isnull((select sum(F_JE) from #t_zwpzfl_tmp0),0)
  set @F_JE_tax= round((@F_JE_sum/1.17)*0.17,2)
  set @F_JE_sale=@F_JE_sum-@F_JE_tax 	
*/  
	set @F_KMBH_tax='221010501'

	set @F_KMBH_sale='501'

  select F_PZBH=@serno,F_FLBH=space(6),F_DWBH=guizuno,F_XM01=spno,
				F_JE=round(sum(cast(isnull(jine,0) as money)),2),F_YWRQ=@date2,
 				F_YT=guizu+'销售'
  into #lsdsp
  from lsdsp
	where lsriqi between @date1 and @date2 and guizuno=@guizuno
  group by guizuno,guizu,spno

     
	declare cursor_lsdsp cursor
  for     
  select F_XM01,F_JE,F_XM01 from #lsdsp
  order by F_XM01

  declare @F_XM01 varchar(16)
  declare @F_JE money

	open cursor_lsdsp

  Fetch next from cursor_lsdsp
  into @F_XM01,@F_JE,@F_XM01

  while @@Fetch_status = 0
  begin
    set @F_JE_tax= round((@F_JE/1.17)*0.17,2)
    set @F_JE_sale=@F_JE-@F_JE_tax 	
    
		insert into #t_zwpzfl_tmp0 (F_PZBH,detail,guizuno,F_JE,F_KMBH,F_JZFX,F_YWRQ,F_FLBH,spno,bTax,F_XM01)
 		values (@serno,null,@guizuno,@F_JE_tax,@F_KMBH_tax,'2',@F_PZRQ,'990',@F_XM01,1,@F_XM01)
		insert into #t_zwpzfl_tmp0 (F_PZBH,detail,guizuno,F_JE,F_KMBH,F_JZFX,F_YWRQ,F_FLBH,spno,bTax,F_XM01)
 		values (@serno,null,@guizuno,@F_JE_sale,@F_KMBH_sale,'2',@F_PZRQ,'991',@F_XM01,0,@F_XM01)  

	  Fetch next from cursor_lsdsp
  	into @F_XM01,@F_JE,@F_XM01
  end  

  close cursor_lsdsp	 
  deallocate cursor_lsdsp

/*
	insert into #t_zwpzfl_tmp0 (F_PZBH,detail,guizuno,F_JE,F_KMBH,F_JZFX,F_YWRQ,F_FLBH)
 	values (@serno,null,@guizuno,@F_JE_sale,@F_KMBH_sale,'2',@F_PZRQ,'991')  

	insert into #t_zwpzfl_tmp0 (F_PZBH,detail,guizuno,F_JE,F_KMBH,F_JZFX,F_YWRQ,F_FLBH)
 	values (@serno,null,@guizuno,@F_JE_tax,@F_KMBH_tax,'2',@F_PZRQ,'990')
*/
	declare cursor_tmp cursor
  for     
  select F_KMBH,spno from #t_zwpzfl_tmp0
  order by spno,F_FLBH

  declare @F_KMBH varchar(16)
  declare @spno varchar(16)
	open cursor_tmp
  Fetch next from cursor_tmp
  into @F_KMBH,@spno
  declare @iRec int
  set @iRec=1
  while @@Fetch_status = 0
  begin
		update #t_zwpzfl_tmp0 set F_FLBH=dbo.LeftAddChar(cast(@iRec as varchar(16)),'0',4)
    where F_KMBH=@F_KMBH and spno=@spno
    set @iRec=@iRec+1

	  Fetch next from cursor_tmp
  	into @F_KMBH,@spno
  end  

  close cursor_tmp	 
  deallocate cursor_tmp
  
  update a set a.F_ZY=b.guizu+'销售'
  from #t_zwpzfl_tmp0 a
  left join guizu b
  on a.guizuno=b.guizuno

  insert into t_zwpzfl (F_PZBH,F_FLBH,F_KMBH,F_ZY,F_JE,F_JZFX,F_YWRQ)
  select F_PZBH,F_FLBH,F_KMBH,F_ZY,cast(F_JE as varchar(16)),F_JZFX,F_YWRQ from #t_zwpzfl_tmp0

  insert into t_zwfzys (F_PZBH,F_FLBH,F_DWBH,F_XM01,F_JE,F_YWRQ,F_YT)
  select F_PZBH,F_FLBH,guizuno,F_XM01,cast(F_JE as varchar(16)),F_YWRQ,F_ZY from #t_zwpzfl_tmp0
  where btax=0
--  insert into 

select * from #t_zwpzfl_tmp0  
select * from t_zwpzfl order by F_FLBH
select * from t_zwfzys order by F_FLBH
  


 


end


GO
