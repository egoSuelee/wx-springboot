
/*
  p_QryMoneycard_Web a,'2010-11-01','2011-11-01','天兰奥特莱斯'
*/

CREATE PROCEDURE [dbo].[p_QryMoneycard_Web]
--@cCardNo varchar(32),  ---卡号
--@bDispDel smallint,  ---显示回收卡
@tble  varchar(100),  ---表名
@date1 datetime,     ---- 开始时间
@date2 datetime--,   ---- 结束时间
--@CMarketName varchar(32)   ---商场名称
	AS
BEGIN
	--if  (select object_id('tempdb..#temp_moneycard')) is not null
	--drop table #temp_moneycard
	if  (select object_id('tempdb..#temp_moneycardList')) is not null
	drop table #temp_moneycardList	
	select 消费地点=a.station,Pos编号=a.sheetno, 储值卡编号=a.cardno, 消费时间=a.custtime, 消费日期=convert(varchar(100),a.custdate,23),
	原始金额=a.orientmoney,本次累计消费=a.custmoney,本次余额=a.leftmoney,本次消费=a.curmoney,操作员编号=a.operno
  into #temp_moneycardList
 -- from dbo.Moneycard_list a where a.station=@CMarketName and a.custdate  between @date1 and @date2
   from dbo.Moneycard_list a where a.custdate  between @date1 and @date2

 --select * from #temp_moneycardlist
  
  exec('if (select object_id(''U_key.dbo.'+@tble+'''))is not null 
drop table U_key.dbo.'+@tble+'
 select * into U_key.dbo.'+@tble+' from  #temp_moneycardlist')
 
 ---select * from U_key.dbo.a
END
GO
