/*
p_QryMoneycard_table '',1,'cz_abc'
*/

CREATE procedure [dbo].[p_QryMoneycard_table]
@cCardNo varchar(32),
@bDispDel smallint,  ---显示回收卡
@tble  varchar(100)  ---表名
as
begin
	if  (select object_id('tempdb..#temp_moneycard')) is not null
	drop table #temp_moneycard
	if  (select object_id('tempdb..#temp_moneycardList')) is not null
	drop table #temp_moneycardList
	select 储值卡编号=cardno,iLineno,锁定=locked,原始金额=orientmoney,累计消费=custmoney,当前余额=leftmoney,
	生效日=date1,失效日=date2,回收=Deleted
	into #temp_moneycard
--	from [warelucent100.gicp.net].supermarket.dbo.moneycard
	from dbo.moneycard
  where cardno like @cCardNo+'%' and (Deleted=(@bDispDel+1)% 2)

  select 消费地点=a.station,Pos编号=a.sheetno, 储值卡编号=a.cardno, 消费时间=a.custtime, 消费日期=a.custdate,
	原始金额=a.orientmoney,本次累计消费=a.custmoney,本次余额=a.leftmoney,本次消费=a.curmoney,操作员编号=a.operno,
  b.当前余额,b.锁定,b.回收
  into #temp_moneycardList
--  from [warelucent100.gicp.net].supermarket.dbo.Moneycard_list a,#temp_moneycard b
  from dbo.Moneycard_list a,#temp_moneycard b
  where a.cardno=b.储值卡编号 and a.custdate between b.生效日 and b.失效日
  order by a.cardno,a.custdate,a.custtime,b.回收

if (select object_id('tempdb..#Tmp_Chuzhik_web'))is not null
drop table #Tmp_Chuzhik_web
 select 储值卡编号, Pos编号, 消费地点,消费时间, 消费日期=convert(varchar(100),消费日期,23),
	原始金额,本次累计消费,本次消费,本次余额,当前余额,操作员编号,
  锁定,回收
 into #Tmp_Chuzhik_web from #temp_moneycardList
  union all
  select 储值卡编号,Pos编号='总结',消费地点=null,  消费时间=null, 消费日期=null,
	原始金额,本次累计消费=累计消费,本次消费=null,本次余额=null,当前余额,操作员编号=null,
  锁定=null,回收=null
	from #temp_moneycard
  order by 储值卡编号,消费日期,消费时间
 -- select 储值卡编号, Pos编号, 消费地点,消费时间, 消费日期=convert(varchar(100),消费日期,23),
	--原始金额,本次累计消费,本次消费,本次余额,当前余额,操作员编号,
 -- 锁定,回收,iSerno=1
 -- from #temp_moneycardList
 -- union all
 -- select 储值卡编号,Pos编号='总结',消费地点=null,  消费时间=null, 消费日期=null,
	--原始金额,本次累计消费=累计消费,本次消费=null,本次余额=null,当前余额,操作员编号=null,
 -- 锁定=null,回收=null,iSerno=99
	--from #temp_moneycard
 -- order by 储值卡编号,iSerno,消费日期,消费时间
  
  exec('if (select object_id(''U_key.dbo.'+@tble+'''))is not null 
drop table U_key.dbo.'+@tble+'
 select * into U_key.dbo.'+@tble+' from  #Tmp_Chuzhik_web'
  

)
--select * from #Tmp_Chuzhik_web
end
GO
