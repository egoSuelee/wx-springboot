create procedure p_Qry_Moneycard
@cardno varchar(32),
@fMoney_Cust money
as
begin
	select leftmoney from supermarket.dbo.moneycard 
	where isnull(Deleted,0)=0 and isnull(bReturned,0)=0 
	 and cardno=@cardno and (leftmoney-@fMoney_Cust)>=0
end
GO
