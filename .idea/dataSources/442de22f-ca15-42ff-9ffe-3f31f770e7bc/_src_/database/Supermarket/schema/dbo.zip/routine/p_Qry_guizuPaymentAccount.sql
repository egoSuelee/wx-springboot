/*
p_Qry_guizuPaymentAccount '2009-01-01','2010-01-01',''
*/

create procedure p_Qry_guizuPaymentAccount
@dDate1 datetime,
@dDate2 datetime,
@guizuno varchar(32)
as
begin
  select jiesuanno,guizuno,guizu,xiaoshoujine,feiyongjine,koudianjine,jiesuanjine,jiesuanriqi,riqi1,riqi2
	into #temp_guizu_jiesuan --截止到@dDate2的结算单
	from dbo.guizu_jiesuan
  where jiesuanriqi <= @dDate2

  select jiesuanNo,fMoney_payment_total=isnull(sum(isnull(fMoney_payment,0)),0)
	into #temp_guizuJiesuanPayment  --截止到@dDate2的结算付款
  from  dbo.t_guizuJiesuanPayment
  where dDate <= @dDate2
	group by jiesuanNo
   
  select jiesuanNo,fMoney_payment_total_period=isnull(sum(isnull(fMoney_payment,0)),0)
	into #temp_guizuJiesuanPayment_period  --@dDate1到@dDate2的结算付款
  from  dbo.t_guizuJiesuanPayment
  where dDate between @dDate1 and  @dDate2
	group by jiesuanNo
   
  select a.jiesuanno,a.guizuno,a.guizu,a.xiaoshoujine,a.feiyongjine,a.koudianjine,a.jiesuanjine,
  fMoney_payment_total=isnull(b.fMoney_payment_total,0),
  fMoney_payment_total_period=isnull( c.fMoney_payment_total_period,0),dDate1=@dDate1,dDate2=@dDate2
	,jiesuanriqi,riqi1,riqi2
  into #temp_guizuJiesuanPayment_period_jiesuanno
  from #temp_guizu_jiesuan a left join #temp_guizuJiesuanPayment b on a.jiesuanno=b.jiesuanno
      left join #temp_guizuJiesuanPayment_period c on a.jiesuanno=c.jiesuanno

  select iserno=0,detail=null,jiesuanno,guizuno,guizu,xiaoshoujine,feiyongjine,koudianjine,jiesuanjine,
  fMoney_payment_total,fMoney_payment_total_period,dDate1,dDate2,riqi1,riqi2,jiesuanriqi,
  fMoney_blance=jiesuanjine-fMoney_payment_total
  from #temp_guizuJiesuanPayment_period_jiesuanno
	union all
  select iserno=1,detail='小计:',jiesuanno=null,guizuno,guizu='小计:',xiaoshoujine=sum(xiaoshoujine),
  feiyongjine=sum(feiyongjine),koudianjine=sum(koudianjine),jiesuanjine=sum(jiesuanjine),
  fMoney_payment_total=sum(fMoney_payment_total),
	fMoney_payment_total_period=sum(fMoney_payment_total_period),dDate1=null,dDate2=null,riqi1=null,riqi2=null,jiesuanriqi=null,
	fMoney_blance=sum(jiesuanjine-fMoney_payment_total)
  from #temp_guizuJiesuanPayment_period_jiesuanno
  group by guizuno
  --order by guizuno,iSerno
	union all
  select iserno=2,detail='总计:',jiesuanno=null,guizuno='合计:',guizu=null,xiaoshoujine=sum(xiaoshoujine),
  feiyongjine=sum(feiyongjine),koudianjine=sum(koudianjine),jiesuanjine=sum(jiesuanjine),
  fMoney_payment_total=sum(fMoney_payment_total),
	fMoney_payment_total_period=sum(fMoney_payment_total_period),dDate1=null,dDate2=null,riqi1=null,riqi2=null,jiesuanriqi=null,
	fMoney_blance=sum(jiesuanjine-fMoney_payment_total)
  from #temp_guizuJiesuanPayment_period_jiesuanno
  order by guizuno,iserno,detail



end
GO
