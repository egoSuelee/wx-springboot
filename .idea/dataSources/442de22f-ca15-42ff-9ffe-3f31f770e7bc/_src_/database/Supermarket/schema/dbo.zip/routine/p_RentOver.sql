


/*


p_RentOver '2008-9-29'


*/
CREATE    procedure p_RentOver 
--@dDate_Ref1 datetime,
@dDate_Ref datetime
as
begin
	--declare @dDate_Ref datetime
	--set @dDate_Ref=@dDate_Ref2

	select serno,guizuno,guizu=mingcheng,jingli,fangzushishou,qixian1,qixian2,iRentDate,iRentPayMode,
	RentMoney=case when iRentPayMode=0 then fRentByMonth
								 when iRentPayMode=1 then fRentBySeason
								 when iRentPayMode=2 then fRentByHalfYear
								 when iRentPayMode=3 then fRentByYear
								 else fRentByMonth
						end
	into #shanghu_hetong  --获取所有租赁户的相关信息
	from dbo.shanghu_hetong
	where bLeaseHold is not null and  bLeaseHold=1

 
  select a.guizuno,a.iSerno,
	a.dPayRentDate,--房租缴纳日期
	a.fPayMoney,--房租缴纳金额
	a.fArrearageMoney,--房租欠款
	a.dPeriod1,--所交房租开始日期
	a.dPeriod2--所交房租结束日期
	into #LastRentPay--各柜组最后一次房租的交付情况
	from shanghu_hetong_RentPay a,
	(
	  select guizuno,iSerno=max(iSerno) 
	  from dbo.shanghu_hetong_RentPay
		group by guizuno
	)b
	where a.guizuno=b.guizuno and a.iSerno=b.iSerno

--select * from  #shanghu_hetong

	select a.serno,a.guizuno,a.guizu,a.jingli,a.RentMoney,a.qixian1,a.qixian2,a.iRentDate,a.iRentPayMode,
	iSerno_RentPay=b.iSerno,b.dPayRentDate,b.fPayMoney,b.fArrearageMoney,b.dPeriod1,b.dPeriod2,
	dRent_Ref=cast(getdate() as datetime),iRentQuantity=cast(null as int)
	into 	#shanghu_hetong_LastRentPay
	from #shanghu_hetong a left join #LastRentPay b on a.guizuno=b.guizuno --如果iSerno_RentPay is null 表明该租户从来没有缴纳房租
--	where a.guizuno=b.guizuno 

	update #shanghu_hetong_LastRentPay
	set dRent_Ref=null

	update #shanghu_hetong_LastRentPay
	set dRent_Ref=qixian1
	where iSerno_RentPay is null

	update #shanghu_hetong_LastRentPay
	set dRent_Ref=dPeriod2
	where iSerno_RentPay is not  null

	update #shanghu_hetong_LastRentPay
	set iRentQuantity=
		case when dRent_Ref<= @dDate_Ref then
			case when iRentPayMode=0 then
								case when iRentDate<=day(@dDate_Ref) then DATEDIFF(month, dRent_Ref, @dDate_Ref)+1
								     when iRentDate>day(@dDate_Ref) then 
													case when DATEDIFF(month, dRent_Ref, @dDate_Ref)>0 then DATEDIFF(month, dRent_Ref, @dDate_Ref)
															 else 0
													end
								end
					 when iRentPayMode=1 then
								case when iRentDate<=day(@dDate_Ref) then (DATEDIFF(month, dRent_Ref, @dDate_Ref))/3+1
								     when iRentDate>day(@dDate_Ref) then 
													case when DATEDIFF(month, dRent_Ref, @dDate_Ref)>0 then (DATEDIFF(month, dRent_Ref, @dDate_Ref)-1)/3+1
															 else 0
													end
										 else 0	
								end
					 when iRentPayMode=2 then
								case when iRentDate<=day(@dDate_Ref) then DATEDIFF(month, dRent_Ref, @dDate_Ref)/6+1
								     when iRentDate>day(@dDate_Ref) then 
													case when DATEDIFF(month, dRent_Ref, @dDate_Ref)>0 then (DATEDIFF(month, dRent_Ref, @dDate_Ref)-1)/6+1
															 else 0
													end
										 else 0
								end
					 when iRentPayMode=3 then
								case when iRentDate<=day(@dDate_Ref) then DATEDIFF(month, dRent_Ref, @dDate_Ref)/12+1
								     when iRentDate>day(@dDate_Ref) then 
													case when DATEDIFF(month, dRent_Ref, @dDate_Ref)>0 then (DATEDIFF(month, dRent_Ref, @dDate_Ref)-1)/12+1
															 else 0
													end
										 else 0
								end
			else 0
			end
		else 0
		end
		
	select guizuno,guizu,jingli,RentMoney,iRentQuantity,qixian1,qixian2,iRentDate,iRentPayMode,dRent_Ref,
	dPayRentDate,fPayMoney,fArrearageMoney,dPeriod1,dPeriod2,iSerno_RentPay,
	fPayMoney_now=isnull(fArrearageMoney,0)+isnull(iRentQuantity,0)*isnull(RentMoney,0),
	iMonthRight=case when iRentPayMode=0 then 1
									 when iRentPayMode=1 then 3
									 when iRentPayMode=2 then 6
									 when iRentPayMode=3 then 12
							else 1
							end,
	dRentDate1_now=cast(null as datetime),
	dRentDate2_now=cast(null as datetime)
	into #qryResult
  from #shanghu_hetong_LastRentPay
	order by guizuno

	update	#qryResult
	set dRentDate1_now=dateadd(day,1,dRent_Ref),
	dRentDate2_now=dateadd(month,iRentQuantity*isnull(iMonthRight,0),dRent_Ref)
  
	drop table #shanghu_hetong_LastRentPay
	drop table #shanghu_hetong
	drop table #LastRentPay

	select guizuno,guizu,--柜组信息
	RentMoney,--按期缴纳的房租金额
  jingli,--默认缴款人（商户经理）
	iRentQuantity,--欠租月、季、半年、年的数量
	qixian1,qixian2,--签约合同期限
	iRentDate,--约定交纳房租日
	RentPayMode=case when iRentPayMode=0 then '按月交'
									 when iRentPayMode=1 then '按季交'
									 when iRentPayMode=2 then '按半年交'
									 when iRentPayMode=3 then '按年交'
									 else 	'按月交'
							end,--交款模式0月、1季、2半年、3年
	dRent_Ref,--查询参照日期。如查询2008-10-01日商户应缴房租情况，则dRent_Ref=2008-10-01
	dPayRentDate,--到dRent_Ref为止，商户欠房租金额
	fPayMoney,--最近一次付款金额
	fArrearageMoney,--最近一次欠款余额
	dPeriod1,dPeriod2,--最近一次房租时段
	iSerno_RentPay,--最近一次房租交款ID序号
	fRentMoney_now=isnull(iRentQuantity,0)*isnull(RentMoney,0),--本期房租金额
	fPayMoney_now,--本次应交租金=最近一次欠款余额+本期房租金额
	iMonthRight,--时段月权系数（如：季度为3个月，所以iMonthRight=3）
	dRentDate1_now,dRentDate2_now--本次应交租金时段
	from #qryResult


end


GO
