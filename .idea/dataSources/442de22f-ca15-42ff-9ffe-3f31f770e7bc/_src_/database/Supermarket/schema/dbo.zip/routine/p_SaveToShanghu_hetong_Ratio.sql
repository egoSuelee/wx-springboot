
CREATE  procedure p_SaveToShanghu_hetong_Ratio
@guizuno varchar(32)
as
begin
  declare @minValue money
  declare @iRec money
  
  select a.guizuno,a.guizu,fMoney1=a.fMoney,fMoney2=isnull(b.fMoney,999999999),a.fRatio
  into #t0
  from #Shanghu_hetong_Ratio a
  left join #Shanghu_hetong_Ratio b
  on b.guizuno=a.guizuno and a.fMoney<b.fMoney
  where a.guizuno=@guizuno

  select guizuno,guizu,fMoney1,fMoney2=min(fMoney2),fRatio
  into #t1
  from #t0
  group by guizuno,guizu,fMoney1,fRatio
  
  set @iRec=(select count(guizuno) from #t1)
  set @minValue=(select min(fMoney1) from #t1) 
/*
  insert into #t1 (guizuno,guizu,fMoney1,fMoney2,fRatio)
  select top 1 guizuno,guizu,-999999999,@minValue,fRatio 
  from #t1 where fMoney1=@minValue
*/
  delete from Shanghu_hetong_Ratio where guizuno=@guizuno
  insert into Shanghu_hetong_Ratio (guizuno,guizu,fMoney1,fMoney2,fRatio)
  select guizuno,guizu,fMoney1,fMoney2,fRatio from #t1
  
  

end

GO
