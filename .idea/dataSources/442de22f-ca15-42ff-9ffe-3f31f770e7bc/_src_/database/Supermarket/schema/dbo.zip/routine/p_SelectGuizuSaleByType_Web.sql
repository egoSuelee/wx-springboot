-- Batch submitted through debugger: SQLQuery2.sql|7|0|C:\Documents and Settings\Administrator\Local Settings\Temp\~vs3E.sql
--select * from jiesuan_byguizu
/*
查询日销售（收银分类）
p_SelectGuizuSaleByType_Web '101','2010-11-08','2010-11-08'
*/
CREATE proc [dbo].[p_SelectGuizuSaleByType_Web]
@guizuNo varchar(32),
@date_bgn datetime,
@date_end datetime
as

declare @cTypes varchar(3000)  -----动态的添加字段。
declare @cTmpType varchar(100)  ----收费类型。。
declare @cTypeSelect varchar(300) 
declare @cTypeSelectTmp varchar(300)
declare @cTypeSum varchar(300)
declare @cTypeSumTmp varchar(300)
if (select object_id('tempdb..#tmpjiesuanType'))is not null
drop table #tmpjiesuanType
select distinct detail
into #tmpjiesuanType
from jiesuan_byguizu


declare Cur_Type cursor for
select distinct detail
from #tmpjiesuanType

open Cur_Type
select  @cTypes='',@cTmpType='',@cTypeSelect='',@cTypeSelectTmp='',@cTypeSum='',@cTypeSumTmp=''
fetch next from Cur_Type into @cTmpType
while @@fetch_status=0
begin
   set @cTypes=@cTypes+',['+@cTmpType+'] money default 0 with values'
   set @cTypeSelect=@cTypeSelect+',['+@cTmpType+']'
   set @cTypeSumTmp=@cTypeSumTmp+',sum('+@cTmpType+')'
   fetch next from Cur_Type into @cTmpType
end
set @cTypes=substring(@cTypes,2,3000)
close Cur_Type
deallocate Cur_Type

--select @cTypes,@cTypeSelect,@cTypeSumTmp

if (select object_id('tempdb..#Tmp_jiesuan_byguizu'))is not null
drop table #Tmp_jiesuan_byguizu
select distinct guizuno,guizu,Qty=cast(0 as money),zdriqi,sheetno=sheetno+'-'+guizuno,fTotMoney=round(sum(shishou),2)
into #Tmp_jiesuan_byguizu
from jiesuan_byguizu
where zdriqi between @date_bgn and @date_end
and guizuno=@guizuNo
group by guizuno,guizu,sheetno,zdriqi

exec('alter table  #Tmp_jiesuan_byguizu add '+@cTypes+', [shenhe] [varchar](32) NULL')


declare Cur_update cursor for
select distinct detail
from #tmpjiesuanType

open Cur_update
select @cTmpType=''
fetch next from Cur_update into @cTmpType
while @@fetch_status=0
begin
exec('
    update a
	set a.['+@cTmpType+']=round(c.shishou,2)
	from #Tmp_jiesuan_byguizu a,jiesuan_byguizu c
	where a.zdriqi=c.zdriqi and a.sheetno=c.sheetno+''-''+c.guizuno and a.guizuno=c.guizuno
    and c.detail='''+@cTmpType+'''
    and c.zdriqi between '''+@date_bgn +'''and '''+@date_end+'''
    and c.guizuno='''+@guizuNo +''''
    )

   fetch next from Cur_update into @cTmpType
end
close Cur_update
deallocate Cur_update


update a
set a.Qty=b.Qty
from #Tmp_jiesuan_byguizu a,
(
	select zdriqi=Lsriqi,LsdNo,Qty=round(sum(shuliang),2)
	from lsdsp
	where Lsriqi between @date_bgn and @date_end 
	and guizuno=@guizuNo
    group by Lsriqi,LsdNo
    
)b
where a.sheetno=b.lsdno and a.zdriqi=b.zdriqi

--update a
--set a.shenhe=b.shenhe
--from #Tmp_jiesuan_byguizu a,
--(
--	select zdriqi,LsdNo,shenhe
--	from lsd
--	where Zdriqi between @date_bgn and @date_end 
--	and guizuno=@guizuNo   
--)b
--where a.sheetno=b.lsdno and a.zdriqi=b.zdriqi

update a
set a.shenhe='√'
from #Tmp_jiesuan_byguizu a,
(
	select zdriqi,LsdNo,shenhe
	from lsd
	where Zdriqi between @date_bgn and @date_end 
	and guizuno=@guizuNo   
)b
where a.sheetno=b.lsdno and a.zdriqi=b.zdriqi and b.shenhe=1

update a
set a.shenhe='×'
from #Tmp_jiesuan_byguizu a,
(
	select zdriqi,LsdNo,shenhe
	from lsd
	where Zdriqi between @date_bgn and @date_end 
	and guizuno=@guizuNo   
)b
where a.sheetno=b.lsdno and a.zdriqi=b.zdriqi and b.shenhe=0


--declare @cShen varchar(32)
--declare Shen_update cursor for
--select shenhe from #Temp_jiesuan_byguizu

--open Shen_update
--select @cShen=''
--fetch next from Shen_update into @cShen
--while @@fetch_status=0
--begin
--    if @cShen='1'
--    exec(
--      'update set a.shenhe=''√'' from #Tmp_jiesuan_byguizu a'
--    )
--   fetch next from Shen_update into @cTmpType
--end
--close Shen_update
--deallocate Shen_update
--exec('
--update  #Temp_jiesuan_byguizu  set shenhe=''√'' where shenhe=''1''
--update  #Temp_jiesuan_byguizu  set shenhe=''×'' where shenhe=''0''
--')

exec('
select 柜组编号=guizuno,柜组名称=guizu,销售日期=convert(varchar(100),zdriqi,23),[销售单号]=sheetno,数量=Qty'+@cTypeSelect+',[合计]=fTotMoney,[审核]=shenhe
from #Tmp_jiesuan_byguizu
union all
select 柜组编号=''总计'',柜组名称=guizu,销售日期=null,[销售单号]=null,数量=sum(Qty)'+@cTypeSumTmp+',sum(fTotMoney),shenhe=null
from #Tmp_jiesuan_byguizu
group by guizuno,guizu'
)

GO
