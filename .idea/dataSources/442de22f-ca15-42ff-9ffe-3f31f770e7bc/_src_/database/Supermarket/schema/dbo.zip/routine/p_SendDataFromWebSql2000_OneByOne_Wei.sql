

/*
insert into spxx_WaitSend(spno,binserted,download) 
select top 10 spno,1,1 from spxx
select * from spxx_WaitSend

12711  11

p_SendDataFromWebSql2000_OneByOne_Wei 'tianyi'
select  * from [192.168.1.2].tianyi.dbo.spxx where spno='01230'
delete [192.168.1.2].tianyi.dbo.spxx where spno='01230'
select *,bDel from spxx where spno in (select spno from spxx_WaitSend )

declare @ServerName varchar(32)
set @ServerName='pingguoyuan'
exec p_SendDataFromWebSql2000_OneByOne_Wei @ServerName

2小时

*/

create     procedure [dbo].[p_SendDataFromWebSql2000_OneByOne_Wei]
@ServerName varchar(32)
as
begin
	exec('
			if  (select object_id(''tempdb..#temp_pass'')) is not null
		drop table #temp_pass

		if  (select object_id(''tempdb..#temp_pass_filtered'')) is not null
		drop table #temp_pass_filtered
		
		if  (select object_id(''tempdb..#temp_guizu_yuangong'')) is not null
		drop table #temp_guizu_yuangong
		
			if  (select object_id(''tempdb..#temp_pinpai'')) is not null
		drop table #temp_pinpai
		
			if  (select object_id(''tempdb..#temp_guizu'')) is not null
		drop table #temp_guizu
		
				if  (select object_id(''tempdb..#temp_spxx'')) is not null
		drop table #temp_spxx
			------- 操作员
			select distinct  [User], [Name], [Pass], [Right], Ki, quanxian, 
			userType, RightPrint, RightQuery, RightOutPut, RightUpate,
			 RightDelete, RightInsert, BumenMc, BumenNo, cManagerNo, cManager, bManager
		into #temp_pass 
		from pass  
		order by [user]  ------  获取本地最新的操作员信息

    select user_a=a.[User],user_b=b.[User]
    into #temp_pass_filtered
		from #temp_pass a left join [192.168.1.2].'+@ServerName+'.dbo.pass b 
		on (a.[user]=b.[user]) 
    where 
		isnull(a.[name],'''')<>isnull(b.[name],'''') or isnull(a.[pass],'''')<>isnull(b.[pass],'''')
				 or isnull(a.[Right],'''')<>isnull(b.[Right],'''') or isnull(a.Ki,0)<>isnull(b.Ki,0)
				 or isnull(a.userType,'''')<>isnull(b.userType,'''')
				 or isnull(a.RightPrint,0)<>isnull(b.RightPrint,0)
				 or isnull(a.RightQuery,0)<>isnull(b.RightQuery,0)
				 or isnull(a.RightOutPut,0)<>isnull(b.RightOutPut,0)
				 or isnull(a.RightUpate,0)<>isnull(b.RightUpate,0)
				 or isnull(a.RightDelete,0)<>isnull(b.RightDelete,0)
			   or isnull(a.RightInsert,0)<>isnull(b.RightInsert,0)
				 or isnull(a.BumenMc,'''')<>isnull(b.BumenMc,'''')
				 or isnull(a.BumenNo,'''')<>isnull(b.BumenNo ,'''')
				 or isnull(a.cManagerNo,'''')<>isnull(b.cManagerNo,'''')
				 or isnull(a.cManager,'''')<>isnull(a.cManager,'''') 
				 or isnull(a.bManager,0)<>isnull(b.bManager,0)

    insert into [192.168.1.2].'+@ServerName+'.dbo.pass
	  ([User], [Name], [Pass], [Right], Ki, quanxian, 
			userType, RightPrint, RightQuery, RightOutPut, RightUpate,
			 RightDelete, RightInsert, BumenMc, BumenNo, cManagerNo, cManager, bManager)
		select [User], [Name], [Pass], [Right], Ki, quanxian, 
			userType, RightPrint, RightQuery, RightOutPut, RightUpate,
			 RightDelete, RightInsert, BumenMc, BumenNo, cManagerNo, cManager, bManager
		from #temp_pass
    where [User] in (select user_a from #temp_pass_filtered where user_b is null)

    update a set
			a.[Name]=b.[Name], a.[Pass]=b.[Pass], a.[Right]=b.[Right], a.Ki=b.Ki, a.quanxian=b.quanxian, 
			a.userType=b.userType, a.RightPrint=b.RightPrint, a.RightQuery=b.RightQuery, a.RightOutPut=b.RightOutPut, a.RightUpate=b.RightUpate,
			a.RightDelete=b.RightDelete, a.RightInsert=b.RightInsert, a.BumenMc=b.BumenMc, a.BumenNo=b.BumenNo, a.cManagerNo=b.cManagerNo, a.cManager=b.cManager, a.bManager=b.bManager
    from [192.168.1.2].'+@ServerName+'.dbo.pass a,#temp_pass b
    where a.[User]=b.[User] and a.[User] in (select user_a from #temp_pass_filtered where user_b is not null)
          and substring(a.quanxian,1,1)<>''Y''

    update a set a.[Pass]=b.[Pass]
    from [192.168.1.2].'+@ServerName+'.dbo.pass a,pass b
    where a.[User]=b.[User] and substring(a.quanxian,1,1)=''Y''

	
	  declare @bData bit
    set @bData=0
	---- 柜组员工
		
		select *
    into #temp_guizu_yuangong
    from dbo.guizu_yuangong a --with (readpast)
    where isnull(bDownLoad,0)=1

		if (select count(*) from #temp_guizu_yuangong)>0
    begin
			set @bData=1

	    insert into [192.168.1.2].'+@ServerName+'.dbo.guizu_yuangong(gonghao, guizuno, guizu, mingcheng, sex, tel, 
				addr, shenfenzheng, jiguan, gongzi, jiesuan, shenhe, 
				shenheren, beizhu,bDownLoad)
	    select a.gonghao, a.guizuno, a.guizu, a.mingcheng, a.sex, a.tel, 
				a.addr, a.shenfenzheng, a.jiguan, a.gongzi, a.jiesuan, a.shenhe, 
				a.shenheren, a.beizhu,a.bDownLoad
	     from #temp_guizu_yuangong a left join [192.168.1.2].'+@ServerName+'.dbo.guizu_yuangong b on a.gonghao=b.gonghao
	     where b.gonghao is null
	
	     update a set
			  a.guizuno=b.guizuno, a.guizu=b.guizu, a.mingcheng=b.mingcheng, a.sex=b.sex, a.tel=b.tel, 
				a.addr=b.addr, a.shenfenzheng=b.shenfenzheng, a.jiguan=b.jiguan, a.gongzi=b.gongzi, a.jiesuan=b.jiesuan, a.shenhe=b.shenhe, 
				a.shenheren=b.shenheren, a.beizhu=b.beizhu,a.bDownLoad=b.bDownLoad
	     from [192.168.1.2].'+@ServerName+'.dbo.guizu_yuangong a,#temp_guizu_yuangong b 
	     where a.gonghao in (select gonghao from #temp_guizu_yuangong) and a.gonghao=b.gonghao
	
	     update a set a.bDownload=0
	     from guizu_yuangong a,#temp_guizu_yuangong b
	     where a.gonghao=b.gonghao
		end

	-----  品牌
		
		 select *
    into #temp_pinpai
    from dbo.t_pinpai a --with (readpast)
    where isnull(bDownLoad,0)=1

		if (select count(*) from #temp_pinpai)>0
    begin
			set @bData=1

	    insert into [192.168.1.2].'+@ServerName+'.dbo.t_pinpai(pinpaino,pinpai,area,fee,remark,
						guizuNo,guizu,bDel,bSleep,scriqi,iDays,
						jzriqi,bDownLoad)
	    select a.pinpaino,a.pinpai,a.area,a.fee,a.remark,
						a.guizuNo,a.guizu,a.bDel,a.bSleep,a.scriqi,a.iDays,
						a.jzriqi,a.bDownLoad
	     from #temp_pinpai a left join [192.168.1.2].'+@ServerName+'.dbo.t_pinpai b on a.pinpaino=b.pinpaino
	     where b.pinpaino is null
	
	     update a set
						a.pinpai=b.pinpai,a.area=b.area,a.fee=b.fee,a.remark=b.remark,
						a.guizuNo=b.guizuNo,a.guizu=b.guizu,a.bDel=b.bDel,a.bSleep=b.bSleep,a.scriqi=b.scriqi,a.iDays=b.iDays,
						a.jzriqi=b.jzriqi,a.bDownLoad=b.bDownLoad
	     from [192.168.1.2].'+@ServerName+'.dbo.t_pinpai a,#temp_pinpai b 
	     where a.pinpaino in (select pinpaino from #temp_pinpai) and a.pinpaino=b.pinpaino
	
	     update a set a.bDownload=0
	     from dbo.t_pinpai a,#temp_pinpai b
	     where a.pinpaino=b.pinpaino
		end

		
	--------------- 柜组信息
    select *
    into #temp_guizu
    from dbo.guizu a 
    where isnull(bDownLoad,0)=1
  
		if (select count(*) from #temp_guizu)>0
    begin
			set @bData=1
	    insert into [192.168.1.2].'+@ServerName+'.dbo.guizu(guizuno,guizu,quno,qu,themanager,thetel,
							thebank,thebankno,leixing,zhangqi,taxno,email,
							youbian,gongsi,gongsiquyu,gongsijingli,
							gongsileixing,jingyingfangshi,mianji,
							mianji_danjia,mianji_jine,shenhe,shenheren,
							beizhu,guanli,gongzi,serno,baodijine,koudian,
							password_guizu,fObjectMoney,cFinanceType,gysno,
							gysmc,bDel,bHide,beizhu_Ratio,cHelp,cPOS,ypfj1,
							ypfj2,ypfj3,maxpfj,Total_qcsl,selected,bMap,
							helpkeyword,cHint,cGoodsTypeNo,cSize,bHouqin,
							kemuno,kemu,bDownLoad)
	    select a.guizuno,a.guizu,a.quno,a.qu,a.themanager,a.thetel,
							a.thebank,a.thebankno,a.leixing,a.zhangqi,a.taxno,a.email,
							a.youbian,a.gongsi,a.gongsiquyu,a.gongsijingli,
							a.gongsileixing,a.jingyingfangshi,a.mianji,
							a.mianji_danjia,a.mianji_jine,a.shenhe,a.shenheren,
							a.beizhu,a.guanli,a.gongzi,a.serno,a.baodijine,a.koudian,
							a.password_guizu,a.fObjectMoney,a.cFinanceType,a.gysno,
							a.gysmc,a.bDel,a.bHide,a.beizhu_Ratio,a.cHelp,a.cPOS,a.ypfj1,
							a.ypfj2,a.ypfj3,a.maxpfj,a.Total_qcsl,a.selected,a.bMap,
							a.helpkeyword,a.cHint,a.cGoodsTypeNo,a.cSize,a.bHouqin,
							a.kemuno,a.kemu,a.bDownLoad 
	     from #temp_guizu a left join [192.168.1.2].'+@ServerName+'.dbo.guizu b on a.guizuno=b.guizuno
	     where b.guizuno is null
	
	     update a set
							a.guizu=b.guizu,a.quno=b.quno,a.qu=b.qu,a.themanager=b.themanager,a.thetel=b.thetel,
							a.thebank=b.thebank,a.thebankno=b.thebankno,a.leixing=b.leixing,a.zhangqi=b.zhangqi,a.taxno=b.taxno,a.email=b.email,
							a.youbian=b.youbian,a.gongsi=b.gongsi,a.gongsiquyu=b.gongsiquyu,a.gongsijingli=b.gongsijingli,
							a.gongsileixing=b.gongsileixing,a.jingyingfangshi=b.jingyingfangshi,a.mianji=b.mianji,
							a.mianji_danjia=b.mianji_danjia,a.mianji_jine=b.mianji_jine,a.shenhe=b.shenhe,a.shenheren=b.shenheren,
							a.beizhu=b.beizhu,a.guanli=b.guanli,a.gongzi=b.gongzi,a.serno=b.serno,a.baodijine=b.baodijine,a.koudian=b.koudian,
							a.password_guizu=b.password_guizu,a.fObjectMoney=b.fObjectMoney,a.cFinanceType=b.cFinanceType,a.gysno=b.gysno,
							a.gysmc=b.gysmc,a.bDel=b.bDel,a.bHide=b.bHide,a.beizhu_Ratio=b.beizhu_Ratio,a.cHelp=b.cHelp,a.cPOS=b.cPOS,a.ypfj1=b.ypfj1,
							a.ypfj2=b.ypfj2,a.ypfj3=b.ypfj3,a.maxpfj=b.maxpfj,a.Total_qcsl=b.Total_qcsl,a.selected=b.selected,a.bMap=b.bMap,
							a.helpkeyword=b.helpkeyword,a.cHint=b.cHint,a.cGoodsTypeNo=b.cGoodsTypeNo,a.cSize=b.cSize,bHouqin=b.bHouqin,
							a.kemuno=b.kemuno,a.kemu=b.kemu,a.bDownLoad=b.bDownLoad
	     from [192.168.1.2].'+@ServerName+'.dbo.guizu a,#temp_guizu b 
	     where a.guizuno in (select guizuno from #temp_guizu) and a.guizuno=b.guizuno
	
	     update a set a.bDownload=0
	     from dbo.guizu a,#temp_guizu b
	     where a.guizuno=b.guizuno
				
		end
    

	----------------- 商品信息
		select a.*,b.bUpdated,b.binserted 
		into #temp_spxx 
		from dbo.spxx a ,
         dbo.spxx_WaitSend b 
    where isnull(a.bDel,0)=0 and a.spno=b.spno  
 
		if (select count(*) from #temp_spxx)>0
    begin
			set @bData=1
			if  (select object_id(''tempdb..#temp_Spxx_web'')) is not null
		   drop table #temp_Spxx_web
		   select spno into #temp_spxx_web from [192.168.1.2].'+@ServerName+'.dbo.spxx
		   
	    insert into [192.168.1.2].'+@ServerName+'.dbo.spxx(SpNo, Mingcheng, Tiaoma, Belong, Danwei, Shangxian, Xiaxian, Scriqi, 
						Bzqi, Dw1, Jl1, Dw2, Jl2, Dw3, Jl3, Beizhu, Bzjj, Ydjj1, Ydjj2, Ydjj3, 
						Maxjj, Minjj, Lastjj, Pfjjl, Bzpfj, Ypfj1, Ypfj2, Ypfj3, Maxpfj, Minpfj, 
						Lastpfj, Lsjjl, Bzlsj, Ylsj1, Ylsj2, Ylsj3, Maxlsj, Minlsj, Lastlsj, Hsfs, 
						Cunliang, Printed, Total_qcsl, Total_qclt, Total_qcjine, Total_insl, Total_inlt, 
						Total_injine, Total_outsl, Total_outlt, Total_outjine, Total_qmsl, Total_qmlt, 
						Total_qmjine, Total_lirun, Selected, star, thevalue, taxirate, qu, chandi, guige, 
						zhongliang, jingyingfangshi, guizu, guizuno, kind, dPeriod1, dPeriod2, iSpec, gysno, 
						gysmc, fTaxRatio, bDel, bHide, Tag_daily, cHelp, dDate, cSpno_POS, cPOS, fQty, bItems, 
						dDate_Create, pinpai, pinpaino, bNo_Modify, cAccountNo, cAccountName, bHouqin )
	    select a.SpNo, a.Mingcheng, a.Tiaoma, a.Belong, a.Danwei, a.Shangxian, a.Xiaxian, a.Scriqi, 
						a.Bzqi, a.Dw1, a.Jl1, a.Dw2, a.Jl2, a.Dw3, a.Jl3, a.Beizhu, a.Bzjj, a.Ydjj1, a.Ydjj2, a.Ydjj3, 
						a.Maxjj, a.Minjj, a.Lastjj, a.Pfjjl, a.Bzpfj, a.Ypfj1, a.Ypfj2, a.Ypfj3, a.Maxpfj, a.Minpfj, 
						a.Lastpfj, a.Lsjjl, a.Bzlsj, a.Ylsj1, a.Ylsj2, a.Ylsj3, a.Maxlsj, a.Minlsj, a.Lastlsj, a.Hsfs, 
						a.Cunliang, a.Printed, a.Total_qcsl, a.Total_qclt, a.Total_qcjine, a.Total_insl, a.Total_inlt, 
						a.Total_injine, a.Total_outsl, a.Total_outlt, a.Total_outjine, a.Total_qmsl, a.Total_qmlt, 
						a.Total_qmjine, a.Total_lirun, a.Selected, a.star, a.thevalue, a.taxirate, a.qu, a.chandi, a.guige, 
						a.zhongliang, a.jingyingfangshi, a.guizu, a.guizuno, a.kind, a.dPeriod1, a.dPeriod2, a.iSpec, a.gysno, 
						a.gysmc, a.fTaxRatio, a.bDel, a.bHide, a.Tag_daily, a.cHelp, a.dDate,a.cSpno_POS, a.cPOS, a.fQty, a.bItems, 
						a.dDate_Create, a.pinpai, a.pinpaino, a.bNo_Modify, a.cAccountNo, a.cAccountName, a.bHouqin 
	     from #temp_spxx a left join #temp_Spxx_web b on a.spno=b.spno 
	     where a.binserted=1 and b.spno is null
	      
	    update a set  a.Mingcheng=b.Mingcheng, a.Tiaoma=b.Tiaoma, a.Belong=b.Belong, 
				a.Danwei=b.Danwei, a.Shangxian=b.Shangxian, a.Xiaxian=b.Xiaxian, a.Scriqi=b.Scriqi, 
				a.Bzqi=b.Bzqi, a.Dw1=b.Dw1, a.Jl1=b.Jl1, a.Dw2=b.Dw2, a.Jl2=b.Jl2, a.Dw3=b.Dw3, 
				a.Jl3=b.Jl3, a.Beizhu=b.Beizhu, a.Bzjj=b.Bzjj, a.Ydjj1=b.Ydjj1, a.Ydjj2=b.Ydjj2, a.Ydjj3=b.Ydjj3, 
				a.Maxjj=b.Maxjj, a.Minjj=b.Minjj, a.Lastjj=b.Lastjj, a.Pfjjl=b.Pfjjl, a.Bzpfj=b.Bzpfj, a.Ypfj1=b.Ypfj1,
				a.Ypfj2=b.Ypfj2, a.Ypfj3=b.Ypfj3,a. Maxpfj=b.Maxpfj, a.Minpfj=b.Minpfj, 
				a.Lastpfj=b.Lastpfj, a.Lsjjl=b.Lsjjl, a.Bzlsj=b.Bzlsj, a.Ylsj1=b.Ylsj1, a.Ylsj2=b.Ylsj2, a.Ylsj3=b.Ylsj3, 
				a.Maxlsj=b.Maxlsj, a.Minlsj=b.Minlsj, a.Lastlsj=b.Lastlsj, a.Hsfs=b.Hsfs, 
				a.Cunliang=b.Cunliang, a.Printed=b.Printed, a.Total_qcsl=b.Total_qcsl, a.Total_qclt=b.Total_qclt, 
				a.Total_qcjine=b.Total_qcjine, a.Total_insl=b.Total_insl, a.Total_inlt=b.Total_inlt, 
				a.Total_injine=b.Total_injine, a.Total_outsl=b.Total_outsl, a.Total_outlt=b.Total_outlt, 
				a.Total_outjine=b.Total_outjine, a.Total_qmsl=b.Total_qmsl, a.Total_qmlt=b.Total_qmlt, 
				a.Total_qmjine=b.Total_qmjine, a.Total_lirun=b.Total_lirun, a.Selected=b.Selected, a.star=b.star, 
				a.thevalue=b.thevalue, a.taxirate=b.taxirate, a.qu=b.qu, a.chandi=b.chandi, a.guige=b.guige, 
				a.zhongliang=b.zhongliang, a.jingyingfangshi=b.jingyingfangshi, a.guizu=b.guizu, a.guizuno=b.guizuno, 
				a.kind=b.kind, a.dPeriod1=b.dPeriod1, a.dPeriod2=b.dPeriod2, a.iSpec=b.iSpec, a.gysno=b.gysno, 
				a.gysmc=b.gysmc, a.fTaxRatio=b.fTaxRatio,  a.bHide=b.bHide, a.Tag_daily=b.Tag_daily, 
				a.cHelp=b.cHelp, a.dDate=b.dDate, a.cSpno_POS=b.cSpno_POS, a.cPOS=b.cPOS, a.fQty=b.fQty, a.bItems=b.bItems, 
				a.dDate_Create=b.dDate_Create, a.pinpai=b.pinpai, a.pinpaino=b.pinpaino, a.bNo_Modify=b.bNo_Modify, 
				a.cAccountNo=b.cAccountNo, a.cAccountName=b.cAccountName, a.bHouqin=b.bHouqin,a.bDel=b.bDel
	    from [192.168.1.2].'+@ServerName+'.dbo.spxx a,#temp_spxx b 
	    where b.bupdated=1 and a.SpNo=b.SpNo
	
	    delete from dbo.spxx_WaitSend 
	    where spno in (select spno from #temp_spxx)  
 		end
   
    if @bData=1
		begin
			update posstation set bDownLoad=1
		end  


      
 ') 
end


GO
