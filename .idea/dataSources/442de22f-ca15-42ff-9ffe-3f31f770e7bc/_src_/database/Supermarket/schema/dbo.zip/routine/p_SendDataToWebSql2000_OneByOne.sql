/*
declare @iDays varchar(16)
declare @ServerName varchar(32)
set  @iDays='10'
set  @ServerName='pingguoyuan'
exec p_SendDataToWebSql2000_OneByOne  @iDays,@ServerName

空闲
*/

CREATE procedure [dbo].[p_SendDataToWebSql2000_OneByOne]
@iLt int,    ---- 条数。。。 
@iDays varchar(16),
@ServerName varchar(32)
as
begin
exec('
/*
	SET XACT_ABORT ON
	--begin distributed tran s1
	begin  tran s1
 
*/
		declare @bSendData bit
                set @bSendData=0	
		declare @date1_jiesuan datetime
		declare @date2_jiesuan datetime

		declare @date1_jiesuan_byguizu datetime
		declare @date2_jiesuan_byguizu datetime

		declare @date1_lsd datetime
		declare @date2_lsd datetime

		declare @date1_lsdsp datetime
		declare @date2_lsdsp datetime




		if  (select object_id(''tempdb..#temp_jiesuan'')) is not null
		drop table #temp_jiesuan
		select distinct top '+@iLt+' sheetno,zdriqi
		into #temp_jiesuan 
		from jiesuan  with (readpast) where zdriqi between dbo.getdaystr(getdate()-'+@iDays+') and dbo.getdaystr(getdate())
		and isnull(bSent,0)=0 and isnull(shishou,0)<>0
		order by zdriqi,sheetno

		if  (select object_id(''tempdb..#temp_jiesuan_byguizu'')) is not null
		drop table #temp_jiesuan_byguizu
		select distinct top '+@iLt+' sheetno,zdriqi
		into #temp_jiesuan_byguizu 
		from jiesuan_byguizu  with (readpast) where  zdriqi between dbo.getdaystr(getdate()-'+@iDays+') and dbo.getdaystr(getdate())
		and isnull(bSent,0)=0 and isnull(shishou,0)<>0
		order by zdriqi,sheetno

		if  (select object_id(''tempdb..#temp_lsd'')) is not null
		drop table #temp_lsd
		select distinct top '+@iLt+' lsdno,zdriqi
		into #temp_lsd 
		from lsd  with (readpast) where  zdriqi between dbo.getdaystr(getdate()-'+@iDays+') and dbo.getdaystr(getdate())
		and isnull(bSent,0)=0
		order by zdriqi,lsdno

		if  (select object_id(''tempdb..#temp_lsdsp'')) is not null
		drop table #temp_lsdsp
		select distinct top '+@iLt+' lsdno,zdriqi=lsriqi
		into #temp_lsdsp 
		from lsdsp  with (readpast) where  lsriqi between dbo.getdaystr(getdate()-'+@iDays+') and dbo.getdaystr(getdate())
		and isnull(bSent,0)=0
		order by lsriqi,lsdno

    if ((select count(*) from #temp_jiesuan)>0)
    begin
            set @date1_jiesuan=(select min(zdriqi) from #temp_jiesuan)
			set @date2_jiesuan=(select max(zdriqi) from #temp_jiesuan)
			
			insert into [192.168.1.2].'+@ServerName+'.dbo.jiesuan
			(zdriqi,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,jiaozhang,
			jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,shoukuanno,
			shoukuanname,orientmoney,leftmoney,storevalue,detail,bChoujiang,Tag_daily,iCardNo,
			cangkuno,iPayoff,bCancel,sheetNo_canceled
			)
			select zdriqi,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,jiaozhang,
			jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,shoukuanno,
			shoukuanname,orientmoney,leftmoney,storevalue,detail,bChoujiang,Tag_daily,iCardNo,
			cangkuno,iPayoff,bCancel,sheetNo_canceled
			from jiesuan
			with (readpast)
			where zdriqi between @date1_jiesuan and @date2_jiesuan and sheetno in (select sheetno from #temp_jiesuan)
						and isnull(shishou,0)<>0			

			update jiesuan set bSent=1
			where zdriqi between @date1_jiesuan and @date2_jiesuan and sheetno in (select sheetno from #temp_jiesuan)

    end
    if ((select count(*) from #temp_jiesuan_byguizu)>0)
    begin
            set @date1_jiesuan_byguizu=(select min(zdriqi) from #temp_jiesuan_byguizu)
			set @date2_jiesuan_byguizu=(select max(zdriqi) from #temp_jiesuan_byguizu)
             
             insert into [192.168.1.2].'+@ServerName+'.dbo.jiesuan_byguizu
			(zdriqi,sheetno,jstype,guizuno,guizu,mianzhi,zhekou,zhaoling,shishou,jstime,
			jiaozhang,jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
			shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,detail,Tag_daily,
			iCardNo,cangkuno,bCancel,sheetNo_canceled
			)
			select zdriqi,sheetno,jstype,guizuno,guizu,mianzhi,zhekou,zhaoling,shishou,jstime,
			jiaozhang,jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
			shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,detail,Tag_daily,
			iCardNo,cangkuno,bCancel,sheetNo_canceled
			from jiesuan_byguizu
			with (readpast)
			where zdriqi between @date1_jiesuan_byguizu and @date2_jiesuan_byguizu and sheetno in (select sheetno from #temp_jiesuan_byguizu)
						and isnull(shishou,0)<>0		
	
			update jiesuan_byguizu set bSent=1
			where zdriqi between @date1_jiesuan_byguizu and @date2_jiesuan_byguizu and sheetno in (select sheetno from #temp_jiesuan_byguizu)
   
    end
    if ((select count(*) from #temp_lsd)>0)
    begin
            set @date1_lsd=(select min(zdriqi) from #temp_lsd)
			set @date2_lsd=(select max(zdriqi) from #temp_lsd)
insert into [192.168.1.2].'+@ServerName+'.dbo.lsd
			(zdriqi,lsdNo,Bumen,BumenNo,Xsy,ZdRen,Beizhu,Jine,Yingshou,Shishou,Mlt,Mltren,Yhkno,Yhl,
			Youhui,Chengben,Lirun,Jiecun,Netjiecun,ojine,tjine,kehuno,kehu,kenuren,xstime,hongchongno,
			xsyno,shenhe,shenheren,leixing,xsleixing,guizu,guizuno,jiesuanover,jiesuanno,jiesuanriqi,
			daogouyuanno,daogouyuan,fukuan,vipno,moneyno,pandianno,Tag_daily,lsdno_cate,sourcePos,
			iCardNo,cangkuno,cClientNO,bCancel,lsdNo_canceled)
			select 
			zdriqi,lsdNo,Bumen,BumenNo,Xsy,ZdRen,Beizhu,Jine,Yingshou,Shishou,Mlt,Mltren,Yhkno,Yhl,
			Youhui,Chengben,Lirun,Jiecun,Netjiecun,ojine,tjine,kehuno,kehu,kenuren,xstime,hongchongno,
			xsyno,shenhe,shenheren,leixing,xsleixing,guizu,guizuno,jiesuanover,jiesuanno,jiesuanriqi,
			daogouyuanno,daogouyuan,fukuan,vipno,moneyno,pandianno,Tag_daily,lsdno_cate,sourcePos,
			iCardNo,cangkuno,cClientNO,bCancel,lsdNo_canceled
			from lsd
			with (readpast)
			where zdriqi between @date1_lsd and @date2_lsd 
			and lsdno in (select lsdno from #temp_lsd)

			update lsd set bSent=1
			where zdriqi between @date1_lsd and @date2_lsd and lsdno in (select lsdno from #temp_lsd)

    end
    if ((select count(*) from #temp_lsdsp)>0)
    begin
			set @date1_lsdsp=(select min(zdriqi) from #temp_lsdsp)
			set @date2_lsdsp=(select max(zdriqi) from #temp_lsdsp)

			
			insert into [192.168.1.2].'+@ServerName+'.dbo.lsdsp
			(Lsriqi,LsdNo,Pnumber,SpNo,Tiaoma,Mingcheng,Danwei,Shuliang,Danjia,Jine,Cangku,CangkuNo,
			Number,Bumen,Yyy,Leftsl,Chengben,lstime,Belong,Jinlv,Jiecun,Netjiecun,Isck,beizhu,cycle,
			thevalue,lingtou,taxirate,ojine,tjine,xingzhi,zhongliang,yingshou,zhekou,zhekoulv,hyzhekoulv,
			chongjian,guige,lirun,maozhong,pizhong,xsleixing,guizu,guizuno,huiyuanjia,daogouyuanno,
			daogouyuan,pandian,jiesuanover,jiesuanno,pandianno,Tag_daily,fuwuqu,piaohao,paino,lsdno_cate,sourcePos,
			iCardNo,SheetNo_Install,SheetNo_Deliver,bCancel,lsdNo_canceled
			)
			select Lsriqi,LsdNo,Pnumber,SpNo,Tiaoma,Mingcheng,Danwei,Shuliang,Danjia,Jine,Cangku,CangkuNo,
			Number,Bumen,Yyy,Leftsl,Chengben,lstime,Belong,Jinlv,Jiecun,Netjiecun,Isck,beizhu,cycle,
			thevalue,lingtou,taxirate,ojine,tjine,xingzhi,zhongliang,yingshou,zhekou,zhekoulv,hyzhekoulv,
			chongjian,guige,lirun,maozhong,pizhong,xsleixing,guizu,guizuno,huiyuanjia,daogouyuanno,
			daogouyuan,pandian,jiesuanover,jiesuanno,pandianno,Tag_daily,fuwuqu,piaohao,paino,lsdno_cate,sourcePos,
			iCardNo,SheetNo_Install,SheetNo_Deliver,bCancel,lsdNo_canceled
			from lsdsp
			with (readpast)
			where lsriqi between @date1_lsdsp and @date2_lsdsp 
			and lsdno in (select lsdno from #temp_lsdsp)
			
			update lsdsp set bSent=1
			where lsriqi between @date1_lsdsp and @date2_lsdsp and lsdno in (select lsdno from #temp_lsdsp)

			
	end
/*
	commit tran s1
*/
')
	/*
	if @@Error<>0
	begin
		insert into tmp(spno) values (dbo.getdaystr(getdate()))
	end
	*/
end


GO
