
CREATE      procedure p_Shanghu_Hetong_save
@gysno  varchar(32),
@gysmc  varchar(64),
@guizuno  varchar(32),
@jingyingfanwei  varchar(256),
@mingcheng  varchar(64),
@leixing  varchar(32),
@dianhua  varchar(32),
@serno  varchar(32),
--@guizuno  varchar(32),
--@yuangongrenshu  varchar(32),
--@yuangonggongzi  varchar(32),
@thebank  varchar(32),
@thebankno  varchar(32),
@jingli  varchar(32),
@weizhino varchar(64),
@weizhi varchar(64),
@danjia  money,
@mianji  money,
@youhui  money,
@dazhe  money,
@fangzuyingshou  money,
@fangzushishou  money,
@jingyingfangshi  varchar(32),
@koudian  money,
@baodijine  money,
@taxno  varchar(32),
@baozhengjin  money,
@qixian1  datetime,
@qixian2  datetime,
@qianyueriqi  datetime,
@qianyueren  varchar(32),
@guanlifei money,
@koudianfangshi smallint

as
begin
delete from shanghu_hetong where guizuno=@guizuno
insert into shanghu_hetong (gysno,gysmc,
 jingyingfanwei,mingcheng,leixing,dianhua,serno,guizuno,thebank,thebankno,jingli,weizhino,weizhi,
 danjia,mianji,youhui,dazhe,fangzuyingshou,fangzushishou,jingyingfangshi,
 koudian,baodijine,taxno,baozhengjin,qixian1,qixian2,qianyueriqi,qianyueren,guanlifei,koudianfangshi
)
values(@gysno,@gysmc,
 @jingyingfanwei,@mingcheng,@leixing,@dianhua,@serno,
@guizuno,@thebank,@thebankno,@jingli,@weizhino,@weizhi,
 @danjia,@mianji,@youhui,@dazhe,@fangzuyingshou,@fangzushishou,@jingyingfangshi,
 @koudian,@baodijine,@taxno,@baozhengjin,@qixian1,@qixian2,@qianyueriqi,@qianyueren,@guanlifei,@koudianfangshi
)

end


GO
