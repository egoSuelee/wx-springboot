


CREATE         procedure p_Statistic_2_8_byGuizu_byPeriod_Right
@date1 datetime,
@date2 datetime,
@guizuno varchar(32)/*空 表示所有所有商户*/,
@Ratio money,
--@spno varchar(32)/*空 表示所有商品*/
@quno varchar(32),@jingyingfangshi varchar(32),@kind varchar(32)
as
begin
  if (select object_id('tempdb..#tempTypeNo')) is not null
  drop table #tempTypeNo

  create table #tempTypeNo(typeno varchar(64))

	declare @cNode varchar(64)
	declare @Fieldname varchar(64)
	declare @Fieldname_parent varchar(64)
	declare @TableName varchar(64)
	declare @bBoolean char(1)--是否显示非叶子节点
	set @cNode=dbo.trim(@quno)
	set @Fieldname='diquno'
	set @Fieldname_parent='cParentNo'
	set @TableName='diqu'
	set @bBoolean='1'
  
	insert into #tempTypeNo(typeno)
  exec supermarket.dbo.p_GetChildren @cNode,@Fieldname,@Fieldname_parent,@TableName,@bBoolean
		
    select a.guizuno,a.guizu,guizuweizhi.iLevel,fLevelRatio=isnull(guizuweizhi.fLevelRatio,1.0)
    into #guizu
    from guizu a
    left join 
    (
      select b.guizuno,c.iLevel,c.fLevelRatio from shanghu_hetong b left join weizhi c  on b.weizhino=c.weizhino
    ) guizuweizhi
    on a.guizuno=guizuweizhi.guizuno
    where (a.quno in (select quno=typeno from #tempTypeNo) or @quno='<全部>' )
          and (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' )
          and a.guizuno in (select distinct guizuno from spxx 
                            where kind=@kind or @kind='<全部>' )
          and (a.guizuno=@guizuno or @guizuno='<全部>')

--  select * from #guizu --where guizuno='88008'

  select a.guizuno,fSaleMoney_orient=sum(isnull(a.jine,0.0)) ,
         fSaleMoney=sum(isnull(a.jine*b.fLevelRatio,0.0)),fLevelRatio=sum(b.fLevelRatio)/count(a.guizuno) 
  into #lsdsp_sales_0
	from lsdsp a
  left join #guizu b on a.guizuno=b.guizuno
  where a.lsriqi between @date1 and @date2
        and (a.guizuno in (select a.guizuno from #guizu )) 
  group by a.guizuno

  select * 
  into #lsdsp_sales
  from #lsdsp_sales_0
  where fLevelRatio is not null

--  print 'hello'

  
  set @Ratio=@Ratio/100.0
  
  select fSumSales=isnull(sum(fSaleMoney),1),fSumSaleMoney_orient=isnull(sum(fSaleMoney_orient),1)
  into #lsdsp_sales_sumBySpno
  from #lsdsp_sales

  if (select top 1 fSumSales from #lsdsp_sales_sumBySpno )=0 
  begin
   select guizuno='ZZZZZZZZ'
   return
  end  

  select a.guizuno,a.fSaleMoney,a.fSaleMoney_orient,b.fSumSales,b.fSumSaleMoney_orient,
				 Ratio=(a.fSaleMoney/(b.fSumSales/1.0)),Ratio_left=-100.00000000000000000
  into #lsdsp_sales_Ratio
  from #lsdsp_sales a
  left join #lsdsp_sales_sumBySpno b
  on 1=1

  select * 
  into #lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio

  declare cursor_Ratio cursor
  for  
  select guizuno,Ratio
  from #lsdsp_sales_Ratio
  order by fSaleMoney desc

	open cursor_Ratio

  declare @guizuno_old varchar(32)
  declare @Ratio_left money
  set @Ratio_left=@Ratio

 
	declare @guizuno_c varchar(32)
  declare @Ratio_c float

--print '0:'+cast(@Ratio as varchar(32))
  
  Fetch next from cursor_Ratio
  into @guizuno_c,@Ratio_c
  
  while @@Fetch_status = 0
  begin
/*
    if (@iYear_c<>@iYear_old) or (@iMonth_c<>@iMonth_old)
    begin
      set @Ratio_left=@Ratio
    end
*/
    update #lsdsp_sales_Ratio_last set Ratio_left=@Ratio_left-Ratio
    where guizuno=@guizuno_c

      
    set @Ratio_left=@Ratio_left-@Ratio_c            



	  Fetch next from cursor_Ratio
    into @guizuno_c,@Ratio_c
  end  

  close cursor_Ratio	 
  deallocate cursor_Ratio
/*
  select 柜组编号=a.guizuno,柜组名称=b.guizu,柜组营业额=a.fSaleMoney,总销售额=a.fSumSales,
				 占比例=a.Ratio*100--,a.Ratio_left
  from #lsdsp_sales_Ratio_last a
  left join guizu b
  on a.guizuno=b.guizuno
  where a.Ratio_left>=0 or (a.Ratio_left<=0  and a.Ratio*8.0/10.0>=abs(a.Ratio_left))
  order by a.fSaleMoney desc
*/
  select 柜组编号=a.guizuno,柜组名称=b.guizu,柜组加权营业额=a.fSaleMoney,
/*
         case when (b.mianji=0) or b.mianji is null then a.fSaleMoney
              else a.fSaleMoney/b.mianji
         end 单位面积效益
         ,
*/
         总权销售额=a.fSumSales,
				 百分比=a.Ratio*100--,a.fSumSaleMoney_orient,a.fSaleMoney_orient--,a.Ratio_left
--  into #lsdsp_sales_Ratio_last_tmp
  from #lsdsp_sales_Ratio_last a
  left join guizu b
  on a.guizuno=b.guizuno
  where a.Ratio_left>=0 or (a.Ratio_left<=0  and a.Ratio*8.0/10.0>=abs(a.Ratio_left))
  order by a.fSaleMoney desc

  
end


GO
