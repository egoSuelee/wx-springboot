






CREATE       procedure [dbo].[p_Statistic_2_8_byGuizu_byPeriod_avg]
@date1 datetime,
@date2 datetime,
@guizuno varchar(32)/*空 表示所有所有商户*/,
@Ratio money,
--@spno varchar(32)/*空 表示所有商品*/
@quno varchar(32),@jingyingfangshi varchar(32),@kind varchar(32)
as
begin
    select a.guizuno,a.guizu,
           case when a.mianji=0 or a.mianji is null then 1
                else a.mianji
           end mianji
    into #guizu
    from guizu a
    where (a.quno=@quno or @quno='<全部>' )
          and (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' )
          and a.guizuno in (select distinct guizuno from spxx 
                            where kind=@kind or @kind='<全部>' )
          and (a.guizuno=@guizuno or @guizuno='<全部>')

  select guizuno,			 
         fSaleMoney=sum(isnull(jine,0.0)) 
  into #lsdsp_sales
	from lsdsp
  where lsriqi between @date1 and @date2
        and (guizuno in (select guizuno from #guizu )) 
  group by guizuno


  set @Ratio=@Ratio/100.0
  
  select fSumSales=isnull(sum(fSaleMoney),1)
  into #lsdsp_sales_sumBySpno
  from #lsdsp_sales

  if (select top 1 fSumSales from #lsdsp_sales_sumBySpno )=0 
  begin
   select guizuno='ZZZZZZZZ'
   return
  end  

  select a.guizuno,a.fSaleMoney,b.fSumSales,
				 Ratio=(a.fSaleMoney/(b.fSumSales/1.0)),Ratio_left=-100.00000000000000000
  into #lsdsp_sales_Ratio
  from #lsdsp_sales a
  left join #lsdsp_sales_sumBySpno b
  on 1=1

  select * 
  into #lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio

  declare cursor_Ratio cursor
  for  
  select guizuno,Ratio
  from #lsdsp_sales_Ratio
  order by fSaleMoney desc

	open cursor_Ratio

  declare @guizuno_old varchar(32)
  declare @Ratio_left money
  set @Ratio_left=@Ratio

 
	declare @guizuno_c varchar(32)
  declare @Ratio_c float

--print '0:'+cast(@Ratio as varchar(32))
  
  Fetch next from cursor_Ratio
  into @guizuno_c,@Ratio_c
  
  while @@Fetch_status = 0
  begin
/*
    if (@iYear_c<>@iYear_old) or (@iMonth_c<>@iMonth_old)
    begin
      set @Ratio_left=@Ratio
    end
*/
    update #lsdsp_sales_Ratio_last set Ratio_left=@Ratio_left-Ratio
    where guizuno=@guizuno_c

      
    set @Ratio_left=@Ratio_left-@Ratio_c            



	  Fetch next from cursor_Ratio
    into @guizuno_c,@Ratio_c
  end  

  close cursor_Ratio	 
  deallocate cursor_Ratio

  if  (select object_id('tempdb..##lsdsp_sales_Ratio_last')) is not null 
  drop table ##lsdsp_sales_Ratio_last

 
  select 柜组编号=a.guizuno,柜组名称=b.guizu,柜组营业额=a.fSaleMoney,
				 单位面积效益=a.fSaleMoney/isnull(b.mianji,1),总销售额=a.fSumSales,
				 占比例=a.Ratio*100--,a.Ratio_left
  into ##lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio_last a
  left join #guizu b
  on a.guizuno=b.guizuno
  order by a.fSumSales
--  where a.Ratio_left>=0 or (a.Ratio_left<=0  and a.Ratio*8.0/10.0>=abs(a.Ratio_left))
--  select * from ##lsdsp_sales_Ratio_last
  
end


GO
