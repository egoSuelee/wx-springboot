
CREATE  procedure p_Statistic_2_8_bySpno
@period int,/*0表示全年*/
@kind varchar(32)/*空 表示所有类型*/,
@Ratio money
--@spno varchar(32)/*空 表示所有商品*/
as
begin
  select a.lsdno,a.spno,a.pnumber,a.lsriqi,a.jine,kind=isnull(b.kind,'')
  into #lsdsp
  from lsdsp a
  left join spxx b
  on a.spno=b.spno

  select iYear=year(lsriqi),
				 iMonth=month(lsriqi),
	       spno,			 
         fSaleMoney=sum(isnull(jine,0.0)) 
  into #lsdsp_sales
	from #lsdsp
  where (month(lsriqi)=@period or @period=0)
    and (kind=@kind or dbo.trim(@kind)='') 
  group by spno,year(lsriqi),month(lsriqi)


  set @Ratio=@Ratio/100.0
  
  select iYear,iMonth,fSumSales=sum(fSaleMoney)
  into #lsdsp_sales_sumBySpno
  from #lsdsp_sales
  group by iYear,iMonth


  select a.iYear,a.iMonth,a.spno,a.fSaleMoney,b.fSumSales,
				 Ratio=(a.fSaleMoney/(b.fSumSales/1.0)),Ratio_left=-100.00000000000000000
  into #lsdsp_sales_Ratio
  from #lsdsp_sales a
  left join #lsdsp_sales_sumBySpno b
  on a.iYear=b.iYear and a.iMonth=b.iMonth

  select * 
  into #lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio

  declare cursor_Ratio cursor
  for  
  select iYear,iMonth,spno,Ratio
  from #lsdsp_sales_Ratio
  order by iYear,iMonth,fSaleMoney desc

	open cursor_Ratio
  declare @iYear_old int
	declare @iMonth_old int
  declare @Ratio_left money
  set @Ratio_left=@Ratio

  declare @iYear_c int
	declare @iMonth_c int
	declare @spno_c varchar(32)
  declare @Ratio_c float

  
  Fetch next from cursor_Ratio
  into @iYear_c,@iMonth_c,@spno_c,@Ratio_c
  
  while @@Fetch_status = 0
  begin

    if (@iYear_c<>@iYear_old) or (@iMonth_c<>@iMonth_old)
    begin
      set @Ratio_left=@Ratio
    end

    update #lsdsp_sales_Ratio_last set Ratio_left=@Ratio_left-Ratio
    where iYear=@iYear_c and iMonth=@iMonth_c and spno=@spno_c

      
    set @Ratio_left=@Ratio_left-@Ratio_c            


    set @iYear_old=@iYear_c
    set @iMonth_old=@iMonth_c

	  Fetch next from cursor_Ratio
	  into @iYear_c,@iMonth_c,@spno_c,@Ratio_c
  end  

  close cursor_Ratio	 
  deallocate cursor_Ratio

  select a.iYear,a.iMonth,a.spno,b.guizuno,b.guizu,a.fSaleMoney,a.fSumSales,
				 a.Ratio,a.Ratio_left
  from #lsdsp_sales_Ratio_last a
  left join spxx b
  on a.spno=b.spno
  where a.Ratio_left>=0
  order by a.iYear,a.iMonth,a.fSaleMoney desc
  
  
end

GO
