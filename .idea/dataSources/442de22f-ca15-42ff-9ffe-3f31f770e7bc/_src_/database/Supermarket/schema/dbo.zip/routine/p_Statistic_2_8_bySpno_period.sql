



CREATE     procedure p_Statistic_2_8_bySpno_period
@date1 datetime,
@date2 datetime,
@guizuno varchar(32)/*空 表示所有柜组*/,
@Ratio money,
@quno varchar(32),@jingyingfangshi varchar(32),@kind varchar(32)

--@spno varchar(32)/*空 表示所有商品*/
as
begin
 -- declare @period int
    select a.spno,a.guizuno,a.guizu
    into #spxx
     from spxx a
    where a.guizuno in (select guizuno from guizu where (quno=@quno or @quno='<全部>' ))
          and a.guizuno in 
             (select guizuno from guizu where (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' ))
          and a.spno in (select distinct spno from spxx 
                            where kind=@kind or @kind='<全部>' )
          and (a.guizuno=@guizuno or @guizuno='<全部>') 

--  select * from #spxx
  select spno,			 
         fSaleMoney=sum(isnull(jine,0.0)) 
  into #lsdsp_sales
	from lsdsp
  where lsriqi between @date1 and @date2
        and (spno in (select spno from #spxx )) 
  group by spno

--  select * from #lsdsp_sales

/*
  select a.lsdno,a.spno,a.pnumber,a.lsriqi,a.jine,kind=isnull(b.kind,'')
  into #lsdsp
  from lsdsp a
  left join spxx b
  on a.spno=b.spno

  select spno,			 
         fSaleMoney=sum(isnull(jine,0.0)) 
  into #lsdsp_sales
	from #lsdsp
  where lsriqi between @date1 and @date2
    and (kind=@kind or dbo.trim(@kind)='') 
  group by spno

*/

  set @Ratio=@Ratio/100.0
  
  select fSumSales=sum(fSaleMoney)
  into #lsdsp_sales_sumBySpno
  from #lsdsp_sales


  select a.spno,a.fSaleMoney,b.fSumSales,
				 Ratio=(a.fSaleMoney/(b.fSumSales/1.0)),Ratio_left=-100.00000000000000000
  into #lsdsp_sales_Ratio
  from #lsdsp_sales a
  left join #lsdsp_sales_sumBySpno b
  on 1=1

  select * 
  into #lsdsp_sales_Ratio_last
  from #lsdsp_sales_Ratio

  declare cursor_Ratio cursor
  for  
  select spno,Ratio
  from #lsdsp_sales_Ratio
  order by fSaleMoney desc

	open cursor_Ratio
  declare @Ratio_left money
  set @Ratio_left=@Ratio

	declare @spno_old varchar(32)
	declare @spno_c varchar(32)
  declare @Ratio_c float

  
  Fetch next from cursor_Ratio
  into @spno_c,@Ratio_c
  
  while @@Fetch_status = 0
  begin
/*
    if (@spno_c<>@spno_old)
    begin
      set @Ratio_left=@Ratio
    end
*/
    print @spno_c
    update #lsdsp_sales_Ratio_last set Ratio_left=@Ratio_left-Ratio
    where  spno=@spno_c

      
    set @Ratio_left=@Ratio_left-@Ratio_c            


    set @spno_old=@spno_c
 
	  Fetch next from cursor_Ratio
    into @spno_c,@Ratio_c
  end  

  close cursor_Ratio	 
  deallocate cursor_Ratio

  select 商品编号=a.spno,商品名称= b.mingcheng,柜组编号=b.guizuno,
				柜组名称=b.guizu,商品营业额=a.fSaleMoney,总销售额=a.fSumSales,
				 占比例=a.Ratio*100--,a.Ratio_left
  from #lsdsp_sales_Ratio_last a
  left join spxx b
  on a.spno=b.spno
  where a.Ratio_left>=0 or (a.Ratio_left<=0  and a.Ratio*8/10.0>=abs(a.Ratio_left))
  order by a.fSaleMoney desc
  

--select * from  #lsdsp_sales_Ratio_last 
end


GO
