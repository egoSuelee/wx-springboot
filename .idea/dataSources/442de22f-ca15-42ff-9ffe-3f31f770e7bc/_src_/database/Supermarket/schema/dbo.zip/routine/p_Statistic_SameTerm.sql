create procedure p_Statistic_SameTerm
@period int,/*0表示全年*/
@kind varchar(32),/*空 表示所有类型*/
@spno varchar(32)/*空 表示所有商品*/
as
begin
  select a.lsdno,a.spno,a.pnumber,a.lsriqi,a.jine,kind=isnull(b.kind,'')
  into #lsdsp
  from lsdsp a
  left join spxx b
  on a.spno=b.spno

  select iYear=year(lsriqi),
				 iMonth=month(lsriqi),
				 fSaleMoney=sum(isnull(jine,0)) 
	from #lsdsp
  where (month(lsriqi)=@period or @period=0)
    and (kind=@kind or dbo.trim(@kind)='') 
    and (spno=@spno or dbo.trim(@spno)='') 
  group by year(lsriqi),month(lsriqi)
  order by year(lsriqi),month(lsriqi)
end
GO
