
CREATE  procedure p_Statistic_SameTerm_byguizu
@date1 datetime,
@date2 datetime,
@period int,/*0表示全年*/
@guizuno varchar(32)/*空 表示所有柜组、业主*/
as
begin
  select a.lsdno,a.spno,a.guizuno,b.guizu,a.pnumber,a.lsriqi,a.jine
  into #lsdsp
  from lsdsp a
  left join guizu b
  on a.guizuno=b.guizuno
  where (a.guizuno=@guizuno or dbo.trim(@guizuno)='')
        and (month(a.lsriqi)=@period or @period=0) 
        and a.lsriqi between @date1 and @date2 

  select iYear=year(lsriqi),
				 iMonth=month(lsriqi),guizuno,guizu,
				 fSaleMoney=sum(isnull(jine,0)) 
  into #lsdsp_group
	from #lsdsp
  group by year(lsriqi),month(lsriqi),guizuno,guizu
  order by year(lsriqi),month(lsriqi),guizuno,guizu
  
  select iYear
  into #lsdsp_group_iYear
  from #lsdsp_group
  group by iYear

  select guizuno,guizu
  into #lsdsp_group_guizu
  from #lsdsp_group
  group by guizuno,guizu

  create table #month
  (
    iMonth int
  ) 
  insert into #month(iMonth) values(1)
  insert into #month(iMonth) values(2)
  insert into #month(iMonth) values(3)
  insert into #month(iMonth) values(4)
  insert into #month(iMonth) values(5)
  insert into #month(iMonth) values(6)
  insert into #month(iMonth) values(7)
  insert into #month(iMonth) values(8)
  insert into #month(iMonth) values(9)
  insert into #month(iMonth) values(10)
  insert into #month(iMonth) values(11)
  insert into #month(iMonth) values(12)


  create table #CubTable
  (
    柜组编号 varchar(32), 柜组名称   varchar(64),月份  int 
	)

  declare cursor_year cursor
  for
  select iYear=cast(iYear as varchar(16)) 
  from #lsdsp_group_iYear
  order by iYear

  declare @iYear varchar(16)
  declare @cAddFields varchar(2000)
  set @cAddFields=''
  declare @cUpdateFields varchar(2000)
  set @cUpdateFields='平均值=('
  open cursor_year  
  fetch next from cursor_year
  into @iYear
  declare @icount int

  if  (select object_id('tempdb..##tYear')) is not null 
  drop table ##tYear
  create table ##tYear
  (iYear varchar(32))

  set @icount=0
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+'['+@iYear+'] money,'
    set @cUpdateFields=@cUpdateFields+'isnull(['+@iYear+'],0)+'
    set @icount=@icount+1
    insert into ##tYear(iYear) values('['+@iYear+']')
    fetch next from cursor_year
    into @iYear

  end    
  close cursor_year  
  deallocate cursor_year  

  set @cAddFields=@cAddFields+'平均值 money'
  if @icount>0 
  begin
    set @cUpdateFields=@cUpdateFields+'0)/'+cast(cast(@icount as money) as varchar(32))
  end else
  begin
    set @cUpdateFields=@cUpdateFields+'0)'
  end
--  print @cAddFields
  exec( 'alter table #CubTable add '+@cAddFields)  

  insert into #CubTable (柜组编号,柜组名称,月份)
  select c.guizuno,c.guizu,c.iMonth
  from
  (select a.guizuno,a.guizu,b.iMonth
   from #lsdsp_group_guizu a
   left join #month b on 1=1
   ) c
  
    
  select guizuno,guizu,iYear=cast(iYear as varchar(4)),iMonth,fSaleMoney
  into #lsdsp_group_c
  from #lsdsp_group

  declare cursor_year cursor
  for
  select iYear=cast(iYear as varchar(16)) 
  from #lsdsp_group_iYear
  order by iYear

  set @cAddFields=''
  open cursor_year  
  fetch next from cursor_year
  into @iYear

  while @@fetch_status=0
  begin
    exec('
	  update a set a.['+@iYear+']=b.fSaleMoney
	  from #CubTable a
	  left join #lsdsp_group_c b
	  on a.柜组编号=b.guizuno and a.月份=b.iMonth and b.iYear='+@iYear
    )
    fetch next from cursor_year
    into @iYear

  end    
  close cursor_year  
  deallocate cursor_year  

  exec('  update #CubTable set '+ @cUpdateFields)

--select * from ##tYear
  if  (select object_id('tempdb..##CubTable')) is not null 
  drop table ##CubTable
  select * into ##CubTable from #CubTable  
  
  select * from ##CubTable  
  


end

GO
