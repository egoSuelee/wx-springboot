


CREATE    procedure p_Statistic_SameTerm_byguizu_other
@date1 datetime,
@date2 datetime,
@period int,/*0表示全年*/
@guizuno varchar(32),/*空 表示所有柜组、业主*/
@quno varchar(32),@jingyingfangshi varchar(32),@kind varchar(32)

as
begin
  if (select object_id('tempdb..#tempTypeNo')) is not null
  drop table #tempTypeNo

  create table #tempTypeNo(typeno varchar(64))

	declare @cNode varchar(64)
	declare @Fieldname varchar(64)
	declare @Fieldname_parent varchar(64)
	declare @TableName varchar(64)
	declare @bBoolean char(1)--是否显示非叶子节点
	set @cNode=dbo.trim(@quno)
	set @Fieldname='diquno'
	set @Fieldname_parent='cParentNo'
	set @TableName='diqu'
	set @bBoolean='1'
  
	insert into #tempTypeNo(typeno)
  exec supermarket.dbo.p_GetChildren @cNode,@Fieldname,@Fieldname_parent,@TableName,@bBoolean
		

    select a.guizuno,a.guizu
    into #guizu
     from guizu a
    where (a.quno in (select quno=typeno from #tempTypeNo) or @quno='<全部>' )
          and (jingyingfangshi=@jingyingfangshi or @jingyingfangshi='<全部>' )
          and a.guizuno in (select distinct guizuno from spxx 
                            where kind=@kind or @kind='<全部>' )
--  select * from #guizu
  
  select c.lsdno,c.spno,c.guizuno,c.guizu,c.pnumber,c.lsriqi,c.jine
    into #lsdsp
  from (
  select a.lsdno,a.spno,a.guizuno,b.guizu,a.pnumber,a.lsriqi,a.jine

  from lsdsp a
  left join #guizu b
  on a.guizuno=b.guizuno
  where (a.guizuno=@guizuno or dbo.trim(@guizuno)='')
        and (month(a.lsriqi)=@period or @period=0) 
        and a.lsriqi between @date1 and @date2 
  ) c
  where c.guizu is not null

--  select * from #lsdsp

  select iYear=year(lsriqi),
				 iMonth=month(lsriqi),guizuno,guizu,
				 fSaleMoney=sum(isnull(jine,0)) 
  into #lsdsp_group
	from #lsdsp
  group by year(lsriqi),month(lsriqi),guizuno,guizu
  order by year(lsriqi),month(lsriqi),guizuno,guizu
  
  select iYear
  into #lsdsp_group_iYear
  from #lsdsp_group
  group by iYear

  select guizuno,guizu
  into #lsdsp_group_guizu
  from #lsdsp_group
  group by guizuno,guizu

  create table #month
  (
    iMonth int
  ) 
  insert into #month(iMonth) values(1)
  insert into #month(iMonth) values(2)
  insert into #month(iMonth) values(3)
  insert into #month(iMonth) values(4)
  insert into #month(iMonth) values(5)
  insert into #month(iMonth) values(6)
  insert into #month(iMonth) values(7)
  insert into #month(iMonth) values(8)
  insert into #month(iMonth) values(9)
  insert into #month(iMonth) values(10)
  insert into #month(iMonth) values(11)
  insert into #month(iMonth) values(12)


  create table #CubTable
  (
    柜组编号 varchar(32), 柜组名称   varchar(64),月份  int 
	)

  declare cursor_year cursor
  for
  select iYear=cast(iYear as varchar(16)) 
  from #lsdsp_group_iYear
  order by iYear

  declare @iYear varchar(16)
  declare @cAddFields varchar(2000)
  set @cAddFields=''
  declare @cUpdateFields varchar(2000)
  set @cUpdateFields='平均值=('
  open cursor_year  
  fetch next from cursor_year
  into @iYear
  declare @icount int

  if  (select object_id('tempdb..##tYear')) is not null 
  drop table ##tYear
  create table ##tYear
  (iYear varchar(32))

  set @icount=0
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+'['+@iYear+'] money,'
    set @cUpdateFields=@cUpdateFields+'isnull(['+@iYear+'],0)+'
    set @icount=@icount+1
    insert into ##tYear(iYear) values('['+@iYear+']')
    fetch next from cursor_year
    into @iYear

  end    
  close cursor_year  
  deallocate cursor_year  

  set @cAddFields=@cAddFields+'平均值 money'
  if @icount>0 
  begin
    set @cUpdateFields=@cUpdateFields+'0)/'+cast(cast(@icount as money) as varchar(32))
  end else
  begin
    set @cUpdateFields=@cUpdateFields+'0)'
  end
--  print @cAddFields
  exec( 'alter table #CubTable add '+@cAddFields)  

  insert into #CubTable (柜组编号,柜组名称,月份)
  select c.guizuno,c.guizu,c.iMonth
  from
  (select a.guizuno,a.guizu,b.iMonth
   from #lsdsp_group_guizu a
   left join #month b on 1=1
   ) c
  
    
  select guizuno,guizu,iYear=cast(iYear as varchar(4)),iMonth,fSaleMoney
  into #lsdsp_group_c
  from #lsdsp_group

  declare cursor_year cursor
  for
  select iYear=cast(iYear as varchar(16)) 
  from #lsdsp_group_iYear
  order by iYear

  set @cAddFields=''
  open cursor_year  
  fetch next from cursor_year
  into @iYear

  while @@fetch_status=0
  begin
    exec('
	  update a set a.['+@iYear+']=b.fSaleMoney
	  from #CubTable a
	  left join #lsdsp_group_c b
	  on a.柜组编号=b.guizuno and a.月份=b.iMonth and b.iYear='+@iYear
    )
    fetch next from cursor_year
    into @iYear

  end    
  close cursor_year  
  deallocate cursor_year  

  exec('  update #CubTable set '+ @cUpdateFields)

--select * from ##tYear
  if  (select object_id('tempdb..##CubTable')) is not null 
  drop table ##CubTable
  select * into ##CubTable from #CubTable  
  
  select * from ##CubTable  
  


end


GO
