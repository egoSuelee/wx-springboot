create proc p_StorageBetweenDate_chen
@guizu varchar(32),
@dateBegin datetime,
@dateEnd datetime
as
set nocount on
begin
exec('
	if(select object_id(''tempdb..#temp_StorageBetweenDate1''))is not null
       drop table #temp_StorageBetweenDate1
	if(select object_id(''tempdb..#temp_StorageBetweenDate2''))is not null
       drop table #temp_StorageBetweenDate2
    if (select object_id(''tempdb..#rkd_sp0''))is not null
		drop table #rkd_sp0
	if (select object_id(''tempdb..#rkd_sp''))is not null
		drop table #rkd_sp
	if (select object_id(''tempdb..#jcd_sp0''))is not null
		drop table #jcd_sp0
	if (select object_id(''tempdb..#jcd_sp''))is not null
		drop table #jcd_sp
	if (select object_id(''tempdb..#ckd_sp0''))is not null
		drop table #ckd_sp0
	if (select object_id(''tempdb..#ckd_sp''))is not null
		drop table #ckd_sp
	if (select object_id(''tempdb..#fcd_sp0''))is not null
		drop table #fcd_sp0
	if (select object_id(''tempdb..#fcd_sp''))is not null
		drop table #fcd_sp
	if (select object_id(''tempdb..#syd_sp0''))is not null
		drop table #syd_sp0
	if (select object_id(''tempdb..#syd_sp''))is not null
		drop table #syd_sp
	if (select object_id(''tempdb..#lsd_sp0''))is not null
		drop table #lsd_sp0
	if (select object_id(''tempdb..#lsd_sp''))is not null
		drop table #lsd_sp
	if (select object_id(''tempdb..#temp_guizu_BetweenDate''))is not null
		drop table #temp_guizu_BetweenDate
	if (select object_id(''tempdb..#temp_rkdsp_betweenDate''))is not null
		drop table #temp_rkdsp_betweenDate 
	if (select object_id(''tempdb..#temp_rkd_sp''))is not null
		drop table #temp_rkd_sp 
	if (select object_id(''tempdb..#temp_jcdsp_betweenDate''))is not null
		drop table #temp_jcdsp_betweenDate 
	if (select object_id(''tempdb..#temp_jcd_sp''))is not null
		drop table  #temp_jcd_sp
	if (select object_id(''tempdb..#temp_ckdsp_betweenDate''))is not null
		drop table #temp_ckdsp_betweenDate 
	if (select object_id(''tempdb..#temp_ckd_sp''))is not null
		drop table #temp_ckd_sp  

	if (select object_id(''tempdb..#temp_fcdsp_betweenDate''))is not null
		drop table #temp_fcdsp_betweenDate
	if (select object_id(''tempdb..#temp_fcd_sp''))is not null
		drop table #temp_fcd_sp	
	if (select object_id(''tempdb..#temp_sydsp_betweenDate''))is not null
		drop table #temp_sydsp_betweenDate
	if (select object_id(''tempdb..#temp_syd_sp''))is not null
		drop table #temp_syd_sp	
	if (select object_id(''tempdb..#temp_lsdsp_betweenDate''))is not null
		drop table #temp_lsdsp_betweenDate
	if (select object_id(''tempdb..#temp_lsd_sp''))is not null
		drop table #temp_lsd_sp	
    if (select object_id(''tempdb..#temp_Storage_last'')) is not null
        drop table #temp_Storage_last
    if (select object_id(''tempdb..#temp_guizuno_belong'')) is not null
        drop table #temp_guizuno_belong
    if (select object_id(''tempdb..#temp_spxx0'')) is not null
        drop table #temp_spxx0
    if (select object_id(''tempdb..#temp_spxx'')) is not null
        drop table #temp_spxx
    if (select object_id(''tempdb..#temp_last_spxx'')) is not null
        drop table #temp_last_spxx
    if (select object_id(''tempdb..#temp_hj'')) is not null
        drop table #temp_hj

    --起初库存
    create table #temp_StorageBetweenDate1
	(
	 guizuno varchar(32),
	 spno varchar(32),
	 mingcheng varchar(100),
     shuliang money,
     jinjiajine money
    )
   --期末库存
	create table #temp_StorageBetweenDate2
	(
	 guizuno varchar(32),
	 spno varchar(32),
	 mingcheng varchar(100),
     shuliang money,
     jinjiajine money
    )
   	create table #temp_Storage_last
	(
	 guizuno varchar(32),
	 spno varchar(32),
	 mingcheng varchar(100),
     Cw_begin money default(0),
     cw_begin_jine money default(0),
	 Cw_end  money default(0),
     cw_end_jine money default(0),
	 rk_shuliang money default(0),
     rk_jine money default(0),
	 jc_shuliang money default(0),
	 jc_jine money default(0),
     ck_shuliang money default(0),
	 ck_jine money default(0),
     fc_shuliang money default(0),
	 fc_jine money default(0),
     sy_shuliang money default(0),
     sy_jine money default(0),
     ls_shuliang money default(0),
     ls_jine money default(0),
     shuliang money default(0)
    )
	insert #temp_StorageBetweenDate1(guizuno,spno,mingcheng,shuliang,jinjiajine)
	exec p_lookupStorageByGuizuByTable_chen '''+@guizu+''','''+@dateBegin+''''+'
	
	insert #temp_StorageBetweenDate2(guizuno,spno,mingcheng,shuliang,jinjiajine)
	exec p_lookupStorageByGuizuByTable_chen '''+@guizu+''','''+@dateEnd+''''+'
    
    --需要管理库存的商品号，柜组号   select * from spxx
	select  guizuno,spno 
	into #temp_guizu_BetweenDate 
	from spxx 
	where selected=1 and guizuno in(select guizu from '+@guizu+')'+'
	order by guizuno

    
    select guizuno,spno,belong
    into #temp_guizuno_belong   --drop table #temp_spxx
    from spxx
    where selected=1 and guizuno in(select guizu from '+@guizu+')'+'
	order by guizuno   

   update a set a.spno=b.spno from #temp_guizuno_belong a,spxx b where a.belong=b.spno
   select distinct guizuno,spno 
   into #temp_spxx0 
   from #temp_guizuno_belong
 
   select a.guizuno,a.spno,b.mingcheng
   into #temp_spxx
   from #temp_spxx0 a left join spxx b
   on a.spno=b.spno
    

---rkd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jinjiajine,0))
    into #temp_rkdsp_betweenDate
	from #temp_guizu_BetweenDate a left join rkd_sp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.zdriqi>'''+@dateBegin+''' and b.zdriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno

    select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #rkd_sp0     --drop table #rkd_sp0 
	from #temp_rkdsp_betweenDate a left join spxx b 
	on a.spno=b.spno 
    group by a.spno,a.guizuno,b.belong
    update a set a.spno=b.spno from #rkd_sp0 a,spxx b where a.belong=b.spno     
    select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #temp_rkd_sp 
    from #rkd_sp0 group by guizuno,spno

--jcd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jinjiajine,0))
    into #temp_jcdsp_betweenDate
	from #temp_guizu_BetweenDate a left join jcd_sp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.zdriqi>'''+@dateBegin+''' and b.zdriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno

	select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
	into #jcd_sp0 
	from #temp_jcdsp_betweenDate a left join spxx b  
    on a.spno=b.spno 	 
   	group by a.spno,a.guizuno,b.belong 
	update a set a.spno=b.spno from #jcd_sp0 a,spxx b where a.belong=b.spno             
	select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0))
	into #temp_jcd_sp 
    from #jcd_sp0 group by guizuno,spno     --select * from #temp_jcd_sp

--ckd_sp  select * from ckd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jinjiajine,0))
    into #temp_ckdsp_betweenDate
	from #temp_guizu_BetweenDate a left join ckd_sp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.zdriqi>'''+@dateBegin+''' and b.zdriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno
	
	select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
	into #ckd_sp0 
	from #temp_ckdsp_betweenDate a left join spxx b 
	on a.spno=b.spno 
	group by a.spno,a.guizuno,b.belong 
	update a set a.spno=b.spno from #ckd_sp0 a,spxx b where a.belong=b.spno 
	select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #temp_ckd_sp 
	from #ckd_sp0 group by guizuno,spno   --select * from #temp_ckd_sp

--fcd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jinjiajine,0))
    into #temp_fcdsp_betweenDate
	from #temp_guizu_BetweenDate a left join fcd_sp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.zdriqi>'''+@dateBegin+''' and b.zdriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno
	
	select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
	into #fcd_sp0 
	from #temp_fcdsp_betweenDate a left join spxx b 
	on a.spno=b.spno 
	group by a.spno,a.guizuno,b.belong 
	update a set a.spno=b.spno from #fcd_sp0 a,spxx b where a.belong=b.spno 
	select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #temp_fcd_sp 
	from #fcd_sp0 group by guizuno,spno

--select * from syd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jinjiajine,0))
    into #temp_sydsp_betweenDate
	from #temp_guizu_BetweenDate a left join syd_sp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.zdriqi>'''+@dateBegin+''' and b.zdriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno

    select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
    into #syd_sp0    --drop table #syd_sp0
	from #temp_sydsp_betweenDate a left join spxx b 
    on a.spno=b.spno 
	group by a.spno,a.guizuno,b.belong
	update a set a.spno=b.spno from #syd_sp0 a,spxx b where a.belong=b.spno   
	select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #temp_syd_sp    --drop table #temp_syd_sp
    from #syd_sp0 group by guizuno,spno


--lsd_sp
	select  a.guizuno,a.spno,shuliang=sum(isnull(b.shuliang,0)),jinjiajine=sum(isnull(b.jine,0))
    into #temp_lsdsp_betweenDate
	from #temp_guizu_BetweenDate a left join lsdsp b
    on a.guizuno=b.guizuno and a.spno=b.spno and b.Lsriqi>'''+@dateBegin+''' and b.Lsriqi<='''+@dateEnd+''''+'
    group by a.guizuno,a.spno
	
	select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
	into #Lsd_sp0 
	from #temp_lsdsp_betweenDate a left join spxx b 
	on a.spno=b.spno 
	group by a.spno,a.guizuno,b.belong 
	update a set a.spno=b.spno from #Lsd_sp0 a,spxx b where a.belong=b.spno 
	select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
	into #temp_lsd_sp 
	from #Lsd_sp0 group by guizuno,spno


/*
--	select a.guizuno,a.spno,a.mingcheng,shuliang=(isnull(a.shuliang,0)-isnull(b.shuliang,0)),
--	jinjiajine=(isnull(a.jinjiajine,0)-isnull(b.jinjiajine,0))
--  from #temp_StorageBetweenDate1 a left join #temp_StorageBetweenDate2 b
--  on a.guizuno=b.guizuno and a.spno=b.spno
	select * from #temp_StorageBetweenDate1
	select * from #temp_StorageBetweenDate2
	select * from #temp_Storage_last      --delete #temp_Storage_last
*/

  insert into #temp_Storage_last(guizuno,spno,mingcheng)
  select guizuno,spno,mingcheng from #temp_spxx
  
  
  update a
  set a.cw_begin=isnull(b.shuliang,0),a.cw_begin_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_StorageBetweenDate1 b
  on a.guizuno=b.guizuno and a.spno=b.spno
  

  update a
  set a.cw_end=isnull(b.shuliang,0),a.cw_end_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_StorageBetweenDate2 b
  on a.guizuno=b.guizuno and a.spno=b.spno
  

  update a
  set a.rk_shuliang=isnull(b.shuliang,0),a.rk_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_rkd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno


  update a
  set a.jc_shuliang=isnull(b.shuliang,0),a.jc_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_jcd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno


  update a
  set a.ck_shuliang=isnull(b.shuliang,0),a.ck_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_ckd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno

  update a
  set a.fc_shuliang=isnull(b.shuliang,0),a.fc_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_fcd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno

  update a
  set a.sy_shuliang=isnull(b.shuliang,0),a.sy_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_syd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno

  update a
  set a.Ls_shuliang=isnull(b.shuliang,0),a.ls_jine=isnull(b.jinjiajine,0)
  from  #temp_Storage_last a left join #temp_lsd_sp b
  on a.guizuno=b.guizuno and a.spno=b.spno

  update a
  set a.shuliang=abs(isnull(a.cw_begin,0)-isnull(a.cw_end,0))
  from #temp_Storage_last a
  
  select 
  case grouping(guizuno) when 0 then guizuno
					     when 1 then ''总计:''end as guizuno,
  case grouping(spno) when 0 then spno
					  when 1 then ''柜组商品合计:''end as spno,cw_begin=sum(isnull(cw_begin,0)),
  cw_begin_jine=sum(isnull(cw_begin_jine,0)),cw_end=sum(isnull(cw_end,0)),cw_end_jine=sum(isnull(cw_end_jine,0)),rk_shuliang=sum(isnull(rk_shuliang,0)),
  rk_jine=sum(isnull(rk_jine,0)),jc_shuliang=sum(isnull(jc_shuliang,0)),jc_jine=sum(isnull(jc_jine,0)),ck_shuliang=sum(isnull(ck_shuliang,0)),
  ck_jine=sum(isnull(ck_jine,0)),fc_shuliang=sum(isnull(fc_shuliang,0))
  ,fc_jine=sum(isnull(fc_jine,0)),sy_shuliang=sum(isnull(sy_shuliang,0)),sy_jine=sum(isnull(sy_jine,0)),
  ls_shuliang=sum(isnull(ls_shuliang,0)), ls_jine=sum(isnull(ls_jine,0)),shuliang=sum(isnull(shuliang,0))
  into #temp_last_spxx	
  from #temp_Storage_last
  group by guizuno,spno with rollup

  select a.guizuno,a.spno,b.mingcheng,/*mingcheng=isnull(b.mingcheng,''--''),*/cw_begin,cw_begin_jine,cw_end,cw_end_jine,rk_shuliang,rk_jine,
  jc_shuliang,jc_jine,ck_shuliang,ck_jine,fc_shuliang,fc_jine,sy_shuliang,sy_jine,ls_shuliang,ls_jine,shuliang
  into #temp_hj
  from #temp_last_spxx a  left join spxx b
  on a.spno=b.spno 
  order by a.guizuno,a.spno

  update a
  set a.mingcheng=''柜组名称:''+(select distinct b.guizu from spxx  b where isnull(b.guizuno,0)=a.guizuno)
  from #temp_hj a
  where (a.mingcheng is null) and a.guizuno<>''总计:''
  

  update #temp_hj
  set mingcheng=''全部柜组合计''
  where (mingcheng is null) and guizuno=''总计:''

  select * from #temp_hj
')

   

end

GO
