

CREATE procedure [dbo].[p_Supplier_Fee_AutoGen_Pre]
@cSupplierNo varchar(32),
@dDate_Finance datetime,-----财务日期
@dDate_Start datetime,
@dDate_End datetime,
@cWhNo varchar(32),
@cOper varchar(32)
as
begin
	/*所生成的费用暂存在[t_Supplier_fee_Waiting]中，审核通过后 保存在t_Supplier_fee表中*/
	/* @dDate_Start--- @dDate_End 必须日结*/
	/*计算本时段该供应商作为主供应商的商品销售结算情况 dbo.jiesuan_daily*/
	delete from t_Supplier_fee_Waiting where cSupplierno=@cSupplierNo and isnull(bAuto,0)=1
	select zdriqi,detail,shishou=SUM(isnull(shishou,0))
	into #temp_jiesuan_daily_Auto_PerDate
	from jiesuan_byguizu
	where zdriqi between @dDate_Start and @dDate_End and guizuno=@cSupplierNo
	group by zdriqi,detail

  declare @cSupplier varchar(64)
  declare @feiyongno varchar(32) 
  declare @feiyong varchar(64) 
  declare @feiyongjine money 
  declare @bSale_Period_Total bit
  declare @bSale_Period_AfterTax bit 
  declare @bJiesuan_Def bit
  declare @cJiesuan_detail varchar(32)
  declare @fRatio money --------扣率
  declare @iDays int 
  declare @dDays_Last datetime -----最近一次执行日期
  declare @dDate_Start_0 datetime -----开始日期
  declare @dDate_End_0 datetime -----结束日期
  declare @detail varchar(64) -----------beizhu
  declare @iDays_Per int
  declare @iDate int
  declare @fMoney money
  declare @fMoney_Ref money
  declare @fMoney_Ratio money
  declare @beizhu varchar(64)
  declare @serno bigint
  declare @iTimes int
  
  set @cSupplier=(select guizu from guizu where guizuno=@cSupplierNo)
  declare Cur_fee_Gen cursor
  for
  select 
	feiyongno,  
	feiyong, feiyongjine,  
	bSale_Period_Total, bSale_Period_AfterTax, fRatio, 
	bJiesuan_Def, cJiesuan_detail, iDays, dDays_Last, 
	 detail, dDate_Start, iDays_Per, iDate, 
	fMoney, dDate_End, fMoney_Ref,serno
	from dbo.t_Supplier_fee_Gen
	where cSupplierNo=@cSupplierNo
	
  
  open Cur_fee_Gen
  fetch next from Cur_fee_Gen
  into @feiyongno,  
	@feiyong, @feiyongjine,  
	@bSale_Period_Total, @bSale_Period_AfterTax, @fRatio, 
	@bJiesuan_Def, @cJiesuan_detail, @iDays, @dDays_Last, 
	 @detail, @dDate_Start_0, @iDays_Per, @iDate, 
	@fMoney, @dDate_End_0, @fMoney_Ref,@serno
	
  while @@fetch_status=0
  begin
 --   if ((@dDays_Last is null) or (@dDays_Last<@dDate_Start) or (@dDate_End_0 is null)) and  (@dDate_Start_0 is not null) ---第一次执行或者 本时段没有执行
    if @dDate_End_0 is null  -----如果没有结束日期，则作以下处理
    begin
      set @dDate_End_0=@dDate_End
    end

    if (isnull(@dDays_Last,'2000-01-01')<@dDate_Start) and (isnull(@dDate_End_0,'2000-01-01')<=@dDate_End) and  (@dDate_Start_0 is not null)
    and ((@dDate_Start  between @dDate_Start_0 and @dDate_End_0) or (@dDate_End  between @dDate_Start_0 and @dDate_End_0))

       ---第一次执行或者 本时段没有执行
    begin
      set @fMoney_Ratio=null
			if isnull(@bSale_Period_Total,0)=1 ---以总销售为参考
			begin
			  set @fMoney_Ratio=(select shishou=SUM(shishou) from #temp_jiesuan_daily_Auto_PerDate where zdriqi between @dDate_Start_0 and @dDate_End_0)
        set @beizhu='总销售:'+CAST(@fMoney_Ratio as varchar(32))+',扣率:'+CAST(@fRatio as varchar(32))+'%'
        insert into t_Supplier_fee_Waiting(cSupplierNo, cSupplier, feiyongno, feiyong, feiyongjine,beizhu,caiwu,  
					zdriqi, zdtime,  riqi1, riqi2, dFill,bAuto,dFinance,Serno_Union)
				values(@cSupplierNo,@cSupplier,@feiyongno,@feiyong,round(@fMoney_Ratio*@fRatio/100,2),substring(@beizhu+' '+dbo.getDayStr(getdate())+' '+ dbo.getTimeStr(GETDATE()),1,64),@cOper,
				@dDate_Finance, dbo.getDayStr(@dDate_Finance)+' '+dbo.getTimeStr(GETDATE()),@dDate_Start,@dDate_End,dbo.getDayStr(getdate()),1,@dDate_Finance,@serno)
				--update t_Supplier_fee_Gen set dDays_Last=@dDate_End where serno=@serno

			end else
			if isnull(@bJiesuan_Def,0)=1 ---以期间收银科目为参考
			begin
			  set @fMoney_Ratio=(select shishou=SUM(shishou) 
													from #temp_jiesuan_daily_Auto_PerDate 
													where zdriqi between @dDate_Start_0 and @dDate_End_0
													and detail=@cJiesuan_detail
													)
        set @beizhu='销售科目:'+@cJiesuan_detail+' 金额:'+CAST(@fMoney_Ratio as varchar(32))+',扣率:'+CAST(@fRatio as varchar(32))+'%'
        insert into t_Supplier_fee_Waiting(cSupplierNo, cSupplier, feiyongno, feiyong, feiyongjine,beizhu,caiwu,  
					zdriqi, zdtime,  riqi1, riqi2, dFill,bAuto,dFinance,Serno_Union)
				values(@cSupplierNo,@cSupplier,@feiyongno,@feiyong,round(@fMoney_Ratio*@fRatio/100,2),substring(@beizhu+' '+dbo.getDayStr(getdate())+' '+ dbo.getTimeStr(GETDATE()),1,32),@cOper,
				@dDate_Finance, dbo.getDayStr(@dDate_Finance)+' '+dbo.getTimeStr(GETDATE()),@dDate_Start,@dDate_End,dbo.getDayStr(getdate()),1,@dDate_Finance,@serno)
				--update t_Supplier_fee_Gen set dDays_Last=@dDate_End where serno=@serno
			end else
			begin
        set @beizhu=null
        if @iDays_Per is not null
        begin
        
          if @iDays_Per>=(DATEDIFF(dd,@dDays_Last,@dDate_End))
          begin
            --@cOper 
            insert into t_Supplier_fee_Waiting(cSupplierNo, cSupplier, feiyongno, feiyong, feiyongjine,beizhu,caiwu,  
							zdriqi, zdtime,  riqi1, riqi2, dFill,bAuto,dFinance,Serno_Union)
						values(@cSupplierNo,@cSupplier,@feiyongno,@feiyong,@fMoney,substring('每'+CAST(@iDays_Per as varchar(32))+'天费用,'+dbo.getDayStr(getdate())+' '+ dbo.getTimeStr(GETDATE()),1,32),@cOper,
		    		@dDate_Finance, dbo.getDayStr(@dDate_Finance)+' '+dbo.getTimeStr(GETDATE()),@dDate_Start,@dDate_End,dbo.getDayStr(getdate()),1,@dDate_Finance,@serno)
						--update t_Supplier_fee_Gen set dDays_Last=@dDate_End where serno=@serno
          end
        end else
        if @iDate is not null
        begin
				  set @iTimes=dbo.f_GetPeriodTimes(@iDate,@dDate_Start,@dDate_End)
--          if (@iDate between DATEPART(dd,@dDate_Start) and DATEPART(dd,@dDate_End))
					if @iTimes>0
          begin
            insert into t_Supplier_fee_Waiting(cSupplierNo, cSupplier, feiyongno, feiyong, feiyongjine,beizhu,caiwu,  
							zdriqi, zdtime,  riqi1, riqi2, dFill,bAuto,dFinance,Serno_Union)
						values(@cSupplierNo,@cSupplier,@feiyongno,@feiyong,isnull(@fMoney,0)*@iTimes,substring('每月'+CAST(@iDate as varchar(32))+'日自动生成费用,'+dbo.getDayStr(getdate())+' '+ dbo.getTimeStr(GETDATE()),1,64),@cOper,
    				@dDate_Finance, dbo.getDayStr(@dDate_Finance)+' '+dbo.getTimeStr(GETDATE()),@dDate_Start,@dDate_End,dbo.getDayStr(getdate()),1,@dDate_Finance,@serno)
						--update t_Supplier_fee_Gen set dDays_Last=@dDate_End where serno=@serno
          end
        end
			end
      		


    end


		fetch next from Cur_fee_Gen
		into @feiyongno,  
		@feiyong, @feiyongjine,  
		@bSale_Period_Total, @bSale_Period_AfterTax, @fRatio, 
		@bJiesuan_Def, @cJiesuan_detail, @iDays, @dDays_Last, 
		@detail, @dDate_Start_0, @iDays_Per, @iDate, 
		@fMoney, @dDate_End_0, @fMoney_Ref,@serno
  end
	
	
  close Cur_fee_Gen
  deallocate Cur_fee_Gen	
 
  
  
	
	
end
GO
