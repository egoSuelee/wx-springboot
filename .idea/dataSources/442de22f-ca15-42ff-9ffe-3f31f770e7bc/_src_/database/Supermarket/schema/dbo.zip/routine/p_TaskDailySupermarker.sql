CREATE         procedure p_TaskDailySupermarker 
@dDate datetime  
as         
begin          
  delete from t_SaleSheet_Day where dDate=@dDate 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0)) into #rkd_sp0 from dbo.rkd_sp a left join spxx b on a.spno=b.spno where zdriqi=@dDate group by a.spno,b.belong
  update a set a.spno=b.spno from #rkd_sp0 a,spxx b where a.belong=b.spno       
  select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) into #rkd_sp from #rkd_sp0 group by spno 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0)) into #jcd_sp0 from dbo.jcd_sp a left join spxx b on a.spno=b.spno where zdriqi=@dDate group by a.spno,b.belong 
  update a set a.spno=b.spno from #jcd_sp0 a,spxx b where a.belong=b.spno             
  select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) into #jcd_sp from #jcd_sp0 group by spno 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)) into #ckd_sp0 from dbo.ckd_sp a left join spxx b on a.spno=b.spno where zdriqi=@dDate group by a.spno,b.belong 
  update a set a.spno=b.spno from #ckd_sp0 a,spxx b where a.belong=b.spno 
  select spno,shuliang=sum(isnull(shuliang,0)) into #ckd_sp from #ckd_sp0 group by spno 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0)) into #fcd_sp0 from dbo.fcd_sp a left join spxx b on a.spno=b.spno where zdriqi=@dDate group by a.spno,b.belong
  update a set a.spno=b.spno from #fcd_sp0 a,spxx b where a.belong=b.spno
  select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) into #fcd_sp from #fcd_sp0 group by spno 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)) into #syd_sp0 from dbo.syd_sp a left join spxx b on a.spno=b.spno where zdriqi=@dDate group by a.spno,b.belong
  update a set a.spno=b.spno from #syd_sp0 a,spxx b where a.belong=b.spno   
  select spno,shuliang=sum(isnull(shuliang,0)) into #syd_sp from #syd_sp0 group by spno 
  select a.spno,b.belong,shuliang=sum(isnull(a.shuliang,0)) into #lsd_sp0 from dbo.lsdsp a left join spxx b on a.spno=b.spno where lsriqi=@dDate group by a.spno,b.belong 
  update a set a.spno=b.spno from #lsd_sp0 a,spxx b where a.belong=b.spno     
  select spno,shuliang=sum(isnull(shuliang,0)) into #lsd_sp from #lsd_sp0 group by spno 
  select spno into #jxc_sp from #rkd_sp 
  union             
  select spno from #jcd_sp 
  union                
  select spno from #ckd_sp  
  union                     
  select spno from #fcd_sp  
  union                  
  select spno from #syd_sp  
  union            
  select spno from #lsd_sp 
  select spno=cspno,dDate=max(dDate) into #max_day from t_SaleSheet_Day where cspno in (select cspno=spno from #jxc_sp) 
  group by cspno       
  select a.spno,a.dDate,fCostPrice=isnull(b.fCostPrice,0),fQty_BeginWH=isnull(b.fQty_BeginWH,0),fQty_CurWH=isnull(b.fQty_CurWH,0) into #max_day_sp0 
  from #max_day a left join t_SaleSheet_Day b on a.spno=b.cspno and a.dDate=b.dDate   
  select a.spno,b.dDate,fCostPrice=isnull(b.fCostPrice,0),fQty_BeginWH=isnull(b.fQty_BeginWH,0),
         fQty_CurWH=isnull(b.fQty_CurWH,0) into #max_day_sp from #jxc_sp a left join #max_day_sp0 b on a.spno=b.spno 
 select a.spno,fCostPrice=  
         case when isnull(a.fQty_CurWH,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)-/*isnull(d.shuliang,0)-*/isnull(e.shuliang,0)/*-isnull(f.shuliang,0)-isnull(g.shuliang,0)*/=0 
              then                   
                --isnull(a.fCostPrice,0)   
                isnull((select top 1 isnull(x.bzjj,0) from spxx x where x.spno=a.spno),0)
              else                                           
                (isnull(a.fCostPrice,0)*isnull(a.fQty_CurWh,0)+ 
                            isnull(b.jine,0)+isnull(c.jine,0)-   
                            --isnull(a.fCostPrice,0)*isnull(d.shuliang,0)-   
                            isnull(e.jine,0)---isnull(a.fCostPrice,0)*isnull(f.shuliang,0)-
                            /*isnull(a.fCostPrice,0)*isnull(g.shuliang,0)*/)/ 
                (isnull(a.fQty_CurWH,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)-/*isnull(d.shuliang,0)-*/isnull(e.shuliang,0)/*-isnull(f.shuliang,0)-isnull(g.shuliang,0)*/)
         end,  
         dDate=@dDate,    
         fQty_BeginWH=isnull(a.fQty_CurWh,0), 
         fQty_CurWh=isnull(a.fQty_CurWh,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)-isnull(d.shuliang,0)-isnull(e.shuliang,0)-isnull(f.shuliang,0)-isnull(g.shuliang,0)
  into #t_SaleSheet_Day      
  from #max_day_sp a left join #rkd_sp b on a.spno=b.spno 
                     left join #jcd_sp c on a.spno=c.spno
                     left join #ckd_sp d on a.spno=d.spno
                     left join #fcd_sp e on a.spno=e.spno 
                     left join #syd_sp f on a.spno=f.spno 
                    left join #lsd_sp g on a.spno=g.spno 
  insert into t_SaleSheet_Day (cspno,dDate,fCostPrice,fQty_BeginWH,fQty_CurWH)
  select cspno=spno,dDate,fCostPrice,fQty_BeginWH,fQty_CurWH from #t_SaleSheet_Day
end
GO
