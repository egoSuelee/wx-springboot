
/*
日结脚本  日期:2009-07-14
日结当天有库存变化的商品：rkd,jcd,cjd,ckd,syd,lsd,pdd,fcd,dbd
p_TaskDay_Chain_chen '2009-05-07','001'
*/

create proc [dbo].[p_TaskDay_Chain_chen]
@dDate1 datetime,
@cWhNo varchar(32)
as
--begin tran

 set nocount on
  if (select object_id('tempdb..#jcdsp0'))is not null
			drop table #jcdsp0
	if (select object_id('tempdb..#rkdsp0'))is not null
			drop table #rkdsp0
	if (select object_id('tempdb..#ckdsp0'))is not null
			drop table #ckdsp0
	if (select object_id('tempdb..#fcdsp0'))is not null
			drop table #fcdsp0
	if (select object_id('tempdb..#sydsp0'))is not null
			drop table #sydsp0
	if (select object_id('tempdb..#lsdsp0'))is not null
			drop table #lsdsp0
	if (select object_id('tempdb..#jcdsp'))is not null
			drop table #jcdsp
	if (select object_id('tempdb..#rkdsp'))is not null
			drop table #rkdsp
	if (select object_id('tempdb..#ckdsp'))is not null
			drop table #ckdsp
	if (select object_id('tempdb..#fcdsp'))is not null
			drop table #fcdsp
	if (select object_id('tempdb..#sydsp'))is not null
			drop table #sydsp
	if (select object_id('tempdb..#lsdsp'))is not null
			drop table #lsdsp
  if (select object_id('tempdb..#spxx'))is not null
		drop table #spxx
  if (select object_id('tempdb..#cjdsp0'))is not null
		drop table #cjdsp0
  if (select object_id('tempdb..#cjdsp'))is not null
		drop table #cjdsp
  if (select object_id('tempdb..#dbdsp0'))is not null
		drop table #dbdsp0
  if (select object_id('tempdb..#dbdsp'))is not null
		drop table #dbdsp
  if (select object_id('tempdb..#pddSp0'))is not null
		drop table #pddSp0
  if (select object_id('tempdb..#pddSp'))is not null
		drop table #pddSp
	if (select object_id('tempdb..#tmpPinpaiDate0'))is not null
			drop table #tmpPinpaiDate0
	if (select object_id('tempdb..#tmpPinpaiDate'))is not null
			drop table #tmpPinpaiDate
	if (select object_id('tempdb..#tmpPinpaiMaxriqi'))is not null
			drop table #tmpPinpaiMaxriqi
	if (select object_id('tempdb..#tmpPdLastDate'))is not null
			drop table #tmpPdLastDate
	if (select object_id('tempdb..#tempSpPdDate'))is not null
			drop table #tempSpPdDate
  if (select object_id('tempdb..#tmpSp_mondify0'))is not null
			drop table #tmpSp_mondify0
  if (select object_id('tempdb..#tmpSp_mondify'))is not null
			drop table #tmpSp_mondify
  if (select object_id('tempdb..#tempPdd'))is not null
			drop table #tempPdd
  if (select object_id('tempdb..#tmpPdsp'))is not null
			drop table #tmpPdsp
  if (select object_id('tempdb..#tempTwoDateDetail'))is not null
			drop table #tempTwoDateDetail
	if (select object_id('tempdb..#temp_storage_manage'))is not null
			drop table #temp_storage_manage
	if (select object_id('tempdb..#temp_jcd_rkd_cjd0'))is not null
			drop table #temp_jcd_rkd_cjd0
	if (select object_id('tempdb..#temp_jcd_rkd_cjd'))is not null
			drop table #temp_jcd_rkd_cjd
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#temp_jcd_rkd_cjd0_sec'))is not null
			drop table #temp_jcd_rkd_cjd0_sec
	if (select object_id('tempdb..#temp_jcd_rkd_cjd_sec'))is not null
			drop table #temp_jcd_rkd_cjd_sec
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#tempSpLastDay'))is not null
			drop table #tempSpLastDay
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#tmpPdsp'))is not null
			drop table #tmpPdsp
	if (select object_id('tempdb..#tmpPdsp_sec'))is not null
			drop table #tmpPdsp_sec
  if (select object_id('tempdb..#tmpPinpaiDate'))is not null
			drop table #tmpPinpaiDate
  if (select object_id('tempdb..#tmpPinpaiDate0'))is not null
			drop table #tmpPinpaiDate0
  if (select object_id('tempdb..#tmpPinpaiDate0'))is not null
			drop table #tmpPinpaiDate0
  if (select object_id('tempdb..#tmpPdLastDate_sec'))is not null
			drop table #tmpPdLastDate_sec
  if (select object_id('tempdb..#tempSpPdDate_sec'))is not null
			drop table #tempSpPdDate_sec
  if (select object_id('tempdb..#tempLsdSp'))is not null
			drop table #tempLsdSp
  if (select object_id('tempdb..#tmpRkdSp'))is not null
			drop table #tmpRkdSp
  if (select object_id('tempdb..#RkdDate'))is not null
			drop table #RkdDate
/*
declare @dDate1 datetime
declare @cWhNo varchar(32)
set @dDate1='2009-04-30'
set @cWhNo='001'
*/
--如果日结表中有当天的日结，先删除
delete  dbo.t_SaleSheet_Day
where dDate=@dDate1 and isnull(cWhNo,@cWhNo)=@cWhNo


  select distinct spno,pinpaino,guizuno
	into #spxx     
	from spxx
  where danwei is not null
--商品盘点日期
--品牌盘点情况  --drop table #tmpPinpaiDate   
  select distinct b.pinpaino,a.zdriqi,a.pandian
  into #tmpPinpaiDate0
  from pdd_sp a left join spxx b
  on a.spno=b.spno
  where (pandian is not null)and( isnull(cangkuno,'')=@cWhNo and @cWhNo<>'' )

	select pinpaino,zdriqi,pandian
  into #tmpPinpaiDate
  from #tmpPinpaiDate0

  select pinpaino,MaxpdRiqi=isnull(max(zdriqi),'1899-01-01')
  into #tmpPinpaiMaxriqi  --drop table #tempSpPdDate
  from #tmpPinpaiDate
  where pandian=0 and pandian is not null
  group by pinpaino

  select pinpaino,MaxPdRiqi,PdDate=MaxPdRiqi
  into #tmpPdLastDate
  from #tmpPinpaiMaxriqi 
  where MaxPdRiqi<=@dDate1-1
  union all
  select a.pinpaino,a.MaxPdRiqi,PdDate=isnull(
                                   (
                                    select max(b.zdriqi) from #tmpPinpaiDate b
                                    where b.zdriqi<@dDate1 and a.pinpaino=b.pinpaino
                                   ),'1899-01-01')
  from #tmpPinpaiMaxriqi a
  where a.MaxPdRiqi>@dDate1-1

  select distinct a.spno,a.pinpaino,PdDate=isnull(PdDate,'1899-01-01')
  into #tempSpPdDate
  from #spxx a left join #tmpPdLastDate b
  on a.pinpaino=b.pinpaino
--期间销售情况  select * from  #tempSpPdDate
------------------------------------------------------------------------------------------------
	  select spno,zdriqi,shuliang,jine=jinjiajine
		into #jcdsp0
		from jcd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=jcd_sp.spno
                           ) and @dDate1
    --where zdriqi<=@dDate2
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'') 
	  update a
		set a.spno=b.belong
		from #jcdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #jcdsp
	  from #jcdsp0
	  group by spno,zdriqi
	
	--select * from #rkdsp    
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #rkdsp0
		from rkd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=rkd_sp.spno
                           ) and @dDate1
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  update a
		set a.spno=b.belong
		from #rkdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #rkdsp
	  from #rkdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #ckdsp0
		from ckd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=ckd_sp.spno
                           ) and @dDate1
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')

	  update a
		set a.spno=b.belong
		from #ckdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #ckdsp
	  from #ckdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #fcdsp0
		from fcd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=fcd_sp.spno
                           ) and @dDate1
    and  (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')

	  update a
		set a.spno=b.belong
		from #fcdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #fcdsp
	  from #fcdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #sydsp0
		from syd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=syd_sp.spno
                           ) and @dDate1
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  update a
		set a.spno=b.belong
		from #sydsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #sydsp
	  from #sydsp0
	  group by spno,zdriqi

		select spno,zdriqi=lsriqi,shuliang,jine=jine
	  into #lsdsp0
		from lsdsp 
		where lsriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=lsdsp.spno
                           ) and @dDate1
    and  (isnull(cangkuno,@cWhNo)=@cWhNo and @cWhNo<>'')
	  update a
		set a.spno=b.belong
		from #lsdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #lsdsp
	  from #lsdsp0
	  group by spno,zdriqi
    
  --cjd  select * from cjd_sp
    select spno,zdriqi,shuliang,jine=chajiajine
	  into #cjdsp0
		from cjd_sp 
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=cjd_sp.spno
                           ) and @dDate1
    and (isnull(cWhNo,'')=@cWhNo and @cWhNo<>'')
	  update a
		set a.spno=b.belong
		from #cjdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #cjdsp
	  from #cjdsp0
	  group by spno,zdriqi
   --select * from #lsdsp0
--dbd

    select spno,zdriqi,shuliang,jine=jinjiajine
	  into #dbdsp0
		from dbd_sp 
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=dbd_sp.spno
                           ) and @dDate1
    and  (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  update a
		set a.spno=b.belong
		from #dbdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #dbdsp
	  from #dbdsp0
	  group by spno,zdriqi
------------------------------------------------------------------------------------------------
--当天有盘点的商品
  select distinct b.pinpaino,a.MaxPdRiqi,PdDate=b.zdriqi
  into #tempPdd
  from #tmpPinpaiMaxriqi a,#tmpPinpaiDate b
  where a.pinpaino=b.pinpaino  and b.zdriqi<=MaxPdRiqi and b.zdriqi=@Ddate1
--select * from #tempPdd
	select distinct b.spno,a.PdDate
	into #pddSp0
	from #tempPdd a left join spxx b
	on a.pinpaino=b.pinpaino
	where a.PdDate is not null
	update a
	set a.spno=b.belong
	from #pddSp0 a,spxx b 
	where  a.spno=b.spno and isnull(b.belong,'')<>''
	select distinct spno,zdriqi=pdDate
	into #pddSp
	from #pddSp0
	
	--当天库存变化的商品
	select  spno
	into #tmpSp_mondify0
	from #jcdsp where zdriqi=@Ddate1
	union all
	select spno from #ckdsp where zdriqi=@Ddate1
	union all
  select spno from #rkdsp where zdriqi=@Ddate1
	union all
	select spno from #fcdsp where zdriqi=@Ddate1
	union all
	select spno from #sydsp where zdriqi=@Ddate1
	union all
	select spno from #lsdsp where zdriqi=@Ddate1
	union all
	select spno from #cjdsp where zdriqi=@Ddate1
	union all
	select spno from #dbdsp where zdriqi=@Ddate1
	union all
	select spno from #pddSp where zdriqi=@Ddate1
	
	
	select distinct a.spno,b.guizuno
	into #tmpSp_mondify
	from #tmpSp_mondify0 a left join spxx b
	on a.spno=b.spno
	
	
	insert into  dbo.t_SaleSheet_Day
	(dDate,guizuno,cSpNo,fQuantity_Sale,fMoney_Sale,dFinanceDate)
	select dDate=@Ddate1,guizuno,spno,0,0,@Ddate1
	from #tmpSp_mondify 
	
	
	update a
	set a.fQuantity_Sale=isnull(b.shuliang,0),
	a.fMoney_Sale=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#lsdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	
	update a
	set a.fQty_TranIn=isnull(b.shuliang,0),
	a.fMoney_TranIn=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#jcdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	
	update a
	set a.fQty_StockIn=isnull(b.shuliang,0),
	a.fMoney_StockIn=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#rkdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	
	update a
	set a.fQty_Out=isnull(b.shuliang,0),
	a.fMoney_Out=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#ckdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	
	update a
	set a.fQty_TranOut=isnull(b.shuliang,0),
	a.fMoney_TranOut=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#dbdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1  and b.zdriqi=@Ddate1
	
	
	update a
	set a.fQty_Return=isnull(b.shuliang,0),
	a.fMoney_Return=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#fcdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	  
	update a
	set a.fQty_Loss=isnull(b.shuliang,0),
	a.fMoney_Loss=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#sydsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	
	update a
	set a.fQty_Compensatory=isnull(b.shuliang,0),
	a.fMoney_Compensatory=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#cjdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
	 
	
	update a
	set a.fQty_Return=isnull(b.shuliang,0),
	a.fMoney_Cust=isnull(b.jine,0)
	from  dbo.t_SaleSheet_Day a,#fcdsp b
	where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1
  
--期初库存

  select a.spno,shuliang=isnull(sum(isnull(b.shuliang,0)),0)
	into #tmpPdsp 
	from #tmpSp_mondify a left join pdd_sp b
	on a.spno=b.spno and b.zdriqi=(select top 1 p.pddate from #tempSpPdDate p where p.spno=b.spno)
  and ( (cangkuno=@cWhNo and @cWhNo<>'') or (@cWhNo='') )
	group by a.spno 
	--select * from #tmpPdsp
  update a
  set a.fQty_BeginWH=b.shuliang
  from  dbo.t_SaleSheet_Day a,#tmpPdsp b
  where a.cSpNo=b.spno and a.dDate=@Ddate1
  and a.cSpNo in(select spno from #tempSpPdDate where PdDate=(@dDate1-1))

	  update a
	  set a.fQty_BeginWH=isnull(p.shuliang,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)
	      -isnull(d.shuliang,0)-isnull(e.shuliang,0)-isnull(f.shuliang,0)-isnull(g.shuliang,0)
        -isnull(db.shuliang,0)
	  from  dbo.t_SaleSheet_Day a 
	  left join #tmpPdsp p on a.cSpNo=p.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #jcdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#jcdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )b on a.cSpNo=b.spno 
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #rkdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#rkdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )c on a.cSpNo=c.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #ckdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#ckdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )d on a.cSpNo=d.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #fcdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#fcdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )e on a.cSpNo=e.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #sydsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#sydsp.spno
                           )+1 and  @dDate1-1 
		  group by spno
		 )f on a.cSpNo=f.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #lsdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#lsdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 ) g on a.cSpNo=g.spno
    left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #dbdsp
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#dbdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 ) db on a.cSpNo=db.spno
	  where  a.dDate=@Ddate1 and 
    a.cSpNo in(select spno from #tempSpPdDate where PdDate<(@dDate1-1))

--期末数量

  select pinpaino,MaxPdRiqi,PdDate=MaxPdRiqi
  into #tmpPdLastDate_sec
  from #tmpPinpaiMaxriqi 
  where MaxPdRiqi<=@dDate1
  union all
  select a.pinpaino,a.MaxPdRiqi,PdDate=isnull(
                                   (
                                    select max(b.zdriqi) from #tmpPinpaiDate b
                                    where b.zdriqi<=@dDate1 and a.pinpaino=b.pinpaino
                                   ),'1899-01-01')
  from #tmpPinpaiMaxriqi a
  where a.MaxPdRiqi>@dDate1

  select distinct a.spno,a.pinpaino,PdDate=isnull(PdDate,'1899-01-01')
  into #tempSpPdDate_sec
  from #spxx a left join #tmpPdLastDate_sec b
  on a.pinpaino=b.pinpaino

  select a.spno,shuliang=isnull(sum(isnull(shuliang,0)),0),shoujia=isnull(avg(isnull(shoujia,0)),0)
	into #tmpPdsp_sec 
	from #tmpSp_mondify a left join pdd_sp b
	on a.spno=b.spno and b.zdriqi=(select top 1 p.pddate from #tempSpPdDate_sec p where p.spno=b.spno)
  and ( (cangkuno=@cWhNo and @cWhNo<>'') or (@cWhNo='') ) 
	group by a.spno 
	
  update a
  set a.fQty_EndWH=b.shuliang
  from   dbo.t_SaleSheet_Day a,#tmpPdsp_sec b
  where a.cSpNo=b.spno and a.dDate=@Ddate1
  and a.cSpNo in(select spno from #tempSpPdDate_sec where PdDate=@dDate1)

	  update a
	  set a.fQty_EndWH=isnull(p.shuliang,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)
	      -isnull(d.shuliang,0)-isnull(e.shuliang,0)-isnull(f.shuliang,0)-isnull(g.shuliang,0)
        -isnull(db.shuliang,0)
	  from  dbo.t_SaleSheet_Day a
	  left join #tmpPdsp_sec p on a.cSpNo=p.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #jcdsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#jcdsp.spno
                           )+1 and  @dDate1 
		  group by spno
		 )b on a.cSpNo=b.spno 
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #rkdsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#rkdsp.spno
                           )+1 and  @dDate1  
		  group by spno
		 )c on a.cSpNo=c.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #ckdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#ckdsp.spno
                           )+1 and  @dDate1 
		  group by spno
		 )d on a.cSpNo=d.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #fcdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#fcdsp.spno
                           )+1 and  @dDate1 
		  group by spno
		 )e on a.cSpNo=e.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #sydsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#sydsp.spno
                           )+1 and  @dDate1  
		  group by spno
		 )f on a.cSpNo=f.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #lsdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#lsdsp.spno
                           )+1 and  @dDate1 
		  group by spno
		 ) g on a.cSpNo=g.spno
    left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #dbdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate1 and x.spno=#dbdsp.spno
                           )+1 and  @dDate1 
		  group by spno
		 ) db on a.cSpNo=db.spno
	  where  a.dDate=@Ddate1 and
   a.cSpNo in(select spno from #tempSpPdDate_sec where PdDate<@dDate1)
--需要管理库存的商品
  select spno,belong
	into #temp_storage_manage    
	from spxx
	where isnull(selected,0)=1 and spno  in(select spno from #tmpSp_mondify )

  update  dbo.t_SaleSheet_Day
  set bStorage=1
  where cSpno in(select spno from #temp_storage_manage)
  and dDate=@Ddate1

--更新最近一次成本价格
  select a.spno,dDate=isnull(max(b.dDate),'1899-01-01')
	into #tempSpLastDay
	from #tmpSp_mondify a, dbo.t_SaleSheet_Day b
	where a.spno=b.cSpNo and b.dDate<@dDate1
	group by a.spno
	
	update a
	set a.fCostPrice_History=b.fCostPrice
	from  dbo.t_SaleSheet_Day a, 
	(
		select cSpNo,fCostPrice=avg(fCostPrice)
		from  dbo.t_SaleSheet_Day 
		where dDate =(select c.dDate from #tempSpLastDay c where cSpNo=c.spno)
    and fCostPrice is not null
		group by cSpNo
	)b
	where a.cSpNo=b.cSpNo and a.dDate=@Ddate1
	--select * from cjd_sp

  --如果成本为0则更新为spxx中的bbjj
  update a
	set a.fCostPrice_History=b.BzJj
	from  dbo.t_SaleSheet_Day a left join spxx b
	on a.cSpNo=b.spno 
	where  a.fCostPrice_History is null and a.dDate=@Ddate1


--更新期末成本
 update a
 set a.fCostPrice=case when isnull(a.fQty_BeginWH,0)+isnull(a.fQty_StockIn,0)+isnull(a.fQty_TranIn,0)-isnull(a.fQty_Return,0)=0
                  then isnull((select top 1 isnull(x.bzjj,0) from spxx x where x.spno=a.cSpNo),0)
                  else
                  (isnull(a.fCostPrice_History,0)*isnull(fQty_BeginWH,0)+ 
                            isnull(a.fMoney_StockIn,0)+isnull(a.fMoney_TranIn,0)-isnull(a.fMoney_Return,0)-isnull(a.fMoney_Compensatory,0)                           
                            )/ 
                   (isnull(a.fQty_BeginWH,0)+isnull(a.fQty_StockIn,0)+isnull(a.fQty_TranIn,0)-isnull(a.fQty_Return,0))
                 end
 from  dbo.t_SaleSheet_Day a
 where a.dDate=@Ddate1
 
--如果成本为0则更新为spxx中的bbjj

  update a
	set a.fCostPrice=b.BzJj
	from  dbo.t_SaleSheet_Day a left join spxx b
	on a.cSpNo=b.spno 
	where  a.fCostPrice is null and a.dDate=@Ddate1

  update a
	set a.fInPrice_avg=a.fCostPrice
	from  dbo.t_SaleSheet_Day a
	where  isnull(a.fInPrice_avg,0)=0 and a.dDate=@Ddate1 


/*
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	into #temp_jcd_rkd_cjd0   
	from #temp_storage_manage a ,jcd_sp  b
	where  a.spno=b.spno and b.zdriqi<=@dDate1-1
	union all
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	from #temp_storage_manage a , rkd_sp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1-1
	union all
	select a.spno,a.belong,shuliang=0,jinjiajine=-isnull(b.chajiajine,0)
	from #temp_storage_manage a , cjd_sp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1-1
	
	update #temp_jcd_rkd_cjd0
	set spno=belong where isnull(belong,'')<>''
	--select * from #temp_jcd_rkd_cjd
	select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
	into #temp_jcd_rkd_cjd
	from #temp_jcd_rkd_cjd0
	group by spno 
	
	update a
	set a.fcostPrice0=case when isnull(shuliang,0)<>0 then isnull(jine,0)/isnull(shuliang,0)
	                 else null end
	from  dbo.t_SaleSheet_Day a,#temp_jcd_rkd_cjd b
	where a.cSpNo=b.spno and a.fcostprice is null
  and a.dDate=@Ddate1

	
	--开业第一天
	update a
	set a.fcostPrice0=b.BzJj
	from  dbo.t_SaleSheet_Day a left join spxx b
	on a.cSpNo=b.spno 
	where  isnull(a.fcostPrice0,0)=0 and a.dDate=@Ddate1
*/
--更新期末成本
  /*select a.spno,dDate=isnull(max(b.dDate),'1899-01-01')
	into #tempSpLastDay_sec
	from #tmpSp_mondify a, dbo.t_SaleSheet_Day b
	where a.spno=b.cSpNo and b.dDate<@dDate1
	group by a.spno
	
	update a
	set a.fcostPrice=b.fCostPrice 
	from  dbo.t_SaleSheet_Day a, 
	(
		select cSpNo,fCostPrice=avg(isnull(fCostPrice,0))
		from  dbo.t_SaleSheet_Day 
		where dDate =(select c.dDate from #tempSpLastDay_sec c where cSpNo=c.spno)
		group by cSpNo
	)b
	where a.cSpNo=b.cSpNo and a.dDate=@Ddate1
	--select * from cjd_sp
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	into #temp_jcd_rkd_cjd0_sec   
	from #temp_storage_manage a ,jcd_sp  b
	where  a.spno=b.spno and b.zdriqi<=@dDate1
	union all
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	from #temp_storage_manage a , rkd_sp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1
	union all
	select a.spno,a.belong,shuliang=0,jinjiajine=-isnull(b.chajiajine,0)
	from #temp_storage_manage a , cjd_sp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1
	
	update #temp_jcd_rkd_cjd0_sec
	set spno=belong where isnull(belong,'')<>''
	--select * from #temp_jcd_rkd_cjd
	select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
	into #temp_jcd_rkd_cjd_sec
	from #temp_jcd_rkd_cjd0_sec
	group by spno 
	
	update a
	set a.fcostPrice=case when isnull(shuliang,0)<>0 then isnull(jine,0)/isnull(shuliang,0)
	                 else null end
	from  dbo.t_SaleSheet_Day a,#temp_jcd_rkd_cjd_sec b
	where a.cSpNo=b.spno and a.fcostprice is null
  and a.dDate=@Ddate1
	
	--开业第一天
	update a
	set a.fcostPrice=b.BzJj
	from  dbo.t_SaleSheet_Day a left join spxx b
	on a.cSpNo=b.spno 
	where  isnull(a.fcostPrice,0)=0 and a.dDate=@Ddate1

*/
  
 --最近一次销售日期
	update a
  set a.dDate_last_Sale=b.MaxDate
  from  dbo.t_SaleSheet_Day a,
  (
   select spno,MaxDate=max(lsriqi) from lsdsp where lsriqi<=@Ddate1
   group by spno
   )b
  where a.cSpNo=b.spno and a.dDate=@Ddate1


--销售数据  #tmpSp_mondify
select distinct spno,lsriqi,lstime,shuliang,jine
into #tempLsdSp
from lsdsp 
where lsriqi=@Ddate1

update a
set a.H0=sp.H0,a.H1=sp.H1,a.H2=sp.H2,a.H3=sp.H3,a.H4=sp.H4,a.H5=sp.H5,a.H6=sp.H6,a.H7=sp.H7,
    a.H8=sp.H8,a.H9=sp.H9,a.H10=sp.H10,a.H11=sp.H11,a.H12=sp.H12,a.H13=sp.H13,a.H14=sp.H14,
    a.H15=sp.H15,a.H16=sp.H16,a.H17=sp.H17,a.H18=sp.H18,a.H19=sp.H19,a.H20=sp.H20,a.H21=sp.H21,
    a.H22=sp.H22,a.H23=sp.H23,
    a.H0_Q=sp.H0_Q,a.H1_Q=sp.H1_Q,a.H2_Q=sp.H2_Q,a.H3_Q=sp.H3_Q,a.H4_Q=sp.H4_Q,a.H5_Q=sp.H5_Q,
    a.H6_Q=sp.H6_Q,a.H7_Q=sp.H7_Q,
    a.H8_Q=sp.H8_Q,a.H9_Q=sp.H9_Q,a.H10_Q=sp.H10_Q,a.H11_Q=sp.H11_Q,a.H12_Q=sp.H12_Q,a.H13_Q=sp.H13_Q,
    a.H14_Q=sp.H14_Q,
    a.H15_Q=sp.H15_Q,a.H16_Q=sp.H16_Q,a.H17_Q=sp.H17_Q,a.H18_Q=sp.H18_Q,a.H19_Q=sp.H19_Q,a.H20_Q=sp.H20_Q,
    a.H21_Q=sp.H21_Q,
    a.H22_Q=sp.H22_Q,a.H23_Q=sp.H23_Q
from  dbo.t_SaleSheet_Day a, 
(
	select a.spno,
	H0=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=0 and spno=a.spno),
	H1=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=1 and spno=a.spno),
	H2=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=2 and spno=a.spno),
	H3=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=3 and spno=a.spno),
	H4=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=4 and spno=a.spno),
	H5=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=5 and spno=a.spno),
	H6=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=6 and spno=a.spno),
	H7=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=7 and spno=a.spno),
	H8=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=8 and spno=a.spno),
	H9=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=9 and spno=a.spno),
	H10=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=10 and spno=a.spno),
	H11=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=11 and spno=a.spno),
	H12=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=12 and spno=a.spno),
	H13=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=13 and spno=a.spno),
	H14=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=14 and spno=a.spno),
	H15=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=15 and spno=a.spno),
	H16=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=16 and spno=a.spno),
	H17=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=17 and spno=a.spno),
	H18=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=18 and spno=a.spno),
	H19=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=19 and spno=a.spno),
	H20=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=20 and spno=a.spno),
	H21=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=21 and spno=a.spno),
	H22=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=22 and spno=a.spno),
	H23=(select sum(jine) from #tempLsdSp 
						where datepart(hh,cast('2000-01-01 '+lstime as datetime))=23 and spno=a.spno),

	H0_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=0 and spno=a.spno),
	H1_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=1 and spno=a.spno),
	H2_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=2 and spno=a.spno),
	H3_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=3 and spno=a.spno),
	H4_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=4 and spno=a.spno),
	H5_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=5 and spno=a.spno),
	H6_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=6 and spno=a.spno),
	H7_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=7 and spno=a.spno),
	H8_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=8 and spno=a.spno),
	H9_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=9 and spno=a.spno),
	H10_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=10 and spno=a.spno),
	H11_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=11 and spno=a.spno),
	H12_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=12 and spno=a.spno),
	H13_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=13 and spno=a.spno),
	H14_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=14 and spno=a.spno),
	H15_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=15 and spno=a.spno),
	H16_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=16 and spno=a.spno),
	H17_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=17 and spno=a.spno),
	H18_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=18 and spno=a.spno),
	H19_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=19 and spno=a.spno),
	H20_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=20 and spno=a.spno),
	H21_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=21 and spno=a.spno),
	H22_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=22 and spno=a.spno),
	H23_Q=(select sum(shuliang) from #tempLsdSp 
									where datepart(hh,cast('2000-01-01 '+lstime as datetime))=23 and spno=a.spno)
	from #tmpSp_mondify a
)sp
where a.cSpNo=sp.spno
and a.dDate=@Ddate1


--跟新当天最高进价fInPrice_H，最低进价fInPrice_L
select spno,jinjia into #tmpRkdSp from rkd_sp 
where zdriqi=@Ddate1 and jinjia is not null
update a
set a.spno=b.belong
from #tmpRkdSp a,spxx b where a.spno=b.spno and isnull(b.belong,'')<>''

update a
set a.fInPrice_H=b.fInPrice_H,a.fInPrice_L=b.fInPrice_L
from  dbo.t_SaleSheet_Day a,
(
  select spno,fInPrice_H=Max(isnull(jinjia,0)),
         fInPrice_L=Min(jinjia),fInPrice_avg=avg(isnull(jinjia,0))
  from #tmpRkdSp
  group by spno
)b
where a.dDate=@Ddate1 and a.cSpNo=b.spno


--更新fNormalPrice，fVipPrice，cSupplierNo
update a
set a.fNormalPrice=b.BzLsj,a.fVipPrice=b.Ylsj1,a.cSupplierNo=b.Dw2
from  dbo.t_SaleSheet_Day a,spxx b
where a.cSpNo=b.spno
and a.dDate=@Ddate1

--更新fMoney_WH_Begin，fMoney_WH_End
update  dbo.t_SaleSheet_Day
set fMoney_WH_Begin=isnull(fQty_BeginWH,0)*isnull(fCostPrice_History,0),
    fMoney_WH_End=isnull(fQty_EndWH,0)*isnull(fCostPrice,0)
where dDate=@Ddate1
--更新fMoney_WH_Sale_Begin，fMoney_WH_Sale_End
update  dbo.t_SaleSheet_Day
set fMoney_WH_Sale_Begin=isnull(fQty_BeginWH,0)*isnull(fNormalPrice,0),
    fMoney_WH_Sale_End=isnull(fQty_EndWH,0)*isnull(fNormalPrice,0)
where dDate=@Ddate1


--更新最近一次入库日期
select spno,MaxRiqi=max(zdriqi)
into #RkdDate 
from rkd_sp where zdriqi<=@Ddate1
group by spno
update a
set a.spno=b.belong
from #RkdDate a,spxx b
where a.spno=b.spno and isnull(b.belong,'')<>''

update a
set a.dDate_Last_StockIn=b.Maxriqi
from  dbo.t_SaleSheet_Day a,
(
  select spno,Maxriqi from #RkdDate
)b
where a.cSpNo=b.spno and a.dDate=@Ddate1

--会员价
select distinct a.spno,a.shuliang,a.jine
into #tmpVipSp0
from lsdsp a,
(
  select zdriqi,lsdno from lsd where isnull(ltrim(rtrim(vipno)),'')<>''
  and zdriqi=@Ddate1
)b
where a.lsdno=b.lsdno and a.lsriqi=b.zdriqi
and a.lsriqi=@Ddate1

update a
set a.spno=b.belong
from #tmpVipSp0 a,spxx b
where a.spno=b.spno and isnull(b.belong,'')<>''

select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #tmpVipSp
from #tmpVipSp0
group by spno

update a
set a.fQty_VipSale=b.shuliang,a.fMoney_VipSale=b.jine
from  dbo.t_SaleSheet_Day a,#tmpVipSp b
where a.cSpNo=b.spno and a.dDate=@Ddate1

--特价商品，spxx中ispec=1
select spno,shuliang,jine
into #tmpSpecSp0
from lsdsp
where lsriqi=@Ddate1
and spno in(
select spno from spxx where isnull(ispec,0)=1
)

update a
set a.spno=b.belong
from #tmpSpecSp0 a,spxx b
where a.spno=b.spno and isnull(b.belong,'')<>''

select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #tmpSpecSp
from #tmpSpecSp0
group by spno

update a
set a.fQty_PriceOff=b.shuliang,a.fMoney_PriceOff=b.jine
from  dbo.t_SaleSheet_Day a,#tmpSpecSp b
where a.cSpNo=b.spno and a.dDate=@Ddate1

--更新客退
select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
into #lsdspCust
from #lsdsp0
where isnull(shuliang,0)<0
group by spno,zdriqi

update a
set a.fQty_Cust=b.shuliang,a.fMoney_Cust=b.jine
from  dbo.t_SaleSheet_Day a,#lsdspCust b
where a.cSpNo=b.spno and a.dDate=@Ddate1 and b.zdriqi=@Ddate1


--更新扣率
update a
set a.fProfitsRatio=isnull(b.koudian,0)
from  dbo.t_SaleSheet_Day a,
(
  select distinct guizuno,koudian from shanghu_hetong
) b
where a.guizuno=b.guizuno and a.ddate=@Ddate1

--更新仓库
update  dbo.t_SaleSheet_Day
set cWhNo=@cWhNo
where ddate=@Ddate1

--if @@Error=0
--commit tran
--else
--rollback tran


GO
