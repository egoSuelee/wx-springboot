CREATE procedure p_VipRetMoney

as
begin
 	if(select object_id('tempdb..#temp_VipRetMoney01')) is not null
	begin
		drop table #temp_VipRetMoney01
	end 

	select  y.cardno,y.fCurValue_MP_Activity,y.fCurValue_MP_0,
			y.cActivityNo,y.dDateSetted,y.fModValue_MP,y.fRetMoney_Mp,
			fMoney_Ret_waiting=floor(ISNULL(y.fCurValue_MP_Activity,0)/y.fModValue_MP)*y.fRetMoney_Mp,
			fMoney_Ret_Waiting_CustScore=floor(ISNULL(y.fCurValue_MP_Activity,0)/y.fModValue_MP)*y.fModValue_MP
	into #temp_VipRetMoney01		
	from

	(
			select 
			x.cardno,x.fCurValue_MP_Activity,x.fCurValue_MP_0,
			x.cActivityNo,x.dDateSetted,x.fModValue_MP,x.fRetMoney_Mp
			from
			(
				select a.cardno,a.fCurValue_MP_Activity,fCurValue_MP_0=(a.fCurValue_MP_Activity-b.fModValue_MP),
				 b.cActivityNo,b.dDateSetted,b.fModValue_MP,b.fRetMoney_Mp
				from card a,
				(
				select cActivityNo,dDateSetted,fModValue_MP,fRetMoney_Mp
				from card_activity
				where dDateSetted=(select MAX(dDateSetted) from card_activity where ISNULL(fModValue_MP,0)<>0)
				and ISNULL(bover,0)=0
				) b
				--where a.cardno=@cVipNo
			) x
			where x.fCurValue_MP_0>=0 
	) y,
	(
			select 
			x.cardno,fCurValue_MP_0=min(x.fCurValue_MP_0)
			from
			(
				select a.cardno,a.fCurValue_MP_Activity,fCurValue_MP_0=(a.fCurValue_MP_Activity-b.fModValue_MP),
				 b.cActivityNo,b.dDateSetted,b.fModValue_MP,b.fRetMoney_Mp
				from card a,
				(
				select cActivityNo,dDateSetted,fModValue_MP,fRetMoney_Mp
				from card_activity
				where dDateSetted=(select MAX(dDateSetted) from card_activity where ISNULL(fModValue_MP,0)<>0)
				) b
				--where a.cardno=@cVipNo
			) x
			where x.fCurValue_MP_0>=0 
			group by x.cardno
	) z
	where y.cardno=z.cardno and y.fCurValue_MP_0=z.fCurValue_MP_0		
	
	update a
	set 
	a.fMoney_Ret_waiting=isnull(b.fMoney_Ret_waiting,0),
	a.bMoney_LastRet=0,
	a.dCurValue_MP_Activity=b.dDateSetted,
	a.fCurValue_MP_Activity=b.fMoney_Ret_Waiting_CustScore
	
	from  card a,#temp_VipRetMoney01 b
	where a.cardno=b.cardno
	
/*
 y.cardno,y.fCurValue_MP_Activity,y.fCurValue_MP_0,
 y.cActivityNo,y.dDateSetted,y.fModValue_MP,y.fRetMoney_Mp
*/

 /*
   fMoney_Ret_Sum , --累计返现
   fMoney_Ret_waiting ,--本次待返现
   bMoney_LastRet ,--是否返现
   dMoney_LastRet ,--最近一次返现日期
 */
 



/*
	if exists(select * from #temp_VipRetMoney01)
	begin
		update a
		set 
		a.fValue_MP_LastRetSub_sum=isnull(a.fValue_MP_LastRetSub_sum,0)
		+isnull(b.fCurValue_MP_Activity,0),
		a.fValue_MP_LastRetSub=isnull(a.fCurValue_MP,0)-isnull(b.fCurValue_MP_0,0),
		a.fCurValue_MP=isnull(a.fCurValue_MP,0)-isnull(b.fCurValue_MP_Activity,0),
		a.fCurValue=isnull(b.fCurValue,0)- isnull(b.fCurValue_MP_Activity,0)
		from  card a,#temp_VipRetMoney01 b
		where a.cardno=b.cardno
	end
*/	
end
GO
