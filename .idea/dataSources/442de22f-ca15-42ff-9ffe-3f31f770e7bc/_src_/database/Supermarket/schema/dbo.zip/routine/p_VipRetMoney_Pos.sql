CREATE procedure p_VipRetMoney_Pos
@cServername varchar(128),
@cardno varchar(32)
as
begin
exec('	
	update a
	set 
	a.fMoney_Ret_Sum=ISNULL(a.fMoney_Ret_Sum,0)+ISNULL(a.fMoney_Ret_waiting,0),
	a.bMoney_LastRet=1,
	a.dMoney_LastRet=GETDATE()
	
	from  '+@cServername+'.supermarket.dbo.card a
	where a.cardno='''+@cardno+'''
')	

end
GO
