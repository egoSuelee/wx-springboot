
/*
	会员消费倾向
exec p_Vip_saleLean_chen 'temp_delphi_last','2007-1-12','2008-12-12'
*/
create proc p_Vip_saleLean_chen
@delphiTable varchar(50),
@date1 datetime,
@date2 datetime
as
begin
exec('
	if (select object_id(''tempdb..#temp_Lsdsp_VipNo''))is not null 
	   drop table #temp_Lsdsp_VipNo
	if (select object_id(''tempdb..#temp_spType''))is not null 
	   drop table #temp_spType
	if (select object_id(''tempdb..#temp_spTypeLast''))is not null 
	   drop table #temp_spTypeLast


	select a.VipNo,b.zdriqi,b.LsdNo,b.guizuno,b.guizu,c.shuliang,c.Spno,c.MingCheng
	into #temp_Lsdsp_VipNo
	from '+@delphiTable+' a left join lsd b
	on isnull(b.VipNO,'''')=a.VipNo
	left join lsdsp c
	on b.lsdno=c.lsdno
	where isnull(b.zdriqi ,''1900-01-01'') between'''+@date1+''' and '''+@date2+'''

	select a.VipNo,a.zdriqi,a.LsdNo,a.shuliang,a.Spno,a.MingCheng,b.kind,c.cGoodsTypeName
	into #temp_spType 
	from #temp_Lsdsp_VipNo a left join spxx b
	on a.Spno=b.Spno
	left join t_GoodsType c
	on b.kind=c.cGoodsTypeno

	select VipNo,kind,cGoodsTypeName,shuliang=sum(shuliang)
    into #temp_spTypeLast
	from #temp_spType
	group by VipNo,kind,cGoodsTypeName
   
	select VipNo,kind,cGoodsTypeName,shuliang
	from #temp_spTypeLast
    union all
    select vipno,kind=''合计'',cGoodsTypeName=cast(count(Kind) as varchar(10))+''--种商品'',null
    from #temp_spTypeLast
    group by vipno
	order by VipNo,shuliang desc
    
')
end

GO
