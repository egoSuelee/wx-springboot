/*

p_X_Shenhe_Web '101','2010-10-20','2011-3-22'
*/

CREATE PROCEDURE p_X_Shenhe_Web 
@guizuno varchar(32),
@times1 datetime,
@times2 datetime
AS
BEGIN
   select a.lsdno,zdriqi=CONVERT(varchar(100),a.zdriqi,23),a.xstime,a.yingshou,mlt=a.mlt,shishou=a.shishou,
lssl=(select lssl=sum(shuliang) from lsdsp where lsriqi=a.zdriqi and 
       guizuno=a.guizuno and lsdno=a.lsdno ),a.xsy,a.shenhe
from lsd a
--select 加密号=a.lsdno,销售日期=CONVERT(varchar(100),a.zdriqi,23),销售时间=a.xstime,应收金额=a.yingshou,优惠金额=a.mlt,实收金额=a.shishou,
--数量=(select lssl=sum(shuliang)from lsdsp where lsriqi=a.zdriqi and 
--       guizuno=a.guizuno and lsdno=a.lsdno ),收银员=a.xsy,审核=a.shenhe
--from lsd a
 where guizuno =@guizuno
 and zdriqi between @times1 and @times2
union all
select lsdno='合计:',zdriqi=null,xstime=null,
yingshou=(select sum(yingshou) from lsd
 where guizuno =@guizuno
 and zdriqi between @times1 and @times2
          ),
mlt=(select sum(mlt) from lsd
 where guizuno =@guizuno
 and zdriqi between @times1 and @times2
          ),
shishou=(select sum(shishou) from lsd
 where guizuno =@guizuno
 and zdriqi between @times1 and @times2
          ),
lssl=(select lssl=sum(shuliang) from lsdsp
      where lsriqi between @times1 and @times2
       and guizuno=@guizuno),xsy=null,shenhe=null
order by lsdno,zdriqi

END
GO
