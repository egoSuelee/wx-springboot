create procedure p_card_activity
as
begin
  select d=1
end
GO
