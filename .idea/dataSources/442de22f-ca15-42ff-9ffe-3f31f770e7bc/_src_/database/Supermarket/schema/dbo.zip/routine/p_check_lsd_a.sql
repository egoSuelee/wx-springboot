
--根据
--通过相关信息缩小范围查找销售信息
create  procedure p_check_lsd_a
 @likesheet varchar(32), --要模糊查询的收银员信息以及收银小票单号以及结算方式以及柜组信息
 @a money, --单价或金额
 @b money,--单价或金额 
 @time1 datetime,
 @time2 datetime 
as
begin
  select c.sheetno,c.SPno,c.Tiaoma,c.MingCheng,c.Danwei,c.Shuliang,c.Danjia,c.Jine,c.daogouyuanno,c.daogouyuan,c.detail,
         c.Xsy,c.xsyno,c.Lsriqi,c.guizuno,c.guizu
  from(
	select sheetno,a.SpNo,a.Tiaoma,a.Mingcheng,a.Danwei,a.Shuliang,a.Danjia,a.Jine,a.daogouyuanno,a.daogouyuan,
	a.guizu,a.guizuno,b.Xsy,b.xsyno,a.lsriqi,detail
	from(
	select LsdNo,sheetno,SpNo,Tiaoma,MingCheng,Danwei,Shuliang,Danjia,Jine,guizu,guizuno,lsriqi,detail,daogouyuanno,daogouyuan
	from lsdsp right join jiesuan
	on left(LsdNo,len(sheetno) )=sheetno
	where (lsriqi=zdriqi and zdriqi between @time1 and @time2
	and LsdNo is not null 
  and ((Danjia between @a and @b ) or (Jine between @a and @b)))
	)a left join lsd b
	on a.LsdNo=b.lsdNo
	and a.lsriqi=b.zdriqi 
 ) c 
 where(c.sheetno=@likesheet or c.detail=@likesheet or c.guizuno=@likesheet or c.guizu=@likesheet 
       or c.xsy=@likesheet or c.xsyno=@likesheet or @likesheet='')
	order by sheetno
end
GO
