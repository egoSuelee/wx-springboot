


create   procedure p_createTemp_goods
@date1 datetime,
@date2 datetime,
@guizuno varchar(32)
as
begin
--	#temp1_save
--spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dDate_pandian

	select a.dDate,spno=a.cSpno,b.belong
	into #temp_SaleSheet_Day0
	from t_SaleSheet_Day a,spxx b
	where a.cSpno=b.spno
				and a.dDate between @Date1 and @Date2

	select distinct spno=a.belong,dLiushui=a.dDate,
	belong=a.belong,b.mingcheng,b.danwei,b.dw1,b.guige,b.bzlsj,b.shuliang
  into #temp_SaleSheet_Day
	from #temp_SaleSheet_Day0 a,#temp10 b
  where a.belong=b.spno 

--select * into ##temp_SaleSheet_Day from #temp_SaleSheet_Day
--select * from ##temp_SaleSheet_Day


	insert into #temp_goods (
	spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select a.spno,a.belong,a.mingcheng,a.danwei,a.dw1,a.guige,0,a.bzlsj,a.shuliang,a.dLiushui, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 
	from #temp_SaleSheet_Day a


	insert into #temp_goods (
	spno,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select e.spno,e.mingcheng,e.danwei,e.dw1,e.guige,0,e.bzlsj,e.shuliang,e.dLiushui, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from
	( 
	select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige, a.bzlsj,a.shuliang,dLiushui=b.dDate
	from #temp10 a left join 
	(select distinct c.guizuno,dDate=c.zdriqi,cSpno=c.spno,d.belong 
	 from pdd_sp c left join spxx d on c.Spno=d.spno
	 where c.zdriqi between @date1 and @date2
	) b on a.spno=b.cspno
	where (b.guizuno in (select guizuno=spno from #tempCon where bChecked=1) 
	   or b.belong in (select belong=spno from #tempCon where bChecked=1))
	 and b.dDate<=@date2
	) e left join #temp_goods f on e.spno=f.spno and e.dLiushui=f.dataLiuShui 
	where f.dataLiuShui is null



--  delete from #temp_goods where dataLiuShui is null

	select distinct spno
	into #temp_goods_date1
	from #temp_goods where dataLiuShui=@date1


/*  下面的代码有错误*/
/*
	insert into #temp_goods (
	spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select distinct a.spno,a.belong,a.mingcheng,a.danwei,a.dw1,a.guige,0,a.bzlsj,a.shuliang,
--	//select distinct a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,0,0,0,
	dataLiuShui=@date1, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 
	from #temp_goods  a where a.spno not in
	(
	select distinct spno
	from #temp_goods_date1 
	)
*/

/*
	insert into #temp_goods (
	spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select distinct spno=e.belong,e.belong,e.mingcheng,e.danwei,e.dw1,e.guige,0,e.bzlsj,e.shuliang,dLiushui=e.dDate_pandian, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 
	from #temp1_save e left join #temp_goods f on e.spno=f.spno and e.dDate_pandian=f.dataLiuShui
	where f.dataLiuShui is null






	insert into #temp_goods (
	spno,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select e.spno,e.mingcheng,e.danwei,e.dw1,e.guige,0,e.bzlsj,e.shuliang,e.dLiushui, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from
	( 
	select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige, a.bzlsj,a.shuliang,dLiushui=b.dDate
	from #temp10 a left join 
	(select distinct c.guizuno,dDate=c.zdriqi,cSpno=c.spno,d.belong 
	 from pdd_sp c left join spxx d on c.Spno=d.spno
	 where c.zdriqi between @date1 and @date2
	) b on a.spno=b.cspno
	where (b.guizuno in (select guizuno=spno from #tempCon where bChecked=1) 
	   or b.belong in (select belong=spno from #tempCon where bChecked=1))
	 and b.dDate<=@date2
	) e left join #temp_goods f on e.spno=f.spno and e.dLiushui=f.dataLiuShui 
	where f.dataLiuShui is null


	
	insert into #temp_goods (
	spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select distinct a.spno,a.belong,a.mingcheng,a.danwei,a.dw1,a.guige,0,a.bzlsj,a.shuliang,
--	//select distinct a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,0,0,0,
	dataLiuShui=@date1, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 
	from #temp_goods  a where a.spno not in
	(
	select distinct spno
	from #temp_goods where dataLiuShui=@date1
	)


	

	insert into #temp_goods (
	spno,belong,mingcheng,danwei,dw1,guige,bzjj,bzlsj,shuliang,dataLiuShui,
	rkshuliang,rkjine,jcshuliang,jcjine,ckshuliang,ckjine,fcshuliang,fcjine,
	syshuliang,syjine,lsshuliang,lsjine,qimoshuliang,lsjinjia,bPanDian
	) 
	select distinct spno=a.spno,a.belong,a.mingcheng,a.danwei,a.dw1,a.guige,0,a.bzlsj,a.shuliang,
--	//select distinct a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,0,0,0,
	dataLiuShui=@date2, 
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 
	from #temp_goods a where a.belong not in 
	(
	select distinct belong
	from #temp_goods where dataLiuShui=@date2
	) 
*/

end


GO
