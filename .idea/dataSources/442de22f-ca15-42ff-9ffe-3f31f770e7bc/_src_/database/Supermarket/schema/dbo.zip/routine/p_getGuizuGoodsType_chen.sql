create proc p_getGuizuGoodsType_chen
as

if (select object_id('tempdb..#guizu_type'))is not null
drop table #guizu_type
create table #guizu_type
(
  guizuno varchar(32),
  type varchar(1000)
)
declare Cur_type cursor for
select guizuno,type from guizu_type
--where guizuno='100'
order by guizuno,orderId

declare @guizuno varchar(32)
declare @tmp_guizuno varchar(32)
declare @type  varchar(32)
declare @tmp_type  varchar(32)
declare @value varchar(1000)

select @guizuno='',@type='',@value='',@tmp_guizuno=''

open Cur_type
fetch next from Cur_type  into @guizuno,@type
set @tmp_guizuno=@guizuno


while (@@fetch_status=0)
begin
   set @value=@value+@type++'\'
   fetch next from Cur_type  into @guizuno,@type
   if @tmp_guizuno<>@guizuno 
   begin
     insert into #guizu_type
     (guizuno,type)
     values
     (@tmp_guizuno,@value)  
     set  @value=''
   end

   set @tmp_guizuno=@guizuno
   set @tmp_type=@type
end
 insert into #guizu_type
     (guizuno,type)values(@guizuno,@value)  

close Cur_type
deallocate Cur_type

select guizuno,type from #guizu_type
order by guizuno


GO
