


/*
p_getInprice_avg '2009-07-26'
*/

CREATE    procedure p_getInprice_avg
@dDate datetime
as
begin

	select guizuno,guizu,spno,mingcheng,belong,danwei,dw1,guige,bzjj0=bzjj,bzjj,bzlsj,selected
	into #temp_spxx_storage
	from spxx
	where isnull(selected,0)=1

/*-=============================获得最新历史售价*/
  select spno=cSpNo,dDate=max(dDate),fSalePrice=cast(0.00 as money),fCostPrice=cast(0.00 as money)
	into #temp_SaleSheet_Day
  from dbo.t_SaleSheet_Day
  where dDate<=@dDate
  group by cSpNo

  update a set a.fSalePrice=b.fSalePrice, a.fCostPrice=b.fCostPrice
  from #temp_SaleSheet_Day a,t_SaleSheet_Day b
  where a.dDate=b.dDate and a.spno=b.cSpno --and isnull(b.fSalePrice,0)>0

  update a set a.bzlsj=b.fSalePrice
  from #temp_spxx_storage a,#temp_SaleSheet_Day b
  where a.spno=b.spno and  isnull(b.fSalePrice,0)>0

  update a set a.bzjj=b.fCostPrice
  from #temp_spxx_storage a,#temp_SaleSheet_Day b
  where a.spno=b.spno and  isnull(b.fCostPrice,0)>0

	select a.spno,c.belong,shuliang=sum(a.shuliang),jinjiajine=sum(a.jinjiajine),fInprice_avg=cast(0.00 as money)
	into #temp_spxx_jinjia
	from
	(
		select sheetno=jcdno,serno,spno,shuliang,jinjiajine,zdriqi
    from jcd_sp
		where zdriqi<=@dDate
		union all
		select sheetno=rkdno,serno,spno,shuliang,jinjiajine,zdriqi
    from rkd_sp
		where zdriqi<=@dDate
		union all
		select sheetno=fcdno,serno,spno,-shuliang,-jinjiajine ,zdriqi
    from fcd_sp
		where zdriqi<=@dDate

	) a left join spxx c on a.spno=c.spno
	where a.zdriqi<=@dDate
	group by a.spno,c.belong

  update a set a.spno=b.spno
  from #temp_spxx_jinjia a,#temp_spxx_storage b
  where a.belong=b.spno

  select spno,shuliang=sum(shuliang),jinjiajine=sum(jinjiajine),fInprice_avg
  into #temp_spxx_jinjia2
  from #temp_spxx_jinjia
  group by spno,fInprice_avg

  update #temp_spxx_jinjia2
	set fInprice_avg=case when shuliang<>0 then jinjiajine/shuliang else null end

  update a set a.fInprice_avg=b.bzjj
  from #temp_spxx_jinjia2 a,#temp_spxx_storage b
  where a.spno=b.spno and  isnull(b.bzjj,0)>0





  update a set a.bzjj=b.fInprice_avg
	from #temp_spxx_storage a,#temp_spxx_jinjia2 b
	where a.belong=b.spno and fInprice_avg is not null

	select
				 guizuno,guizu,spno,mingcheng,belong,danwei,dw1,guige,bzjj0=bzjj,bzjj,bzlsj,selected
  from #temp_spxx_storage
  order by spno


end


GO
