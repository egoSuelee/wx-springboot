


CREATE    procedure p_getInprice_avg_belong
@dDate datetime
as
begin
---hello
	select guizuno,guizu,spno,mingcheng,belong,danwei,dw1,guige,bzjj0=bzjj,bzjj,bzlsj,selected
	into #temp_spxx_storage
	from spxx
	where isnull(selected,0)=1


/*-=============================获得最新历史售价*/
  select spno=cSpNo,dDate=max(dDate),fSalePrice=cast(0.00 as money),fCostPrice=cast(0.00 as money)
	into #temp_SaleSheet_Day
  from dbo.t_SaleSheet_Day
  where dDate<=@dDate
  group by cSpNo

  update a set a.fSalePrice=b.fSalePrice, a.fCostPrice=b.fCostPrice
  from #temp_SaleSheet_Day a,t_SaleSheet_Day b
  where a.dDate=b.dDate and a.spno=b.cSpno --and isnull(b.fSalePrice,0)>0

  update a set a.bzlsj=b.fSalePrice
  from #temp_spxx_storage a,#temp_SaleSheet_Day b
  where a.spno=b.spno and  isnull(b.fSalePrice,0)>0

  update a set a.bzjj=b.fCostPrice
  from #temp_spxx_storage a,#temp_SaleSheet_Day b
  where a.spno=b.spno and  isnull(b.fCostPrice,0)>0


	select a.spno,c.belong/*=cast('' as varchar(32))*/,shuliang=sum(a.shuliang),jinjiajine=sum(a.jinjiajine),fInprice_avg=cast(0.00 as money)
	into #temp_spxx_jinjia0
	from
	(
		select sheetno=jcdno,serno,spno,shuliang,jinjiajine,zdriqi
    from jcd_sp
		where zdriqi<=@dDate
		union all
		select sheetno=rkdno,serno,spno,shuliang,jinjiajine,zdriqi
    from rkd_sp
		where zdriqi<=@dDate
		union all
		select sheetno=fcdno,serno,spno,-shuliang,-jinjiajine ,zdriqi
    from fcd_sp
		where zdriqi<=@dDate

	) a left join spxx c on a.spno=c.spno
	where a.zdriqi<=@dDate
	group by a.spno,c.belong
/*
	update a set a.belong=b.belong
	from #temp_spxx_jinjia0 a,spxx b
	where a.spno=b.spno
*/

  update a set a.spno=b.spno
  from #temp_spxx_jinjia0 a,#temp_spxx_storage b
  where a.belong=b.spno

	select spno/*=belong*/,shuliang=sum(shuliang),jinjiajine=sum(jinjiajine),fInprice_avg=cast(0.00 as money),
				 guizuno=cast('' as varchar(32)),guizu=cast('' as varchar(128)),mingcheng=cast('' as varchar(128)),
				 danwei=cast('' as varchar(32)),dw1=cast('' as varchar(32)),guige=cast('' as varchar(64)),
				 bzjj0=cast(0.0 as money),bzjj=cast(0.0 as money),bzlsj=cast(0.0 as money),selected=1,
				 belong=belong
	into #temp_spxx_jinjia
	from #temp_spxx_jinjia0
	--group by belong
  group by spno

--select * from  #temp_spxx_jinjia order by spno

  update #temp_spxx_jinjia
	set fInprice_avg=case when shuliang<>0 then jinjiajine/shuliang else null end

  update a set a.fInprice_avg=b.bzjj
  from #temp_spxx_jinjia a,#temp_spxx_storage b
  where a.spno=b.spno and  isnull(b.bzjj,0)>0

 


  update a set a.bzjj0=a.fInprice_avg,a.bzjj=a.fInprice_avg,a.mingcheng=b.mingcheng,a.guizuno=b.guizuno,a.guizu=b.guizu,
							 a.danwei=b.danwei,a.dw1=b.dw1,a.guige=b.guige,a.bzlsj=b.bzlsj
	from #temp_spxx_jinjia a ,spxx b
	where a.spno=b.spno

	select 
				 guizuno,guizu,spno,mingcheng,belong,danwei,dw1,guige,bzjj0=bzjj,bzjj,bzlsj,selected
  from #temp_spxx_jinjia
--	where guizuno='88001'
	order by spno


end


GO
