
/*

[p_guizu_FinanceListZh] '','2010-10-08','2011-12-08'
p_guizu_FinanceListZh_web_fenye_table_qu_01 '','2011-3-01','2011-12-08',103,a_01,'5af276a7fba2e87b'

select * from u_key.dbo.a_01

2010-10-08 ——2010-12-8
*/
--select * from a_01
--select * from guizu
--select  from guizu where cMarketNo='103' and quno='0101'
CREATE           procedure [dbo].[p_guizu_FinanceListZh_web_fenye_table_qu_01]
@financeType varchar(32),
@date1 datetime,
@date2 datetime,

	@CmarkNo varchar(32),
	@tble varchar(100),
	@qu varchar(64)
as
begin  
--exec dbo.p_GetPath_web 

--select * from ##temp_Type_qu


--select  guizuno as cGuizuNo into #tempguizu from guizu where quno in (select F1 from dbo.SplitStr(@qu,'@'))

if (select object_id('tempdb..#tempguizu'))is not null
			drop table #tempguizu 
			create table #tempguizu(guizuno varchar(32))
exec('
    insert into #tempguizu
	select  guizuno from guizu where quno in(select guizuno  from Temp_SupKey.dbo.temp_TypeTree'+@qu+')')		--select * from ##tempguizu
--select * from ##temp_Type_qu
--select  guizuno as cGuizuNo into #tempguizu from guizu where quno in (select diquno from ##temp_Type_qu where cPath+'.' like '%.'+@qu+'.%')   ---条件指的是对单个店总大的销售查询

  /*生成报表的列*/
	set @financeType=rtrim(ltrim(@financeType))
  select detail,sum(shishou) shishou 
  into #jiesuan_detail
	from jiesuan_byguizu
  where  zdriqi between @date1 and  @date2
  			 and guizuno in 
						(select guizuno from guizu where (cFinanceType=@financeType  or @financeType=''))
				 and guizuno in (select guizuno from #tempguizu)	
  group by detail
/*  
  if (select count(*) #jiesuan_detail)=0 
  begin
    select 商户No='空',商户='空'
		return 1
  end
*/
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
--  declare @guizuno_cursor varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     商户No varchar(32),
     商户 varchar(64)
	)

  declare @cAddFields varchar(8000)
  set @cAddFields=''
  declare @strtmp varchar(8000)
  set @strtmp=''
  declare @strtmp_group varchar(8000)
  declare @strtmp_group_balance varchar(8000)
  set @strtmp_group=''
  set @strtmp_group_balance=''

  declare @strtmp_Clear varchar(8000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
/*
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(round(sum(cast('+@detail+' as money)),4) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
*/
    set @cAddFields=@cAddFields+@detail+' money,'
    set @strtmp=@strtmp+'0,'
    set @strtmp_group=@strtmp_group+@detail+'=cast(round(sum(cast('+@detail+' as money)),4) as money),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then null else '+@detail+' end,'


		fetch next from detail_cursor
    into @detail
  end
/*
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(round(sum(cast(合计 as money)),4) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
*/
  set @cAddFields=@cAddFields+' 合计 money'
  set @strtmp=@strtmp+'0'
  set @strtmp_group=@strtmp_group+' 合计=cast(round(sum(cast(合计 as money)),4) as money)'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then null else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

--print @cAddFields

	select guizuno,guizu,detail,
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,round(sum(round(cast(shishou as money),2)),2) shishou
  into #jiesuan
	from jiesuan_byguizu
	where zdriqi between @date1 and  @date2
  			 and guizuno in 
						(select guizuno from guizu where (cFinanceType=@financeType  or @financeType=''))
				 and guizuno in (select guizuno from #tempguizu)	
	group by  guizuno,guizu,detail
	order by guizuno,guizu
  
  declare jiesuan_cursor cursor
  for
  select guizuno,guizu,detail,shishou=cast(round(shishou,2) as varchar(32))
  from #jiesuan
  order by guizuno,guizu,detail
 
  select guizuno,guizu,shishou=sum(shishou )
  into #jiesuan_heji
  from #jiesuan
  group by guizuno,guizu
  

  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(64)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou

  while @@fetch_status=0
  begin
		if (select 商户No from #account_detail 
				where 商户No=@shouyinyuanno and 商户=@shouyinyuanmc ) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','+@strtmp)
    end
/*
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 商户No='''+@shouyinyuanno+''' and 商户='''+@shouyinyuanmc+'''')
*/
    exec('update #account_detail set '+@detail+'='+@shishou
					+' where 商户No='''+@shouyinyuanno+''' and 商户='''+@shouyinyuanmc+'''')
    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 
/*
  update a set a.合计=dbo.trim(b.shishou)
*/
  update a set a.合计=round(cast(b.shishou as money),2)
  from #account_detail a
  left join #jiesuan_heji b
  on a.商户No=b.guizuno and a.商户=b.guizu 
 
 
/*
  exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 商户No=''总计'',商户=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear)
*/
	
  select *,销售数量=cast(0.00 as money) into #account_detail_last from #account_detail
  where  商户No is null

	insert into #account_detail_last
  select *,销售数量=0.0000 from #account_detail
  exec('
		insert into #account_detail_last
    select 商户No=''总计'',商户=null,'+@strtmp_group
    +', 销售数量=null from #account_detail '
    +@strtmp_Clear)
  
--  alter table #account_detail_last add shuliang money
 drop table #tempguizu
 update a set a.销售数量=b.销售数量
  from #account_detail_last a,
  (
   select guizuno,guizu,销售数量=sum(shuliang) from lsdsp where lsriqi between @date1 and @date2
   group by guizuno,guizu
	) b
  where a.商户No=b.guizuno and a.商户=b.guizu
  
  update #account_detail_last set 销售数量=(select SUM(销售数量) from #account_detail_last)where 商户No='总计'

  --select COUNT(*) from  #account_detail_last 
  
  --  select * from 
  --  (select  ROW_NUMBER() OVER(order by 商户No asc) as 序号,a.*  
  --  from #account_detail_last a where 1=1) as sp where 序号 between''+str((@PageIndex-1)*@PageSize+1)+'' AND ''+str(@PageIndex*@PageSize)+''

--exec('if (select object_id('''+@tble+'''))is not null 
--drop table '+@tble+'
-- select * into '+@tble+' from #account_detail_last '
--)

exec('if (select object_id(''U_key.dbo.'+@tble+'''))is not null 
drop table U_key.dbo.'+@tble+'
 select * into U_key.dbo.'+@tble+' from #account_detail_last '
)
end


GO
