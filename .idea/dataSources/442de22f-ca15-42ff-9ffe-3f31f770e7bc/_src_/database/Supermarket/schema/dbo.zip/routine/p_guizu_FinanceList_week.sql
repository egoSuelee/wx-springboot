








CREATE          procedure p_guizu_FinanceList_week
@financeType varchar(32),
@Year_tongji char(4)
as
begin
	declare @date1 datetime
	declare @date2 datetime
	set @date1=@Year_tongji+'-01-01'
	set @date2=@Year_tongji+'-12-31'
  /*生成报表的列*/
	set @financeType=rtrim(ltrim(@financeType))
  select detail,sum(shishou) shishou 
  into #jiesuan_detail
	from jiesuan_byguizu
  where  zdriqi between @date1 and  @date2
  			 and guizuno in 
						(select guizuno from guizu where (cFinanceType=@financeType  or @financeType=''))
				 and guizuno in (select guizuno=cGuizuno from #tempguizu)	
  group by detail
/*  
  if (select count(*) #jiesuan_detail)=0 
  begin
    select 商户No='空',商户='空'
		return 1
  end
*/
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
--  declare @guizuno_cursor varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     商户No varchar(32),
     商户 varchar(64),
		 年   char(4),
		 周   int
	)

  declare @cAddFields varchar(8000)
  set @cAddFields=''
  declare @strtmp varchar(8000)
  set @strtmp=''
  declare @strtmp_group varchar(8000)
  declare @strtmp_group_balance varchar(8000)
  set @strtmp_group=''
  set @strtmp_group_balance=''

  declare @strtmp_Clear varchar(8000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
/*
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(round(sum(cast('+@detail+' as money)),4) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
*/
    set @cAddFields=@cAddFields+@detail+' money,'
    set @strtmp=@strtmp+'0,'
    set @strtmp_group=@strtmp_group+@detail+'=cast(round(sum(cast('+@detail+' as money)),4) as money),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then 0 else '+@detail+' end,'


		fetch next from detail_cursor
    into @detail
  end
/*
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(round(sum(cast(合计 as money)),4) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
*/
  set @cAddFields=@cAddFields+' 合计 money'
  set @strtmp=@strtmp+'0'
  set @strtmp_group=@strtmp_group+' 合计=cast(round(sum(cast(合计 as money)),4) as money)'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then 0 else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

--print @cAddFields

	select guizuno,guizu,cYear=substring(dbo.getdaystr(zdriqi),1,4),cMonth=dbo.f_GetWeeks(zdriqi),detail,
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,round(sum(round(cast(isnull(shishou,0) as money),2)),2) shishou
  into #jiesuan
	from jiesuan_byguizu
	where zdriqi between @date1 and  @date2
  			 and guizuno in 
						(select guizuno from guizu where (cFinanceType=@financeType  or @financeType=''))
				 and guizuno in (select guizuno=cGuizuno from #tempguizu)	
	group by  guizuno,guizu,substring(dbo.getdaystr(zdriqi),1,4),dbo.f_GetWeeks(zdriqi),detail
	order by guizuno,guizu
  
  declare jiesuan_cursor cursor
  for
  select guizuno,guizu,
				 cYear,cMonth,
				 detail,shishou=cast(round(isnull(shishou,0),2) as varchar(32))
  from #jiesuan
  order by guizuno,guizu,cYear,cMonth,detail
 
  select guizuno,guizu,cYear,cMonth,shishou=sum(shishou )
  into #jiesuan_heji
  from #jiesuan
  group by guizuno,guizu,cYear,cMonth
  

  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(64)
  declare @year char(4)
  declare @month int
  declare @month_c char(2)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@year,@month,@detail,@shishou
	set @month_c=cast(@month as char(2))
  while @@fetch_status=0
  begin
		if (select 商户No from #account_detail 
				where 商户No=@shouyinyuanno and 商户=@shouyinyuanmc and 年=@year and 周=@month ) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','''+@year+''','+@month_c+','+@strtmp)
    end
/*
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 商户No='''+@shouyinyuanno+''' and 商户='''+@shouyinyuanmc+'''')
*/
    exec('update #account_detail set '+@detail+'='+@shishou
					+' where 商户No='''+@shouyinyuanno+''' and 商户='''+@shouyinyuanmc+''' and 年='''+@year+''' and 周='+@month_c)
    fetch next from jiesuan_cursor
	  into @shouyinyuanno,@shouyinyuanmc,@year,@month,@detail,@shishou
		set @month_c=cast(@month as char(2))
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 
/*
  update a set a.合计=dbo.trim(b.shishou)
*/
  update a set a.合计=round(cast(b.shishou as money),1)
  from #account_detail a
  left join #jiesuan_heji b
  on a.商户No=b.guizuno and a.商户=b.guizu and a.年=b.cYear and a.周=b.cMonth 
 
  exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 商户No=''总计'',商户=null,年=null,周=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select a.*,确认金额=null,[商户/导购员签字]=null,签字日期=null from #account_detail_last a')


end


GO
