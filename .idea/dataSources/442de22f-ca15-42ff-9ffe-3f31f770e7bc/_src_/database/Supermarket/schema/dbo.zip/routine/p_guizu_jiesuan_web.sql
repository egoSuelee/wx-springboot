/*
  p_guizu_jiesuan_web '2011-1-1','2011-1-1'
*/
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE p_guizu_jiesuan_web 
@date1 datetime,
@date2 datetime
AS
BEGIN
   if (select object_id('tempdb..#temp_jiesuan_web'))is not null
   drop table #temp_jiesuan_web
	select   guizuno, guizu, jiesuanriqi=convert(varchar(100),jiesuanriqi,23),riqi1=convert(varchar(100),riqi1,23),
riqi2=convert(varchar(100),riqi2,23), jiesuanno,feiyongjine,koudianjine, xiaoshoujine, jiesuanjine,shenhe
 into #temp_jiesuan_web from guizu_jiesuan --where jiesuanriqi between @date1 and @date2
select * from #temp_jiesuan_web
union all
select guizuno='',guizu='合计',jiesuanriqi='',riqi1='',
riqi2='', jiesuanno='',SUM(feiyongjine),SUM(koudianjine),SUM(xiaoshoujine),SUM(jiesuanjine),shenhe='' 
from #temp_jiesuan_web 
END
GO
