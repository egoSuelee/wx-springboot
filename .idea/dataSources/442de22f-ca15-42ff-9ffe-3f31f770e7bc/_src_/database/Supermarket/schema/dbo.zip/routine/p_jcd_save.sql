
CREATE  procedure p_jcd_save
@jcdno varchar(32),
@cangkuno varchar(32),
@cangku varchar(32),
@zhidanren varchar(32),
@zhidanriqi datetime,
@shenheren varchar(32),
@shenheriqi varchar(32),
@guizuno varchar(32),
@guizu varchar(64),
@jingbanren varchar(32),
@jingbanrenno varchar(32),
@lingshoujine money,
@jinjiajine money,
@chajiajine money,
@shenhe smallint,@zdtime datetime
as
begin
  delete from jcd where jcdno=@jcdno  
  delete from jcd_sp where jcdno=@jcdno 

  insert into jcd (cangkuno,cangku,jcdno,zhidanren,zhidanriqi,shenheren,shenheriqi,  
  guizuno,guizu,jingbanren,jingbanrenno,lingshoujine,jinjiajine,chajiajine,shenhe,zdtime)  
  values (  
  @cangkuno,@cangku,@jcdno,@zhidanren,@zhidanriqi,@shenheren,@shenheriqi,  
  @guizuno,@guizu,@jingbanren,@jingbanrenno,@lingshoujine,@jinjiajine,@chajiajine,@shenhe,@zdtime  
  )  

end


GO
