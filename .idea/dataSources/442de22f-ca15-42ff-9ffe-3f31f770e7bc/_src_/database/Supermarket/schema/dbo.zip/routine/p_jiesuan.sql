







CREATE                     procedure [dbo].[p_jiesuan]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime

as
begin
  declare @xiaoshou_zj money /*正价销售额*/
  declare @xiaoshou_tj money /*特价销售额*/
  declare @xiaoshou_tj_ratio money /*特价销售扣点金额*/
  declare @feiyong money
  declare @koudian money
  declare @JiesuanNo varchar(32)
  declare @iDaysRatio money
  declare @iDays int

	/*从商户合同里面查找商户进驻的日期*/
  declare @inDate1 datetime
  declare @inDate2 datetime
  set @inDate1=(select top 1 dbo.getDayStr(qixian1) from shanghu_hetong where guizuno=@guizuno)
  set @inDate2=(select top 1 dbo.getDayStr(qixian2) from shanghu_hetong where guizuno=@guizuno)

  if @inDate1 between @date1 and @date2 
  begin
    set @date1=@inDate1
  end
  
  if @inDate2 < @date2 
  begin
    return 10
  end
  set @iDays=(SELECT DATEDIFF(day, @date1, @date2)+1)

  declare @bCi bit
  set @bCi=0
  select @bCi=isnull(_RbCi,0) from  shanghu_hetong where guizuno=@guizuno
  
  if @bCi=1 
  begin  
	set @iDaysRatio=1
  end else
  begin
	set @iDaysRatio=@iDays/30.0
  end

  /*先查找出有没有审核项目（销售、支出）的柜组*/ 
  select guizuno,guizu,sheetno=lsdno,itemNo=guizuno,item=guizu,itemMoney=shishou,riqi1=zdriqi,riqi2=zdriqi,zdriqi,shenhe,tablename='lsd'
  into #NotShenhe
  from lsd
  where guizuno=@guizuno and (zdriqi between @date1 and @date2) and (shenhe is null or shenhe=0)
  union all
  select guizuno,guizu,sheetno=cast(serno as varchar(32)),itemNo=feiyongno,item=feiyong,itemMoney=feiyongjine,riqi1,riqi2,zdriqi,shenhe,tablename='guizufeiyong'
  from guizufeiyong
  where guizuno=@guizuno and  (zdriqi between @date1 and @date2) and (shenhe is null or shenhe=0)
 
  select spno,iSpec 
	into #spxx_zj 
	from spxx 
	where guizuno=@guizuno and (iSpec=0 or iSpec is null)

  select spno,dPeriod1,dPeriod2,fRatio,iSpec=1 
  into #spxx_tj 
  from dbo.t_Ploy_detail 
  where guizuno=@guizuno 
				and (( dPeriod1 between @date1 and @date2)
						  or (dPeriod2  between @date1 and @date2)
             or (dPeriod1  <=@date1 and dPeriod2>=@date2)

						)

/*
  where guizuno=@guizuno 
				and ((dPeriod2 between  @date1 and @date2)
						  or (dPeriod1 between  @date1 and @date2)
						)
*/
  if (select count(guizuno) from #NotShenhe)=0 /*本时间段内，所有销售和支出都已经审核*/
  begin
    /*计算本次结算单号*/
    set @JiesuanNo=
       dbo.LeftAddChar(cast(cast(isnull((select right(rtrim(max(jiesuanno)),4) 
										                 from guizu_jiesuan
											               where guizuno=@guizuno),'0000')
                             as int
                            )+1 
                       as varchar(32)
                       ),'0',4)
    

    /*计算正价销售额*/
    select lsdno 
    into #lsdno_notjiesuan
		from lsd 
    where  guizuno=@guizuno 
					and (jiesuanover=0 or jiesuanover is null) 
					and zdriqi between @date1 and @date2 

    select a.guizuno,a.guizu,a.spno,a.lsdno,a.jine,fRatio=null,b.iSpec 
    into #lsdsp_zj
    from lsdsp a 
    right join #spxx_zj b
    on a.spno=b.spno 
    where  a.guizuno=@guizuno and a.lsriqi between @date1 and @date2
           and (a.jiesuanover=0 or a.jiesuanover is null)
           --and a.lsdno in (select lsdno from #lsdno_notjiesuan) 

    /*计算本期支出和费用*/
		declare @feiyongjine money  
    set @feiyongjine=isnull(
      (
      select feiyongjine=sum(feiyongjine)
 	 		 from guizufeiyong
 	 	  where guizuno=@guizuno and  (zdriqi between @date1 and @date2) and shenhe=1
      ),0)
    /*计算特价商品的本期销售额*/
    select c.*
    into #lsdsp_tj
    from 
    ( 
	    select a.guizuno,a.guizu,a.spno,a.lsdno,a.jine,b.fRatio,b.iSpec 
 		   from lsdsp a 
   	 		right join #spxx_tj b
   		 on a.spno=b.spno and a.lsriqi between b.dPeriod1 and b.dPeriod2
   		 where  a.guizuno=@guizuno and a.lsriqi between @date1 and @date2
              and a.lsdno in (select lsdno from #lsdno_notjiesuan) 
    ) c
    where c.guizuno is not null

    drop table #spxx_zj
    drop table #spxx_tj


    set @xiaoshou_zj=isnull((select sum(jine) from #lsdsp_zj ),0)    
    set @xiaoshou_tj=isnull((select sum(jine) from #lsdsp_tj ),0)     
    set @xiaoshou_tj_ratio=isnull((select sum(jine*fRatio/100.00) from #lsdsp_tj ),0)     
    
    declare @guizu varchar(64)
    set @guizu=(select top 1 guizu from guizu where guizuno=@guizuno) 
   
    select jiesuanno=@guizuno+'-'+@JiesuanNo,
           xiaoshou_total=@xiaoshou_zj+@xiaoshou_tj,/*总销售*/
           xiaoshou_zj=@xiaoshou_zj,/*正价销售*/
           xiaoshou_tj=@xiaoshou_tj,/*特价销售*/
           xiaoshou_tj_ratio=round(@xiaoshou_tj_ratio,2),/*特价扣点金额*/
           period1=@date1,
           period2=@date2,
           guizuno=@guizuno, 
           guizu=@guizu,
           detail='审核'
    into #Shanghu_hetong_xiaoshou_sum

    /*查询该柜组本时间段内 按照保底扣点方案对正价销售金额进行分摊*/
		select guizuno,fMoney1=round(fMoney1*@iDaysRatio,2),
					 fMoney2=round(fMoney2*@iDaysRatio,2),fRatio,iSerno,iDays=@iDays
    into #Shanghu_hetong_Ratio_tmp0
		from dbo.Shanghu_hetong_Ratio
    where guizuno=@guizuno
--select * from #Shanghu_hetong_Ratio_tmp0

/*#Shanghu_hetong_Ratio_tmp*/

    declare @minfMoney1 money
    declare @minfRatio money
    set @minfMoney1=(select min(fMoney1) from #Shanghu_hetong_Ratio_tmp0 )
    set @minfRatio=(select fRatio from #Shanghu_hetong_Ratio_tmp0 where fMoney1=@minfMoney1)
 
    select guizuno=@guizuno,fMoney1=-999999999,fMoney2=@minfMoney1,fRatio=@minfRatio,
    iSerno=-1,iDays=@iDays,fDispartMoney=@minfMoney1  /*处理没有达到最小保底金额的情况，按照保底金额为基数进行计算*/
    into #Shanghu_hetong_Ratio_tmp/*记录 按照保底扣点方案对正价销售金额进行分摊*/
    where (select count(guizuno) from #Shanghu_hetong_Ratio_tmp0)>0

    union all
    select guizuno,fMoney1,fMoney2,fRatio,iSerno,iDays,fDispartMoney=fMoney2-fMoney1
    from #Shanghu_hetong_Ratio_tmp0
    where fMoney2<=@xiaoshou_zj
    union all    
    select c.guizuno,c.fMoney1,c.fMoney2,c.fRatio,c.iSerno,c.iDays,c.fDispartMoney
    from 
      (
	    select guizuno,fMoney1,fMoney2,fRatio,iSerno,iDays,fDispartMoney=@xiaoshou_zj-fMoney1
  	  from #Shanghu_hetong_Ratio_tmp0
    	where fMoney1<@xiaoshou_zj and fMoney2>=@xiaoshou_zj
      ) c
    where c.fDispartMoney>=0

--select * from #Shanghu_hetong_Ratio_tmp
    drop table #Shanghu_hetong_Ratio_tmp0

    declare @standardMoney money
    set @standardMoney=(select max(fMoney1) from #Shanghu_hetong_Ratio_tmp)

    select guizuno,fMoney1,fMoney2,fRatio,iSerno,iDays,fDispartMoney,fKoudianMoney=fDispartMoney*fRatio/100.0
    into #Shanghu_hetong_Ratio/*记录 按照保底扣点方案对正价销售金额进行分摊 并且计算分摊列表*/
    from #Shanghu_hetong_Ratio_tmp    


    drop table #Shanghu_hetong_Ratio_tmp

--select * from #Shanghu_hetong_Ratio

    /************************************************************/
   
    declare @xiaoshou_zj_ratio money

		declare @koudianfangshi smallint --扣点执行方式 0-分段式扣点 1-直通式扣点
		set  @koudianfangshi=isnull((select top 1 koudianfangshi from shanghu_hetong where guizuno=@guizuno),0)
		if @koudianfangshi=0 /*0-分段式扣点*/
		begin
	    set @xiaoshou_zj_ratio=isnull((select sum(isnull(fKoudianMoney,0)) from #Shanghu_hetong_Ratio),0)
		end else
		begin/*1-直通式扣点*/
			set @xiaoshou_zj_ratio=round(@xiaoshou_zj*
														isnull((select top 1 fRatio 
																		from dbo.Shanghu_hetong_Ratio 
																		where guizuno=@guizuno and @xiaoshou_zj >fMoney1 and @xiaoshou_zj<=fMoney2
														 			 )
																	,0)/100.00
																	,2)

		end
    insert into guizu_jiesuan
    (jiesuanno,xiaoshoujine,xiaoshou_zj,baodijine,koudian,koudian_zj,xiaoshou_tj,koudian_tj,
     koudianjine,feiyongjine,riqi1,riqi2,guizuno,guizu,caiwu,chuna,
     shenheren,jiesuanjine,qita,jiesuanriqi,beizhu,shenhe,jiesuanover)
    select jiesuanno, xiaoshou_total,/*总销售*/ xiaoshou_zj,/*正价销售*/ xiaoshou_zj_standard=@standardMoney,/*正价扣点金额参考标准*/
           koudian=null, xiaoshou_zj_Ratio=round(@xiaoshou_zj_ratio,2),/*正价扣点金额*/
           xiaoshou_tj,/*特价销售*/xiaoshou_tj_ratio,/*特价扣点金额*/
           koudianjine=round(@xiaoshou_zj_ratio,2)+xiaoshou_tj_ratio,
           feiyongjine=@feiyongjine,
           period1,period2,guizuno,guizu,caiwu=null,chuna=null,shenheren=null,
           jiesuanjine=xiaoshou_total-(round(@xiaoshou_zj_ratio,2)+xiaoshou_tj_ratio)-@feiyongjine,qita=0,jiesuanriqi=@date2,
           beizhu=null,shenhe=0,jiesuanover=0
    from #Shanghu_hetong_xiaoshou_sum 

                set @jiesuanNo=@guizuno+'-'+@JiesuanNo 

    
		update lsdsp set jiesuanover=1,jiesuanno=@JiesuanNo
		where jiesuanover=0 and guizuno=@guizuno
					and lsriqi between @date1 and @date2

		update lsd set jiesuanover=1,jiesuanno=@JiesuanNo
		where jiesuanover=0 and guizuno=@guizuno
					and zdriqi between @date1 and @date2

		update guizufeiyong set jiesuanover=1,jiesuanno=@JiesuanNo
		where jiesuanover=0 and guizuno=@guizuno
					and zdriqi between @date1 and @date2


		
 --   print  @JiesuanNo
 
    insert into guizu_jiesuan_mingxi (jiesuanno,zdriqi,guizuno,guizu,xiaoshoujine,koulv,yingfujine)
		select jiesuanno,zdriqi,guizuno,guizu,sum(shishou),0,sum(shishou)
		from lsd
		where guizuno=@guizuno and jiesuanno=@JiesuanNo
				 and jiesuanover=1 
		group by jiesuanno,zdriqi,guizuno,guizu
    
    return 1
  end else
  begin
    select jiesuanno=null,
					 koudianjine=0,guizu=null,caiwu=null,chuna=null,shenheren=null,	
           xiaoshou_total=0,/*总销售*/
           xiaoshou_zj=0,/*正价销售*/
           xiaoshou_zj_standard=0,
           xiaoshou_zj_ratio=0,/*正价扣点金额*/
           xiaoshou_tj=0,/*特价销售*/
           xiaoshou_tj_ratio=0,/*特价扣点金额*/
           feiyongjine=0,
           period1=@date1,
           period2=@date2,
           guizuno=@guizuno, 
           detail='未审核'
    return -1
	end
  

end


GO
