
create proc [dbo].[p_lookupStorageByGuizuByTable_chen]
	@guizu varchar(32),
	@SelectDate datetime
as
set nocount on

begin
exec('

	if (select object_id(''tempdb..#temp_spxx''))is not null 
				drop table #temp_spxx
			if (select object_id(''tempdb..#temp_spxx0''))is not null
			drop table #temp_spxx0
			if (select object_id(''tempdb..#temp_rkd_sp''))is not null
			drop table #temp_rkd_sp
			if (select object_id(''tempdb..#temp_jcd_sp''))is not null
			drop table #temp_jcd_sp
			if (select object_id(''tempdb..#temp_ckd_sp''))is not null
			drop table #temp_ckd_sp
			if (select object_id(''tempdb..#temp_fcd_sp''))is not null
			drop table #temp_fcd_sp
			if (select object_id(''tempdb..#temp_syd_sp''))is not null
			drop table #temp_syd_sp
			if (select object_id(''tempdb..#temp_lsd_sp''))is not null
			drop table #temp_lsd_sp
			if (select object_id(''tempdb..#temp_sp_day''))is not null
			drop table #temp_sp_day
			if (select object_id(''tempdb..#temp_guizuno''))is not null
			drop table #temp_guizuno
			if (select object_id(''tempdb..#temp_CurWh''))is not null
			drop table #temp_CurWh
			if (select object_id(''tempdb..#temp_CurWh0''))is not null
			drop table #temp_CurWh0
			if (select object_id(''tempdb..#temp_modifySp''))is not null
			drop table #temp_modifySp
			if (select object_id(''tempdb..#temp_modifyTotal''))is not null
			drop table #temp_modifyTotal
			if (select object_id(''tempdb..#temp_MinDate''))is not null
			drop table #temp_MinDate
			if (select object_id(''tempdb..#temp_MaxDate''))is not null
			drop table #temp_MaxDate
			if (select object_id(''tempdb..#temp_MinDate''))is not null
			drop table #temp_MinDate

			if (select object_id(''tempdb..#rkd_sp0''))is not null
			drop table #rkd_sp0
			if (select object_id(''tempdb..#rkd_sp''))is not null
			drop table #rkd_sp
			if (select object_id(''tempdb..#jcd_sp0''))is not null
			drop table #jcd_sp0
			if (select object_id(''tempdb..#jcd_sp''))is not null
			drop table #jcd_sp
			if (select object_id(''tempdb..#ckd_sp0''))is not null
			drop table #ckd_sp0
			if (select object_id(''tempdb..#ckd_sp''))is not null
			drop table #ckd_sp
			if (select object_id(''tempdb..#fcd_sp0''))is not null
			drop table #fcd_sp0
			if (select object_id(''tempdb..#fcd_sp''))is not null
			drop table #fcd_sp
			if (select object_id(''tempdb..#syd_sp0''))is not null
			drop table #syd_sp0
			if (select object_id(''tempdb..#syd_sp''))is not null
			drop table #syd_sp
			if (select object_id(''tempdb..#lsd_sp0''))is not null
			drop table #lsd_sp0
			if (select object_id(''tempdb..#lsd_sp''))is not null
			drop table #lsd_sp
			if (select object_id(''tempdb..#temp_last''))is not null
			drop table #temp_last
			/*
			select  * from #temp_spxx order by spno
			select  * from #temp_spxx0 order by guizu,spno
			*/
			--查找需要管理库存的商品
			select spno,Mingcheng,Belong,guizu,guizuno
			into #temp_spxx0
			from spxx
			where isnull(selected,0)=1  
			--spno<-->belong
			update a set a.spno=b.spno
			from #temp_spxx0 a,#temp_spxx0 b
			where a.belong=b.spno
			select distinct guizuno,spno into #temp_spxx from #temp_spxx0 where guizuno in(select guizu from '+@guizu+')  

			/*
			select * from t_saleSheet_day order by cspno
			drop table #temp_sp_day
			select  * from #temp_sp_day
			*/
			--select a.guizuno,a.spno,b.dDate,b.fCostPrice,b.fQty_BeginWH,b.fQty_CurWH
			select a.guizuno,a.spno,dDate=isnull(b.dDate,''1899-01-01''),fCostPrice=isnull(b.fCostPrice,0),fQty_BeginWH=isnull(b.fQty_BeginWH,0),fQty_CurWH=isnull(b.fQty_CurWH,0)
			into #temp_sp_day
			from #temp_spxx a left join dbo.t_SaleSheet_Day b
			on a.spno=b.cSpNo
			order by a.guizuno,b.dDate

		

			--查找某种商品最近一次结算时间
			select a.guizuno,a.spno,max(b.dDate) MaxDate
			into #temp_CurWh0
			from #temp_spxx a left join #temp_sp_day b
			on a.spno=b.spno
			where b.dDate<='''+@SelectDate+'''
			group by a.guizuno,a.spno
			select a.guizuno,a.spno,a.MaxDate,shuliang=isnull(b.fQty_curWh,0),jinjiajine=isnull(isnull(b.fcostPrice,0)*isnull(b.fQty_curWh,0),0)
			into #temp_CurWh
			from #temp_CurWh0 a,#temp_sp_day b
			where a.spno=b.spno and a.MaxDate=b.dDate


		--rkd_sp  select * from rkd_sp

			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
			into #rkd_sp0 
			from dbo.rkd_sp a left join spxx b on a.spno=b.spno join #temp_CurWh c 
			on a.spno=c.spno and a.zdriqi>c.MaxDate and a.zdriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong
			update a set a.spno=b.spno from #rkd_sp0 a,spxx b where a.belong=b.spno     
			select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)) 
			into #temp_rkd_sp from #rkd_sp0 group by guizuno,spno

			--jcd_sp
			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
			into #jcd_sp0 
			from dbo.jcd_sp a left join spxx b on a.spno=b.spno join #temp_CurWh c
			on a.spno=c.spno and a.zdriqi>c.MaxDate and a.zdriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong 
			update a set a.spno=b.spno from #jcd_sp0 a,spxx b where a.belong=b.spno             
			select spno,guizuno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0))
			into #temp_jcd_sp from #jcd_sp0 group by guizuno,spno

			--ckd_sp  select * from ckd_sp
			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
			into #ckd_sp0 
			from dbo.ckd_sp a left join spxx b on a.spno=b.spno join #temp_CurWh c
			on a.spno=c.spno and a.zdriqi>c.MaxDate and a.zdriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong 
			update a set a.spno=b.spno from #ckd_sp0 a,spxx b where a.belong=b.spno 
			select spno,guizuno,shuliang=-sum(isnull(shuliang,0)),jinjiajine=-sum(isnull(jinjiajine,0)) 
			into #temp_ckd_sp from #ckd_sp0 group by guizuno,spno 


			--select * from fcd_sp
			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
			into #fcd_sp0 
			from dbo.fcd_sp a left join spxx b on a.spno=b.spno join #temp_CurWh c
			on a.spno=c.spno and a.zdriqi>c.MaxDate and a.zdriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong
			update a set a.spno=b.spno from #fcd_sp0 a,spxx b where a.belong=b.spno
			select spno,guizuno,shuliang=-sum(isnull(shuliang,0)),jinjiajine=-sum(isnull(jinjiajine,0))
			into #temp_fcd_sp 
			from #fcd_sp0 group by guizuno,spno 

			---select * from syd_sp
			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jinjiajine,0)) 
			into #syd_sp0 
			from dbo.syd_sp a left join spxx b on a.spno=b.spno join #temp_CurWh c
			on a.spno=c.spno and a.zdriqi>c.MaxDate and a.zdriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong
			update a set a.spno=b.spno from #syd_sp0 a,spxx b where a.belong=b.spno   
			select spno,guizuno,shuliang=-sum(isnull(shuliang,0)),jinjiajine=-sum(isnull(jinjiajine,0)) 
			into #temp_syd_sp from #syd_sp0 group by guizuno,spno

			---select * from lsdsp
			select a.spno,a.guizuno,b.belong,shuliang=sum(isnull(a.shuliang,0)),jinjiajine=sum(isnull(a.jine,0)) 
			into #lsd_sp0 
			from dbo.lsdsp a left join spxx b on a.spno=b.spno join #temp_CurWh c
			on a.spno=c.spno and a.Lsriqi>c.MaxDate and a.Lsriqi<='''+@SelectDate+'''
			group by a.spno,a.guizuno,b.belong 
			update a set a.spno=b.spno from #lsd_sp0 a,spxx b where a.belong=b.spno     
			select spno,guizuno,shuliang=-sum(isnull(shuliang,0)),jinjiajine=-sum(isnull(jinjiajine,0))
			into #temp_lsd_sp from #lsd_sp0 group by guizuno,spno



			--drop table #temp_modifySp
			--select * from #temp_modifySp
			select guizuno,spno,shuliang,jinjiajine
			into #temp_modifySp
      from #temp_CurWh
      union
      select guizuno,spno,shuliang,jinjiajine
			from #temp_rkd_sp
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_CurWh
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_jcd_sp
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_ckd_sp
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_fcd_sp
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_syd_sp
			union
			select guizuno,spno,shuliang,jinjiajine
			from #temp_lsd_sp

			/*
			--drop table #temp_modifyTotal
			select * from #temp_modifyTotal 
			*/
			select guizuno,spno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0))
			into #temp_modifyTotal
			from #temp_modifySp
			group by guizuno,spno

			select 
			case grouping(guizuno) when 0 then guizuno
							       when 1 then ''总计:''end as guizuno,
			case grouping(spno) when 0 then spno
							       when 1 then ''柜组商品合计:''end as spno,shuliang=sum(isnull(shuliang,0)),
			jinjiajine=sum(isnull(jinjiajine,0))
      into #temp_last  --drop table #temp_last
			from #temp_modifyTotal
			group by guizuno,spno with rollup


			select a.guizuno,a.spno,mingcheng=isnull(b.mingcheng,''--''),a.shuliang,a.jinjiajine
      from 	#temp_last a  left join spxx b
      on a.spno=b.spno 
      order by a.guizuno,a.spno

	')
      


end


GO
