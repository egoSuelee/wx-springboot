
CREATE procedure [dbo].[p_lsd_select]
  @likesheet varchar(32),
  @a money,
  @b money,
  @time1 datetime,
  @time2 datetime
as
begin

	if(select object_id('tempdb..#temp_p_lsd_select')) is not null
	begin
		drop table #temp_p_lsd_select
	end 
  select iLineNo=IDENTITY(int,1,1),a.LsdNo,a.shishou,a.guizu,a.guizuno,a.zdriqi,a.xsyno,a.xsy
  into #temp_p_lsd_select
  from(
  select LsdNo,shishou,guizu,guizuno,zdriqi,xsyno,xsy
  from lsd
  where  zdriqi between @time1 and @time2
  and shishou between @a and @b
  ) a
 where ((left(a.LsdNo,len(ltrim(rtrim(@likesheet))))=@likesheet)
         or (a.guizu=@likesheet) or (a.guizuno=@likesheet) or (a.xsyno=@likesheet)
         or (a.xsy=@likesheet) or (@likesheet=''))
 order by zdriqi,LsdNO
 
 select iLineNo,LsdNo,shishou,guizu,guizuno,zdriqi=dbo.getDayStr(zdriqi),xsyno,xsy
 from #temp_p_lsd_select
 union all
 select iLineNo=MAX(iLineNo)+1,LsdNo='总计:',shishou=SUM(shishou),guizu='共('+cast(COUNT(*) as varchar(32))+')笔交易',guizuno=null,
 zdriqi=dbo.getDayStr(@time1)+'至'+dbo.getDayStr(@time2),xsyno=null,xsy=null
 from #temp_p_lsd_select
 order by iLineNo,zdriqi,LsdNo
 
 
 

  
end

GO
