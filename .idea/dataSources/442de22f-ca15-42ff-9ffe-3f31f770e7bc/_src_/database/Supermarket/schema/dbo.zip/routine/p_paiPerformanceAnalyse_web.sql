/*
drop #tempPinpaino
select pinpaino
into #delp
from t_pinpai

p_paiPerformanceAnalyse_web '2010-05-01','2011-05-10','d8d21c08a448c63a'
select * from #delp

品牌绩效分析
*/
CREATE proc [dbo].[p_paiPerformanceAnalyse_web]
@date1 datetime,
@date2 datetime,
@qu varchar(64)--,
---@strserver varchar(32) '+@strserver+'.
as
begin
exec('
if (select object_id(''tempdb..#temp_Rkdsp''))is not null
drop table #temp_Rkdsp
if (select object_id(''tempdb..#temp_Lsdsp''))is not null
drop table #temp_Lsdsp
if (select object_id(''tempdb..#temp_Pinpaino''))is not null
drop table #temp_Pinpaino
if (select object_id(''tempdb..#temp_Fcdsp''))is not null
drop table #temp_Fcdsp
if (select object_id(''tempdb..#temp_RkNumber''))is not null
drop table #temp_RkNumber

--select F1 as pinpaino into #temp_Pinpaino  from dbo.splitstr(@qu,@)
                                                          ------服务器名
			select guizuno as pinpaino into #temp_Pinpaino  from Temp_SupKey.dbo.temp_TypeTree'+@qu+'
delete from #temp_pinpaino where pinpaino=''quno''
--select * into #temp_Pinpaino from @qu
--select * from #temp_pinpaino
--待统计的品牌商品入库情况
select pinpaino,InQty=sum(isnull(shuliang,0)),InMoney=sum(isnull(jinjiajine,0))
into #temp_Rkdsp
from v_rkdSp_PinpaiNo
where pinpaino in
(
	select pinpaino from #temp_Pinpaino
)
and zdriqi between '''+@date1+''' and '''+@date2+'''
group by pinpaino

--待统计的品牌商品返厂情况
select pinpaino,FcQty=sum(isnull(shuliang,0)),FcMoney=sum(isnull(jinjiajine,0))
into #temp_Fcdsp
from v_fcdSp_PinpaiNo  
where pinpaino in
(
	select pinpaino from #temp_Pinpaino
)
and zdriqi between '''+@date1+''' and '''+@date2+'''
group by pinpaino

--待统计的品牌商品零售情况
select pinpaino,LsQty=sum(isnull(shuliang,0)),LsMoney=sum(isnull(jine,0))
into #temp_Lsdsp
from v_lsdsp_pinpaiNo
where pinpaino in
(
	select pinpaino from #temp_Pinpaino
)
and lsriqi between '''+@date1+''' and '''+@date2+'''
group by pinpaino

--品牌进货次数
select pinpaino,rkNumber=count(distinct rkdno)
into #temp_RkNumber
from v_rkdSp_PinpaiNo
where zdriqi between '''+@date1+''' and '''+@date2+'''
group by pinpaino

select a.pinpaino as 品牌编号,b.pinpai as 品牌名称,费用=isnull(b.fee,0),
进货数量=isnull(c.InQty,0),进货金额=isnull(c.InMoney,0),
零售数量=isnull(d.LsQty,0),零售金额=isnull(d.LsMoney,0),
返厂数量=isnull(f.FcQty,0),返厂金额=isnull(f.FcMoney,0),
期间进货次数=isnull(n.rkNumber,0)
from #temp_Pinpaino a left join t_pinpai b
on a.pinpaino=b.pinpaino
left join #temp_Rkdsp c
on a.pinpaino=c.pinpaino
left join #temp_Lsdsp d
on a.pinpaino=d.pinpaino
left join #temp_Fcdsp f
on a.pinpaino=f.pinpaino
left join #temp_RkNumber n
on a.pinpaino=isnull(n.pinpaino,'''''''')
order by a.pinpaino
')
end
GO
