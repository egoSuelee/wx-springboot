/*
库存流水（一种商品只一条信息）无配送
*/
/*--drop table #tempDelphiTable
create table #tempDelphiTable(spno varchar(32))
insert into #tempDelphiTable(spno)
select spno from spxx where isnull(selected,0)=1 and guizuno='100' and pinpaino='10036'

select * from #temp
select * from #lsdsp

p_periodOfTimeStorage_cWh_chen '2009-05-29','2009-05-29','100','001'
*/
CREATE proc p_periodOfTimeStorage_cWh_chen
@dDate1 datetime,
@dDate2 datetime,
@guizuno varchar(32),
@cWhNo varchar(32)
as
  set nocount on
begin
	if (select object_id('tempdb..#tmpMaxpdSp0'))is not null
			drop table #tmpMaxpdSp0
	if (select object_id('tempdb..#tmpMaxpdSp'))is not null
			drop table #tmpMaxpdSp
	if (select object_id('tempdb..#jcdsp0'))is not null
			drop table #jcdsp0
	if (select object_id('tempdb..#rkdsp0'))is not null
			drop table #rkdsp0
	if (select object_id('tempdb..#ckdsp0'))is not null
			drop table #ckdsp0
	if (select object_id('tempdb..#fcdsp0'))is not null
			drop table #fcdsp0
	if (select object_id('tempdb..#sydsp0'))is not null
			drop table #sydsp0
	if (select object_id('tempdb..#lsdsp0'))is not null
			drop table #lsdsp0
	if (select object_id('tempdb..#jcdsp'))is not null
			drop table #jcdsp
	if (select object_id('tempdb..#rkdsp'))is not null
			drop table #rkdsp
	if (select object_id('tempdb..#ckdsp'))is not null
			drop table #ckdsp
	if (select object_id('tempdb..#fcdsp'))is not null
			drop table #fcdsp
	if (select object_id('tempdb..#sydsp'))is not null
			drop table #sydsp
	if (select object_id('tempdb..#lsdsp'))is not null
			drop table #lsdsp
	if (select object_id('tempdb..#tempTwoDateDetail'))is not null
			drop table #tempTwoDateDetail
	if (select object_id('tempdb..#temp_storage_manage'))is not null
			drop table #temp_storage_manage
	if (select object_id('tempdb..#temp_jcd_rkd_cjd0'))is not null
			drop table #temp_jcd_rkd_cjd0
	if (select object_id('tempdb..#temp_jcd_rkd_cjd'))is not null
			drop table #temp_jcd_rkd_cjd
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#temp_jcd_rkd_cjd0_sec'))is not null
			drop table #temp_jcd_rkd_cjd0_sec
	if (select object_id('tempdb..#temp_jcd_rkd_cjd_sec'))is not null
			drop table #temp_jcd_rkd_cjd_sec
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#tempSpLastDay'))is not null
			drop table #tempSpLastDay
	if (select object_id('tempdb..#tempSpLastDay_sec'))is not null
			drop table #tempSpLastDay_sec
	if (select object_id('tempdb..#tmpPdsp'))is not null
			drop table #tmpPdsp
	if (select object_id('tempdb..#tmpPdsp_sec'))is not null
			drop table #tmpPdsp_sec
  if (select object_id('tempdb..#tmpPinpaiDate'))is not null
			drop table #tmpPinpaiDate
  if (select object_id('tempdb..#tmpPinpaiDate0'))is not null
			drop table #tmpPinpaiDate0
  if (select object_id('tempdb..#tmpPinpaiDate0'))is not null
			drop table #tmpPinpaiDate0
  if (select object_id('tempdb..#tempCwh'))is not null
			drop table #tempCwh


  --pos对应的仓库号
  --declare @Posid varchar(32)
  select distinct posid,cangkuno 
  into #tempCwh
  from posstation
  where isnull(cangkuno,posid)=@cWhNo
	
	create table #tempTwoDateDetail
	(
		spno varchar(32),
	  dDate1 datetime,
	  dDate2 datetime,
	  salePrice numeric(18,4),
	  costPrice1 numeric(18,4),--期初成本
	  costPrice2 numeric(18,4),--期末成本
	  jcQty money,
	  jc_money numeric(18,4),
	  rkQty money,
	  rk_money numeric(18,4),
	  ckQty money,
	  ck_money numeric(18,4),
	  fcQty money,
	  fc_money numeric(18,4),
	  syQty money,
	  sy_money numeric(18,4),
	  lsQty money,
	  ls_money numeric(18,4),
    dbQty money,
    db_money numeric(18,4),
	  startQty money,
	  endQty money,
	  diffShuliang money,
	  costAll_begin  numeric(18,4),
	  costAll_end numeric(18,4),
	  saleAll_begin numeric(18,4),
	  saleAll_end numeric(18,4),
    cj_shuliang money,
    cj_jine numeric(18,4)
	)
	insert into #tempTwoDateDetail
	(spno,dDate1,dDate2)
	select spno,@dDate1,@dDate2
	from #tempDelphiTable
	--select * from #tempDelphiTablePinPai

  select a.spno,b.pinpaino
  into #tempDelphiTablePinPai
  from #tempDelphiTable a left join spxx b
  on a.spno=b.spno

--品牌盘点情况  --drop table #tmpPinpaiDate   
  select distinct b.pinpaino,a.zdriqi,a.pandian
  into #tmpPinpaiDate0
  from pdd_sp a left join spxx b
  on a.spno=b.spno
  where ( isnull(cangkuno,'')=@cWhNo and @cWhNo<>'' )
  --select * from #tmpPinpaiDate
	select pinpaino,zdriqi,pandian
  into #tmpPinpaiDate
  from #tmpPinpaiDate0
  where pinpaino in
 ( select distinct Pinpaino=isnull(pinpaino,'') from #tempDelphiTablePinPai)

  select pinpaino,MaxpdRiqi=isnull(max(zdriqi),'1899-01-01')
  into #tmpPinpaiMaxriqi  --drop table #tempSpPdDate
  from #tmpPinpaiDate
  where pandian=0 and pandian is not null
  group by pinpaino

  --select * from #tmpPdLastDate order by pinpaino
  select pinpaino,MaxPdRiqi,PdDate=MaxPdRiqi
  into #tmpPdLastDate
  from #tmpPinpaiMaxriqi 
  where MaxPdRiqi<=(@dDate1-1)
  union all
  select a.pinpaino,a.MaxPdRiqi,PdDate=isnull(
                                   (
                                    select max(b.zdriqi) from #tmpPinpaiDate b
                                    where b.zdriqi<@dDate1 and a.pinpaino=b.pinpaino
                                   ),'1899-01-01')
  from #tmpPinpaiMaxriqi a
  where a.MaxPdRiqi>(@dDate1-1)

  select distinct a.spno,a.pinpaino,PdDate=isnull(PdDate,'1899-01-01')
  into #tempSpPdDate
  from #tempDelphiTablePinPai a left join #tmpPdLastDate b
  on a.pinpaino=b.pinpaino

--时间段开始日期的最近盘点日期
/*
	declare @MinPdDate datetime
	select  @MinPdDate=max(zdriqi) from pdd_sp
	where spno in (select spno from #tempDelphiTable)
  and pandian=0 and pandian is not null and zdriqi<=@dDate1-1 

	if @MinPdDate is null set @MinPdDate='1899-01-01'
  if @MinPdDate>=@dDate1-1
  begin
    select  @MinPdDate=max(zdriqi) from pdd_sp
	  where spno in (select spno from #tempDelphiTable)
    and zdriqi<=@dDate1-1  
  end
  if @MinPdDate is null set @MinPdDate='1899-01-01'
*/
	
	--期间销售情况
	--select * from #jcdsp
	  select spno,zdriqi,shuliang,jine=jinjiajine
		into #jcdsp0
		from jcd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=jcd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'') 
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #jcdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #jcdsp
	  from #jcdsp0
	  group by spno,zdriqi
	
	--select * from #rkdsp    
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #rkdsp0
		from rkd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=rkd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #rkdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #rkdsp
	  from #rkdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #ckdsp0
		from ckd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=ckd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #ckdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #ckdsp
	  from #ckdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #fcdsp0
		from fcd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=fcd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and  (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #fcdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #fcdsp
	  from #fcdsp0
	  group by spno,zdriqi
	
		select spno,zdriqi,shuliang,jine=jinjiajine
	  into #sydsp0
		from syd_sp
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=syd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #sydsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #sydsp
	  from #sydsp0
	  group by spno,zdriqi
	
		select spno,zdriqi=lsriqi,shuliang,jine=jine
	  into #lsdsp0
		from lsdsp 
		where lsriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=lsdsp.spno
                           ) and @dDate2
    --where lsriqi<=@dDate2
    and  (isnull(cangkuno,@cWhNo)=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #lsdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #lsdsp
	  from #lsdsp0
	  group by spno,zdriqi
    
  --cjd  select * from cjd_sp
    select spno,zdriqi,shuliang,jine=chajiajine
	  into #cjdsp0
		from cjd_sp 
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=cjd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and (isnull(cWhNo,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #cjdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #cjdsp
	  from #cjdsp0
	  group by spno,zdriqi
   --select * from #lsdsp0
--dbd

    select spno,zdriqi,shuliang,jine=jinjiajine
	  into #dbdsp0
		from dbd_sp 
		where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where  x.spno=dbd_sp.spno
                           ) and @dDate2
    --where zdriqi<=@dDate2
    and  (isnull(cangkuno,'')=@cWhNo and @cWhNo<>'')
	  and isnull(guizuno,0)=@guizuno and spno in(select spno from #tempDelphiTable )
	  update a
		set a.spno=b.belong
		from #dbdsp0 a,spxx b 
		where  a.spno=b.spno and isnull(b.belong,'')<>''
	  select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0))
	  into #dbdsp
	  from #dbdsp0
	  group by spno,zdriqi

	update a
	set a.jcQty=isnull(b.shuliang,0),a.jc_money=isnull(b.jine,0),
	    a.rkQty=isnull(c.shuliang,0),a.rk_money=isnull(c.jine,0),
	    a.ckQty=isnull(d.shuliang,0),a.ck_money=isnull(d.jine,0),
	    a.fcQty=isnull(e.shuliang,0),a.fc_money=isnull(e.jine,0),
	    a.syQty=isnull(f.shuliang,0),a.sy_money=isnull(f.jine,0),
	    a.lsQty=isnull(g.shuliang,0),a.ls_money=isnull(g.jine,0),
      a.dbQty=isnull(db.shuliang,0),a.db_money=isnull(db.jine,0),
      a.cj_shuliang=isnull(cj.shuliang,0),a.cj_jine=isnull(cj.jine,0)
	from #tempTwoDateDetail a 
	left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #jcdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 )b on a.spno=b.spno 
	left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #rkdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 )c on a.spno=c.spno
	left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #ckdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 )d on a.spno=d.spno
	left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #fcdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 )e on a.spno=e.spno
	left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #sydsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 )f on a.spno=f.spno
	left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #lsdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 ) g on a.spno=g.spno
  left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #dbdSp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 ) db on a.spno=db.spno
  left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #cjdsp
			where zdriqi between @dDate1 and @dDate2 
		  group by spno
		 ) cj on a.spno=cj.spno
	
	--select * from #temp_storage_manage
	select spno,belong
	into #temp_storage_manage    
	from spxx
	where isnull(selected,0)=1 and guizuno=@guizuno and spno in(select spno from #tempDelphiTable)
	--更新期初成本
	--select * from #tempSpLastDay
	select a.spno,dDate=isnull(max(b.dDate),'1899-01-01')
	into #tempSpLastDay
	from #tempTwoDateDetail a,t_SaleSheet_Day b
	where a.spno=b.cspno and b.dDate<@dDate1
	group by a.spno
	
	update a
	set a.costPrice1=b.fCostPrice 
	from #tempTwoDateDetail a, 
	(
		select cSpno,fCostPrice=avg(isnull(fCostPrice,0))
		from t_SaleSheet_Day 
		where dDate =(select c.dDate from #tempSpLastDay c where cSpno=c.spno)
		group by cspno
	)b
	where a.spno=b.cSpno
	--select * from #temp_jcd_rkd_cjd0
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jine,0)
	into #temp_jcd_rkd_cjd0   
	from #temp_storage_manage a ,#jcdsp  b
	where  a.spno=b.spno and b.zdriqi<=@dDate1
	union all
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jine,0)
	from #temp_storage_manage a , #rkdsp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1
	union all
	select a.spno,a.belong,shuliang=0,jinjiajine=-isnull(b.jine,0)
	from #temp_storage_manage a , #cjdsp  b
	where a.spno=b.spno and b.zdriqi<=@dDate1
	
	update #temp_jcd_rkd_cjd0
	set spno=belong where isnull(belong,'')<>''
	--select * from #temp_jcd_rkd_cjd
	select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
	into #temp_jcd_rkd_cjd
	from #temp_jcd_rkd_cjd0
	group by spno 
	
	
	update a
	set a.costPrice1=case when isnull(shuliang,0)<>0 then isnull(jine,0)/isnull(shuliang,0)
	                 else null end
	from #tempTwoDateDetail a,#temp_jcd_rkd_cjd b
	where a.spno=b.spno and a.costprice1 is null
	
	--开业第一天
	update a
	set a.costPrice1=b.BzJj
	from #tempTwoDateDetail a left join spxx b
	on a.spno=b.spno 
	where  isnull(a.costPrice1,0)=0
	---========================================================================================
	--更新期末成本
	--select * from #tempSpLastDay
	select a.spno,dDate=isnull(max(b.dDate),'1899-01-01')
	into #tempSpLastDay_sec
	from #tempTwoDateDetail a,t_SaleSheet_Day b
	where a.spno=b.cspno and b.dDate<=@dDate2
	group by a.spno
	
	update a
	set a.costPrice2=b.fCostPrice 
	from #tempTwoDateDetail a, 
	(
		select cSpno,fCostPrice=avg(isnull(fCostPrice,0))
		from t_SaleSheet_Day 
		where dDate =(select c.dDate from #tempSpLastDay_sec c where cSpno=c.spno)
		group by cspno
	)b
	where a.spno=b.cSpno
	--select * from #temp_jcd_rkd_cjd0
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jine,0)
	into #temp_jcd_rkd_cjd0_sec   
	from #temp_storage_manage a ,#jcdsp  b
	where  a.spno=b.spno and b.zdriqi between @dDate1 and @dDate2
	union all
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jine,0)
	from #temp_storage_manage a , #rkdsp  b
	where a.spno=b.spno and b.zdriqi between @dDate1 and @dDate2
	union all
	select a.spno,a.belong,shuliang=0,jinjiajine=-isnull(b.jine,0)
	from #temp_storage_manage a , #cjdsp  b
	where a.spno=b.spno and b.zdriqi between @dDate1 and @dDate2
	
	update #temp_jcd_rkd_cjd0_sec
	set spno=belong where isnull(belong,'')<>''
	--select * from #temp_jcd_rkd_cjd
	select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
	into #temp_jcd_rkd_cjd_sec
	from #temp_jcd_rkd_cjd0_sec
	group by spno 
	
	update a
	set a.costPrice2=case when isnull(shuliang,0)<>0 then isnull(jine,0)/isnull(shuliang,0)
	                 else null end
	from #tempTwoDateDetail a,#temp_jcd_rkd_cjd_sec b
	where a.spno=b.spno and a.costprice2 is null
	
	--开业第一天
	update a
	set a.costPrice2=b.BzJj
	from #tempTwoDateDetail a left join spxx b
	on a.spno=b.spno 
	where  isnull(a.costPrice2,0)=0 
--***********************************************************************************

 
	--期初库存
/*
	declare @MaxpdDate1 datetime
	select  @MaxpdDate1=max(zdriqi) from pdd_sp
	where spno in (select spno from #tempDelphiTable)
  and pandian=0 and pandian is not null --	and zdriqi<@dDate1 

	if @MaxpdDate1 is null set @MaxpdDate1='1899-01-01'
  if @MaxpdDate1>=@dDate1-1
  begin
    select  @MaxpdDate1=max(zdriqi) from pdd_sp
	  where spno in (select spno from #tempDelphiTable)
    and zdriqi<=@dDate1-1  
  end
  if @MaxpdDate1 is null set @MaxpdDate1='1899-01-01'
--select @MaxpdDate1

  */
	
	select a.spno,shuliang=isnull(sum(isnull(shuliang,0)),0)
	into #tmpPdsp 
	from #tempDelphiTable a left join pdd_sp b
	on a.spno=b.spno and b.zdriqi=(select top 1 p.pddate from #tempSpPdDate p where p.spno=b.spno)
  and ( (cangkuno=@cWhNo and @cWhNo<>'') or (@cWhNo='') )
  
	group by a.spno 
	--select * from #tmpPdsp
  update a
  set a.startQty=b.shuliang
  from #tempTwoDateDetail a,#tmpPdsp b
  where a.spno=b.spno
  and a.spno in(select spno from #tempSpPdDate where PdDate=(@dDate1-1))

	--if (@MaxpdDate1<(@dDate1-1))
	--begin
	  update a
	  set a.startQty=isnull(p.shuliang,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)
	      -isnull(d.shuliang,0)-isnull(e.shuliang,0)-isnull(f.shuliang,0)-isnull(g.shuliang,0)
        -isnull(db.shuliang,0)
	  from #tempTwoDateDetail a 
	  left join #tmpPdsp p on a.spno=p.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #jcdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#jcdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )b on a.spno=b.spno 
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #rkdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#rkdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )c on a.spno=c.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #ckdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#ckdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )d on a.spno=d.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #fcdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#fcdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 )e on a.spno=e.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #sydsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#sydsp.spno
                           )+1 and  @dDate1-1 
		  group by spno
		 )f on a.spno=f.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #lsdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#lsdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 ) g on a.spno=g.spno
    left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #dbdsp
			--where zdriqi between pd.PdDate+1 and @dDate1-1 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate  x 
                            where x.PdDate<(@dDate1-1) and x.spno=#dbdsp.spno
                           )+1 and  @dDate1-1
		  group by spno
		 ) db on a.spno=db.spno
	  where  a.spno in(select spno from #tempSpPdDate where PdDate<(@dDate1-1))
	--end
--***********************************************************************************
--品牌盘点情况  --drop table #tmpPinpaiDate   
  --select * from #tmpPinpaiDate
  --select * from #tmpPdLastDate order by pinpaino
  select pinpaino,MaxPdRiqi,PdDate=MaxPdRiqi
  into #tmpPdLastDate_sec
  from #tmpPinpaiMaxriqi 
  where MaxPdRiqi<=@dDate2
  union all
  select a.pinpaino,a.MaxPdRiqi,PdDate=isnull(
                                   (
                                    select max(b.zdriqi) from #tmpPinpaiDate b
                                    where b.zdriqi<=@dDate2 and a.pinpaino=b.pinpaino
                                   ),'1899-01-01')
  from #tmpPinpaiMaxriqi a
  where a.MaxPdRiqi>@dDate2

  select distinct a.spno,a.pinpaino,PdDate=isnull(PdDate,'1899-01-01')
  into #tempSpPdDate_sec
  from #tempDelphiTablePinPai a left join #tmpPdLastDate_sec b
  on a.pinpaino=b.pinpaino
 
	--期末库存
/*
	declare @MaxpdDate2 datetime
	select  @MaxpdDate2=max(zdriqi) from pdd_sp
	where spno in (select spno from #tempDelphiTable)
	and pandian=0 and pandian is not null--and zdriqi<=@dDate2 
	if @MaxpdDate2 is null set @MaxpdDate2='1899-01-01'
  if @MaxpdDate2>=@dDate2
  begin
    select  @MaxpdDate2=max(zdriqi) from pdd_sp
	  where spno in (select spno from #tempDelphiTable)
    and zdriqi<=@dDate2  
  end 
  if @MaxpdDate2 is null set @MaxpdDate2='1899-01-01'
*/
	--select * from #tmpPdsp_sec
	select a.spno,shuliang=isnull(sum(isnull(shuliang,0)),0),shoujia=isnull(avg(isnull(shoujia,0)),0)
	into #tmpPdsp_sec 
	from #tempDelphiTable a left join pdd_sp b
	on a.spno=b.spno and b.zdriqi=(select top 1 p.pddate from #tempSpPdDate_sec p where p.spno=b.spno)
  and ( (cangkuno=@cWhNo and @cWhNo<>'') or (@cWhNo='') ) 
	group by a.spno 
	
  update a
  set a.endQty=b.shuliang
  from #tempTwoDateDetail a,#tmpPdsp_sec b
  where a.spno=b.spno
  and a.spno in(select spno from #tempSpPdDate_sec where PdDate=@dDate2)

	  update a
	  set a.endQty=isnull(p.shuliang,0)+isnull(b.shuliang,0)+isnull(c.shuliang,0)
	      -isnull(d.shuliang,0)-isnull(e.shuliang,0)-isnull(f.shuliang,0)-isnull(g.shuliang,0)
        -isnull(db.shuliang,0)
	  from #tempTwoDateDetail a
	  left join #tmpPdsp_sec p on a.spno=p.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #jcdsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#jcdsp.spno
                           )+1 and  @dDate2 
		  group by spno
		 )b on a.spno=b.spno 
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #rkdsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#rkdsp.spno
                           )+1 and  @dDate2  
		  group by spno
		 )c on a.spno=c.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #ckdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#ckdsp.spno
                           )+1 and  @dDate2 
		  group by spno
		 )d on a.spno=d.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #fcdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#fcdsp.spno
                           )+1 and  @dDate2 
		  group by spno
		 )e on a.spno=e.spno
		left join  
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #sydsp
			--where zdriqi between pd.PdDate+1 and @dDate2
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#sydsp.spno
                           )+1 and  @dDate2  
		  group by spno
		 )f on a.spno=f.spno
		left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #lsdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#lsdsp.spno
                           )+1 and  @dDate2 
		  group by spno
		 ) g on a.spno=g.spno
    left join 
		(
			select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)) 
			from #dbdsp
			--where zdriqi between pd.PdDate+1 and @dDate2 
      where zdriqi between (select top 1 x.PdDate from #tempSpPdDate_sec  x 
                            where x.PdDate<@dDate2 and x.spno=#dbdsp.spno
                           )+1 and  @dDate2 
		  group by spno
		 ) db on a.spno=db.spno
	  where  a.spno in(select spno from #tempSpPdDate_sec where PdDate<@dDate2)

	
	
	--select * from #tempTwoDateDetail where isnull(startqty,0)<>0
	--select sum(jcQty)+sum(rkQty)-sum(fcQty)-sum(ckQty)-sum(syQty)-sum(lsQty) from #tempTwoDateDetail
	--select sum(diffshuliang)from #tempTwoDateDetail
	
	update a
	set a.costprice1=b.bzjj
	from #tempTwoDateDetail a,spxx b
	where a.spno=b.spno and isnull(a.costprice1,0)=0
	update a
	set a.costprice2=b.bzjj
	from #tempTwoDateDetail a,spxx b
	where a.spno=b.spno and isnull(a.costprice2,0)=0

  
  update a
  set a.saleprice=b.shoujia
  from #tempTwoDateDetail a,#tmpPdsp_sec b
  where a.spno=b.spno 
  
  update a
  set a.saleprice=b.bzlsj
  from #tempTwoDateDetail a,spxx b
  where a.spno=b.spno 

	update a
	set a.saleprice=b.bzlsj
	from #tempTwoDateDetail a,spxx b
	where a.spno=b.spno
	and isnull(a.saleprice,0)=0

 update #tempTwoDateDetail
 set saleprice=abs(saleprice)
	
	
	update #tempTwoDateDetail
	set diffShuliang=isnull(endQty,0)-(isnull(startQty,0)+isnull(rkQty,0)+isnull(jcQty,0)-isnull(fcQty,0)
	                -isnull(ckQty,0)-isnull(syQty,0)-isnull(lsQty,0)-isnull(dbQty,0)),
	costAll_begin=isnull(startQty,0)*isnull(costPrice1,0),costAll_end=isnull(endQty,0)*isnull(costPrice2,0),
	saleAll_begin=isnull(startQty,0)*isnull(saleprice,0),saleAll_end=isnull(endQty,0)*isnull(saleprice,0)
	
	select a.spno,b.mingcheng,a.saleprice,huoNo=b.dw1,b.danwei,b.guige,zdriqi1=a.dDate1,zdriqi=a.dDate2,
	costPriceold=a.costPrice1,costPrice=a.costPrice2,jc_shuliang=a.jcQty,jc_jinea=a.jc_money,
	rk_shuliang=a.rkQty,rk_jine=a.rk_money,ck_shuliang=a.ckQty,ck_jine=a.ck_money,fc_shuliang=a.fcQty,
	fc_jine=a.fc_money,sy_shuliang=a.syQty,sy_jine=a.sy_money,Ls_shuliang=a.lsQty,Ls_jine=a.ls_money,
  dbQty,db_money,cj_shuliang,cj_jine,
	storageShuliang_begin=a.startQty,storageShuliang_end=a.endQty,shuliang=a.diffShuliang,
	costAll_begin,costAll_end,saleAll_begin,saleAll_end
	from #tempTwoDateDetail a left join spxx b
	on a.spno=b.spno
	union all  
	select '合计：','--',saleprice=null,huoNo=null,danwei=null,guige=null,dDate1=@dDate1,dDate2=@dDate2,costPrice1=null,
	costPrice2=null,sum(isnull(jcQty,0)),sum(isnull(jc_money,0)),sum(isnull(rkQty,0)),sum(isnull(rk_money,0)),
	sum(isnull(ckQty,0)),sum(isnull(ck_money,0)),sum(isnull(fcQty,0)),sum(isnull(fc_money,0)),
	sum(isnull(syQty,0)),sum(isnull(sy_money,0)),sum(isnull(lsQty,0)),sum(isnull(ls_money,0)),
  sum(isnull(dbQty,0)),sum(isnull(db_money,0)),sum(isnull(cj_shuliang,0)),sum(isnull(cj_jine,0)),
	sum(isnull(startQty,0)),sum(isnull(endQty,0)),sum(isnull(diffShuliang,0)),
	sum(isnull(costAll_begin,0)),sum(isnull(costAll_end,0)),sum(isnull(saleAll_begin,0)),sum(isnull(saleAll_end,0))
	from #tempTwoDateDetail
	
	order by a.spno



end


GO
