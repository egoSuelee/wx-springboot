create procedure p_qryUserModule
@userno varchar(32)
as
begin
  select a.name,a.[user],a.userType,b.ModuleName
  from Pass a
  left join t_Module_userType b
  on a.userType=b.userType
  where a.[user]=@userno


end
GO
