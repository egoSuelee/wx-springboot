/*
--drop table #temp
create table #temp(spno varchar(32))
insert into #temp(spno)
select spno from spxx where isnull(selected,0)=1 and guizuno='100' and pinpaino='10036'

select * from #temp
库存流水（小数点后四位）
参数（柜组号，柜组商品，1：加权成本0：平均成本，开始时间，结束时间）
exec p_storage_DetailByTwoDecimal_cWh_chen '100','#temp',1,'2009-05-29','2009-05-29','001'
*/


create proc p_storage_DetailByTwoDecimal_cWh_type_chen
@guizuno varchar(32),
@GoodsTable varchar(32),
@cost int=1,
@Date_begin datetime,
@Date_end datetime,
@cWhNo varchar(32)
as
    set nocount on 
exec('
	if (select object_id(''tempdb..#temp_Goods_Sale0''))is not null
		drop table #temp_Goods_Sale0
	if (select object_id(''tempdb..#temp_Goods_Sale''))is not null
		drop table #temp_Goods_Sale
	if (select object_id(''tempdb..#temp_Goods_Detail0''))is not null
		drop table #temp_Goods_Detail0
	if (select object_id(''tempdb..#temp_Goods_saleMaxDate''))is not null
		drop table #temp_Goods_saleMaxDate
	if (select object_id(''tempdb..#temp_Goods_salePrice''))is not null
		drop table #temp_Goods_salePrice
	if (select object_id(''tempdb..#temp_Goods_saleMaxPrice''))is not null
		drop table #temp_Goods_saleMaxPrice
	if (select object_id(''tempdb..#temp_storage_end''))is not null
		drop table #temp_storage_end
	if (select object_id(''tempdb..#temp_storage_modify''))is not null
		drop table #temp_storage_modify
	if (select object_id(''tempdb..#temp_last_storage_end''))is not null
		drop table #temp_last_storage_end
	if (select object_id(''tempdb..#temp_last0''))is not null
		drop table #temp_last0
	if (select object_id(''tempdb..#temp_0''))is not null
		drop table #temp_0
	if (select object_id(''tempdb..#temp_1''))is not null
		drop table #temp_1
	if (select object_id(''tempdb..#temp_hj''))is not null
		drop table #temp_hj
	if (select object_id(''tempdb..#temp_hj0''))is not null
		drop table #temp_hj0
	if (select object_id(''tempdb..#temp_3''))is not null
		drop table #temp_3
	if (select object_id(''tempdb..#temp_costPrice''))is not null
		drop table #temp_costPrice
	if (select object_id(''tempdb..#temp_storage_manage''))is not null
		drop table #temp_storage_manage
	if (select object_id(''tempdb..#temp_jcd_rkd_fcd0''))is not null
		drop table #temp_jcd_rkd_fcd0
	if (select object_id(''tempdb..#temp_jcd_rkd_fcd''))is not null
		drop table #temp_jcd_rkd_fcd
	if (select object_id(''tempdb..#temp_maxDate_jcd0''))is not null
		drop table #temp_maxDate_jcd0
	if (select object_id(''tempdb..#temp_last_lsd''))is not null
		drop table #temp_last_lsd
	if (select object_id(''tempdb..#temp_last_lsd0''))is not null
		drop table #temp_last_lsd0
	if (select object_id(''tempdb..#temp_jcd_rkd_fcd0_avg''))is not null
		drop table #temp_jcd_rkd_fcd0_avg
	if (select object_id(''tempdb..#temp_jcd_rkd_fcd_avg''))is not null
		drop table #temp_jcd_rkd_fcd_avg
	if (select object_id(''tempdb..#temp_4''))is not null
		drop table #temp_4
	if (select object_id(''tempdb..#temp_5''))is not null
		drop table #temp_5
	if (select object_id(''tempdb..#temp_Goods_Detail0_last''))is not null
		drop table #temp_Goods_Detail0_last
if (select object_id(''tempdb..#temp_Goods_pdd0''))is not null
		drop table #temp_Goods_pdd0
if (select object_id(''tempdb..#temp_Goods_pdd''))is not null
		drop table #temp_Goods_pdd
if (select object_id(''tempdb..#tempSpPdDate''))is not null
		drop table #tempSpPdDate
if (select object_id(''tempdb..#tempSpPd''))is not null
		drop table #tempSpPd
if (select object_id(''tempdb..#temp_Goods_Detail0_last0''))is not null
		drop table #temp_Goods_Detail0_last0
if (select object_id(''tempdb..#temp_lastDate''))is not null
		drop table #temp_lastDate
if (select object_id(''tempdb..#tempNullDate''))is not null
		drop table #tempNullDate
if (select object_id(''tempdb..#temp_hjDay''))is not null
		drop table #temp_hjDay
--关联盘点报告和盘点日期
------------////////////////////////////////////////////

  select a.spno,b.pinpaino
  into #tempDelphiTablePinPai
  from '+@GoodsTable+' a left join spxx b
  on a.spno=b.spno

  select distinct b.pinpaino,a.zdriqi,a.pandian
  into #tmpPinpaiDate0
  from pdd_sp a left join spxx b
  on a.spno=b.spno
  where (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')
  --select * from #tmpPinpaiDate
	select pinpaino,zdriqi,pandian
  into #tmpPinpaiDate
  from #tmpPinpaiDate0
  where pinpaino in
 ( select distinct Pinpaino=isnull(pinpaino,'''') from #tempDelphiTablePinPai)

  select pinpaino,MaxpdRiqi=isnull(max(zdriqi),''1899-01-01'')
  into #tmpPinpaiMaxriqi  --drop table #tempSpPdDate
  from #tmpPinpaiDate
  where pandian=0 and pandian is not null
  group by pinpaino

  --select * from #tmpPdLastDate order by pinpaino
  select b.pinpaino,a.MaxPdRiqi,PdDate=b.zdriqi
  into #tmpPdLastDate
  from #tmpPinpaiMaxriqi a,#tmpPinpaiDate b
  where a.pinpaino=b.pinpaino and MaxPdRiqi<='''+ @Date_end+''' and b.zdriqi<=MaxPdRiqi
  union all
  select a.pinpaino,a.MaxPdRiqi,PdDate=isnull(
                                   (
                                    select b.zdriqi from #tmpPinpaiDate b
                                    where b.zdriqi<='''+ @Date_end+''' and a.pinpaino=b.pinpaino
                                   ),''1899-01-01'')
  from #tmpPinpaiMaxriqi a
  where a.MaxPdRiqi>'''+ @Date_end+'''

  select distinct a.spno,d.type,a.pinpaino,zdriqi=isnull(PdDate,''1899-01-01'')
  into #tempSpPdDate
  from #tempDelphiTablePinPai a left join #tmpPdLastDate b
  on a.pinpaino=b.pinpaino
  left join spxx c
  on a.spno=c.spno
  left join guizu_type d
  on c.guizuno=d.guizuno
	
---------------------------------------------------------

select a.spno,a.type,a.zdriqi,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0),shoujia=isnull(b.shoujia,0)
into #tempSpPd
from #tempSpPdDate a left join 
(
select spno,type,zdriqi,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0)),
shoujia=avg(isnull(shoujia,0))
from pdd_sp
where guizuno='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' ) 
and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')
group by spno,type,zdriqi
)b
on a.spno=b.spno and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
where a.spno in(select spno from '+@GoodsTable+')

------------/////////////////////////////////////////////

--合并 发生库存变化，盘点的日期
	--select * from #temp_Goods_Sale0 order by id    drop table #temp_Goods_Sale0
	select spno,type,zdriqi,shuliang,id=0,jine=jinjiajine
	into #temp_Goods_Sale0
	from #tempSpPd

	union all
	select spno,type,zdriqi,shuliang,id=1,jine=jinjiajine
	from jcd_sp
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')
	        
	union all
	select spno,type,zdriqi,shuliang,id=2,jine=jinjiajine
	from rkd_sp
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')

	union all
	select spno,type,zdriqi,shuliang,id=3,jine=jinjiajine
	from ckd_sp
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')

	union all
	select spno,type,zdriqi,shuliang,id=4,jine=jinjiajine
	from fcd_sp
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')

	union all
	select spno,type,zdriqi,shuliang,id=5,jine=jinjiajine
	from syd_sp
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')

	union all
	select spno,type,zdriqi=lsriqi,shuliang,id=6,jine=jine
	from lsdsp 
	where lsriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''+@cWhNo+''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')
--cjd_sp  
  union all
	select spno,type,zdriqi,shuliang,id=9,jine=chajiajine
	from cjd_sp 
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cWhNo,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')
--dbd
  union all
	select spno,type,zdriqi,shuliang,id=10,jine=jinjiajine
	from dbd_sp 
	where zdriqi<='''+ @Date_end+''' and isnull(guizuno,0)='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
  and (isnull(cangkuno,'''')='''+@cWhNo+''' and '''+@cWhNo+'''<>'''')

 
 union all
 select a.spno,c.type,zdriqi='''+@Date_begin +''',shuliang=0,id=55,jine=0
 from '+@GoodsTable+' a left join spxx b
 on a.spno=b.spno
 left join guizu_type c
 on b.guizuno=c.guizuno

 union all
 select a.spno,c.type,zdriqi='''+@Date_end +''',shuliang=0,id=55,jine=0
 from '+@GoodsTable+' a left join spxx b
 on a.spno=b.spno
 left join guizu_type c
 on b.guizuno=c.guizuno


--关联spno  belong
	update a
	set a.spno=b.belong
	from #temp_Goods_Sale0 a left join spxx b 
	on a.spno=b.spno
  where isnull(b.belong,'''')<>''''

	--drop table #temp_Goods_Sale
	select spno,type,zdriqi,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jine,0)),id
	into #temp_Goods_Sale
	from #temp_Goods_Sale0
	group by spno,type,zdriqi,id


	--drop table #temp_Goods_Detail0
	create table #temp_Goods_Detail0
	(
		spno varchar(32),
    type varchar(32),
		mingcheng varchar(100),
		huoNO varchar(32),
		danwei varchar(10),
		guiGe varchar(32),
		--guizuno varchar(32),
		hj varchar(10),
		zdriqi datetime,
		salePrice numeric(18,2),
		costPriceOld numeric(18,2),--期初成本
    costPrice numeric(18,2),--当天成本
		storageShuliang_begin money,
		costAll_begin  numeric(18,2),  --起初库存成本总金额
		saleAll_begin numeric(18,2),--起初库存销售总金额
		storageShuliang_end money,
		costAll_end  numeric(18,2),
		saleAll_end numeric(18,2),
		pandian bit default(0),
		pd_shuliang money default(0),
		pd_jine numeric(18,2),
		pd_loseShuliang money default(0),
		pd_loseCostAll numeric(18,2),--盘点差异成本总金额  
		pd_loseSaleAll numeric(18,2),--盘点差异销售总金额 
		jc_shuliang money default(0),
		jc_jine numeric(18,2),
		rk_shuliang money default(0),
		rk_jine numeric(18,2),
		ck_shuliang money default(0),
		ckCostAll numeric(18,2),--出库成本总金额
		ck_jine numeric(18,2), --出库销售总金额
		fc_shuliang money default(0),
		fc_jine numeric(18,2), 
		sy_shuliang money default(0),
		syCostAll numeric(18,2),--损益成本总金额
		sy_jine numeric(18,2),--损益销售总金额
		Ls_shuliang money default(0),
		LsCostAll numeric(18,2),
		Ls_jine numeric(18,2),
    dbQty money,--调拨数量
    db_money numeric(18,2), --调拨金额
    cj_shuliang money default(0),--差价数量
    cj_jine numeric(18,2) ,
    spnoTmp varchar(32),
    iserno int     
		
	)


--select * from #temp_Goods_Detail0  where pandian=1 and pd_LoseShuliang>0
--更新表数据
  insert into #temp_Goods_Detail0
  (spno,type,zdriqi)
	select distinct spno,type,zdriqi
	from  #temp_Goods_Sale0
	--pdd_sp
	update a
	set a.pandian=1,a.pd_shuliang=b.shuliang,a.pd_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=0 
	--jcd_sp
	update a
	set a.jc_shuliang=b.shuliang,a.jc_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=1 
	--rkd_sp
	update a
	set a.rk_shuliang=b.shuliang,a.rk_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=2 
	--ckd_sp
	update a
	set a.ck_shuliang=b.shuliang,a.ck_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=3
	--fcd_sp
	update a
	set a.fc_shuliang=b.shuliang,a.fc_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=4
	--syd_sp
	update a
	set a.sy_shuliang=b.shuliang,a.sy_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=5
	--lsdsp
	update a
	set a.Ls_shuliang=b.shuliang,a.Ls_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=6

--cjd_sp
  update a
	set a.cj_shuliang=b.shuliang,a.cj_jine=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
  where isnull(b.id,99)=9
--dbdsp
	update a
	set a.dbQty=b.shuliang,a.db_money=b.jine
	from #temp_Goods_Detail0 a left join #temp_Goods_Sale b
	on a.spno=b.spno  and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	where isnull(b.id,99)=10

  update a
	set a.cj_shuliang=0
  from #temp_Goods_Detail0 a
  where cj_shuliang is null

  update a
	set a.cj_jine=0
  from #temp_Goods_Detail0 a
  where cj_jine is null

--select * from #temp_Goods_Detail0  
--drop table #temp_Goods_saleMaxDate
--更新costprice

	select spno,belong
    into #temp_storage_manage    --drop table #temp_storage_manage
    from spxx
    where isnull(selected,0)=1 and guizuno='''+@guizuno+''' and spno in(select spno from '+@GoodsTable+' )
--=========================================================================================================
--加权成本价格
if '''+@cost+'''=1
begin
	select a.zdriqi,a.spno,a.zdriqi_lastDaily
  into #temp_Goods_saleMaxDate
  from 
      (
				select a.zdriqi,a.spno,
					zdriqi_lastDaily=
							(
							select max(b.dDate) from t_SaleSheet_Day b 
							where b.dDate<=isnull(a.zdriqi,''1899-01-01'') and b.cspno=a.spno
							)
				from #temp_Goods_Detail0 a
       )a
   where a.zdriqi_lastDaily is not null

	--drop table #temp_Goods_saleMaxPrice
	select a.spno,a.zdriqi,a.zdriqi_lastDaily,b.fCostPrice
	into #temp_Goods_saleMaxPrice
	from  #temp_Goods_saleMaxDate a left join t_SaleSheet_Day b
	on a.spno=b.cspno and a.zdriqi_lastdaily=isnull(b.dDate,''1899-01-01'')

	update a
	set a.costprice=b.fCostPrice
	from #temp_Goods_Detail0 a left join #temp_Goods_saleMaxPrice b
	on a.spno=b.spno and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')
	

	--如果此商品未日结过，则把costPrice更改未jcd,rkd,cjd价格平均
--select * from #temp_Goods_Detail0

    select a.spno,a.belong,b.zdriqi,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	  into #temp_jcd_rkd_fcd0   --drop table #temp_jcd_rkd_fcd0
    from #temp_storage_manage a ,jcd_sp  b
    where  a.spno=b.spno and b.zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''
    and b.spno in(select spno from '+@GoodsTable+' )
    and ( (b.cangkuno='''+@cWhNo+''' and '''+@cWhNo+'''<>'''') or ('''+@cWhNo+'''='''') )
    union all
    select a.spno,a.belong,b.zdriqi,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
    from #temp_storage_manage a , rkd_sp  b
    where a.spno=b.spno and b.zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''
    and b.spno in(select spno from '+@GoodsTable+' )
    and ( (b.cangkuno='''+@cWhNo+''' and '''+@cWhNo+'''<>'''') or ('''+@cWhNo+'''='''') )
    --union all
    --select a.spno,a.belong,b.zdriqi,shuliang=0,jinjiajine=-isnull(b.chajiajine,0)
    --from #temp_storage_manage a , cjd_sp  b
    --where a.spno=b.spno and b.zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''


	update #temp_jcd_rkd_fcd0
	set spno=belong where isnull(belong,'''')<>''''

	select spno,zdriqi,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0))
  into #temp_jcd_rkd_fcd   --drop table #temp_jcd_rkd_fcd
  from #temp_jcd_rkd_fcd0
  group by spno,zdriqi	
	
   select a.spno,a.zdriqi,a.zdriqi_last_jcd
   into #temp_maxDate_jcd0    --drop table #temp_maxDate_jcd0
   from 
		(select a.spno,a.zdriqi,zdriqi_last_jcd=
										(select max(b.zdriqi) from #temp_jcd_rkd_fcd b where b.zdriqi<=isnull(a.zdriqi,''1899-01-01'')
											and a.spno=b.spno 
										)
		from #temp_Goods_Detail0 a
    )a
    where a.zdriqi_last_jcd is not null
	
    select a.spno,a.zdriqi,a.zdriqi_last_jcd,b.shuliang,b.jinjiajine
    into #temp_costPrice
    from #temp_maxDate_jcd0 a left join #temp_jcd_rkd_fcd b
    on a.spno=b.spno and a.zdriqi_last_jcd=isnull(b.zdriqi,''1899-01-01'')

	--select * from #temp_Goods_Detail0
    update a
    set a.costPrice=case when isnull(b.shuliang,0)<>0 then isnull(b.jinjiajine,0)/isnull(b.shuliang,0) else 0 end
    from #temp_Goods_Detail0 a,#temp_costPrice b
    where (a.costPrice is null) and a.spno=b.spno and a.zdriqi=b.zdriqi

end
else 
begin
--=========================================================================================================
--平均成本计算
	select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
	into #temp_jcd_rkd_fcd0_avg   --drop table #temp_jcd_rkd_fcd0
    from #temp_storage_manage a ,jcd_sp  b
    where  a.spno=b.spno and b.zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''
    and b.spno in(select spno from '+@GoodsTable+' )
    and ( (b.cangkuno='''+@cWhNo+''' and '''+@cWhNo+'''<>'''') or ('''+@cWhNo+'''='''') )
    union all
    select a.spno,a.belong,shuliang=isnull(b.shuliang,0),jinjiajine=isnull(b.jinjiajine,0)
    from #temp_storage_manage a , rkd_sp  b
    where a.spno=b.spno and b.zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''
    and b.spno in(select spno from '+@GoodsTable+' )
    and ( (b.cangkuno='''+@cWhNo+''' and '''+@cWhNo+'''<>'''') or ('''+@cWhNo+'''='''') )

	update #temp_jcd_rkd_fcd0_avg
	set spno=belong
	--select * from #temp_jcd_rkd_fcd order by spno,zdriqi
	select spno,shuliang=sum(isnull(shuliang,0)),jinjiajine=sum(isnull(jinjiajine,0))
    into #temp_jcd_rkd_fcd_avg   --drop table #temp_jcd_rkd_fcd
    from #temp_jcd_rkd_fcd0_avg
    group by spno	


	--select * from #temp_Goods_Detail0
    update a
    set a.costPrice=case when isnull(b.shuliang,0)<>0 then isnull(b.jinjiajine,0)/isnull(b.shuliang,0) else 0 end
    from #temp_Goods_Detail0 a,#temp_jcd_rkd_fcd_avg  b
    where  a.spno=b.spno 

 
end

--=========================================================================================================

--开业第一天
	update a
	set a.costPrice=b.BzJj
	from #temp_Goods_Detail0 a left join spxx b
	on a.spno=b.spno 
	where  isnull(a.costPrice,0)=0 


--更新salePrice
	--select * from #temp_Goods_Sale order by spno,id,zdriqi 
	--drop table #temp_Goods_salePrice
	select a.zdriqi,a.spno,a.zdriqi_lastDaily
	into #temp_Goods_salePrice
	from  
		(select a.zdriqi,a.spno,
						zdriqi_lastDaily=(
									select max(b.zdriqi) from pdd_sp b 
									where  b.zdriqi<=isnull(a.zdriqi,''1899-01-01'') and b.spno=a.spno)
		from #temp_Goods_Detail0 a
		)a
	where a.zdriqi_lastDaily is not null

	--update a
	--set a.salePrice=b.shoujia
	--from #temp_Goods_Detail0 a left join pdd_sp b
	--on  a.zdriqi=isnull(b.zdriqi,''1899-01-01'') and isnull(a.pandian,99)=1 and a.spno=b.spno

	--把salePrice更改为前一次盘点时的零售价
	update a 
	set a.salePrice=(select max(c.shoujia) from #tempSpPd c where c.zdriqi=isnull(b.zdriqi_lastdaily,''1899-01-01'') and c.spno=b.spno)
	from #temp_Goods_Detail0 a left join #temp_Goods_salePrice b
	on a.spno=b.spno and a.zdriqi=isnull(b.zdriqi,''1899-01-01'') 
	--where isnull(a.pandian,99)=0

   --开业第一天
	update a
	set a.salePrice=b.BzLsj
	from #temp_Goods_Detail0 a left join spxx b
	on a.spno=b.spno 
	where  a.salePrice is null
  
 ---------------------------------把salePrice取绝对值
  update a
	set a.saleprice=b.bzlsj
	from #temp_Goods_Detail0 a,spxx b
	where a.spno=b.spno
	and isnull(a.saleprice,0)=0

 update #temp_Goods_Detail0
 set salePrice=abs(salePrice)

 -------------------------------------
	

--select * from #temp_Goods_Detail0 
--期末库存
	--当天有盘点，把盘点数量作为当天的期末库存
	update #temp_Goods_Detail0
	set storageShuliang_end=pd_shuliang
	where isnull(pandian,99)=1

	--select * from #temp_Goods_Detail0 --where pandian=0
	--未盘点商品的最近一次盘点日期
--------------------------------------------------
	  select spno,type,shuliang,zdriqi
		into #temp_Goods_pdd0    --drop table #temp_Goods_pdd0
		from #tempSpPd                                   --******************************************


		update a
		set a.spno=b.belong
		from #temp_Goods_pdd0 a,spxx b
		where a.spno=b.spno and isnull(b.belong,'''')<>''''

	--select * from #temp_Goods_pdd0 order by spno
		select spno,type,shuliang=sum(isnull(shuliang,0)),zdriqi
		into #temp_Goods_pdd
		from #temp_Goods_pdd0
		group by spno,type,zdriqi 
---------------------------------------------------
	select a.spno,a.type,a.zdriqi,
		   zdriqi_lastPandian=isnull(
							(
								select max(b.zdriqi) from #temp_Goods_pdd b 
								where b.zdriqi<isnull(a.zdriqi,''1899-01-01'') and b.spno=a.spno
							),''1899-01-01'')
	into #temp_storage_end
	from #temp_Goods_Detail0 a
	where isnull(a.pandian,99)=0
	--未盘点商品当天的库存变化
	select a.spno,a.type,a.zdriqi,a.zdriqi_lastPandian,b.shuliang
	into #temp_storage_modify
	from #temp_storage_end a left join 
	(
		select spno,type,zdriqi,shuliang=isnull(jc_shuliang,0)+isnull(rk_shuliang,0)-isnull(ck_shuliang,0)-
				isnull(sy_shuliang,0)-isnull(Ls_shuliang,0)-isnull(fc_shuliang,0)-isnull(dbQty,0)
		from #temp_Goods_Detail0 
	)b
	on a.spno=b.spno and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')

	select a.spno,a.type,a.zdriqi,a.zdriqi_lastPandian,Modify_shuliang=
							(
								select sum(isnull(b.shuliang,0))
								from #temp_storage_modify b 
								where b.spno=a.spno and a.type=b.type and b.zdriqi>=a.zdriqi_lastPandian and b.zdriqi<=isnull(a.zdriqi,''1899-01-01'')
								group by b.spno,b.type
							)
	into #temp_last_storage_end     --drop table #temp_last_storage_end
	from #temp_storage_modify a 


	select a.spno,a.type,a.zdriqi,a.zdriqi_lastPandian,a.Modify_shuLiang,
		   pdd_shuliang=(
						select b.pd_shuliang from #temp_Goods_Detail0 b
						where b.zdriqi=isnull(a.zdriqi_lastPandian,''1899-01-01'') and a.spno=b.spno and a.type=b.type
						)
	into #temp_last0
	from #temp_last_storage_end a




	--select * from #temp_Goods_Detail0
	--select * from #temp_last0


	update a
	set a.storageShuliang_end=
							(
								select case when (b.pdd_shuliang is null) then b.Modify_shuliang
											 else (isnull(b.pdd_shuliang,0)+isnull(b.Modify_shuliang,0))
											end
								from #temp_last0 b
								where b.zdriqi=isnull(a.zdriqi,''1899-01-01'') and a.spno=b.spno
                                                               and a.type=b.type
							)
	from #temp_Goods_Detail0 a
	where isnull(a.pandian,99)=0


--起初库存

	select a.spno,a.type,a.zdriqi,a.zdriqi_last
	into #temp_0
	from
	(select a.spno,a.type,a.zdriqi,zdriqi_last=
									(
										select max(isnull(b.zdriqi,''1899-01-01''))
										from #temp_Goods_Detail0 b
										where b.zdriqi<isnull(a.zdriqi,''1899-01-01'') and a.spno=b.spno
                                                                   and a.type=b.type

									)	
		from #temp_Goods_Detail0 a
	 )a
	 where a.zdriqi_last is not null


		select a.spno,a.type,a.zdriqi,a.zdriqi_last,b.storageShuliang_end,b.costprice
		into #temp_1
		from #temp_0 a left join #temp_Goods_Detail0 b
		on a.spno=b.spno and a.type=b.type and a.zdriqi_last=isnull(b.zdriqi,''1899-01-01'') 
		where b.storageShuliang_end is not null


		update a
		set a.storageShuliang_begin=b.storageShuliang_end,a.costpriceold=b.costprice
		from #temp_Goods_Detail0 a left join #temp_1 b
		on a.zdriqi=isnull(b.zdriqi,''1899-01-01'')and a.spno=b.spno and a.type=b.type


		update #temp_Goods_Detail0
		set storageShuliang_begin=0
		where storageShuliang_begin is null

    update #temp_Goods_Detail0
		set costpriceold=0
		where costpriceold is null
--如果当天有差价单此 当天成本=期初成本-（差价金额/差价数量）
   update #temp_Goods_Detail0
   set costprice=costprice-(isnull(cj_jine,0)/isnull(cj_shuliang,0))
   where isnull(cj_jine,0)<>0 and isnull(cj_shuliang,0)<>0
   and isnull(costpriceold,0)=0 and isnull(costprice,0)<>0 

   update #temp_Goods_Detail0
   set costprice=costpriceold-(isnull(cj_jine,0)/isnull(cj_shuliang,0))
   where isnull(cj_jine,0)<>0 and isnull(cj_shuliang,0)<>0
   and isnull(costpriceold,0)<>0 

--计算成本价格，销售价格
	  update #temp_Goods_Detail0
	  set costAll_begin=isnull(storageShuliang_begin,0)*isnull(costPriceold,0),
		saleAll_begin=isnull(storageShuliang_begin,0)*isnull(salePrice,0),
		costAll_end=isnull(storageShuliang_end,0)*isnull(costPrice,0),
		saleAll_end=isnull(storageShuliang_end,0)*isnull(salePrice,0),
		--pd_jine=isnull(pd_shuliang,0)*isnull(costPrice,0),
		--jc_jine=isnull(jc_shuliang,0)*isnull(costPrice,0),
		--rk_jine=isnull(rk_shuliang,0)*isnull(costPrice,0),
		ckCostAll=isnull(ck_shuliang,0)*isnull(costPrice,0),
		--ck_jine=isnull(ck_shuliang,0)*isnull(salePrice,0),
		--fc_jine=isnull(fc_shuliang,0)*isnull(costPrice,0),
		syCostAll=isnull(sy_shuliang,0)*isnull(costPrice,0),
		--sy_jine=isnull(sy_shuliang,0)*isnull(salePrice,0),
		LsCostAll=isnull(Ls_shuliang,0)*isnull(costPrice,0)
		--Ls_jine=isnull(Ls_shuliang,0)*isnull(salePrice,0)

		update #temp_Goods_Detail0
		set pd_loseShuliang=isnull((isnull(pd_shuliang,0)-(isnull(storageShuliang_begin,0)+isnull(jc_shuliang,0)+isnull(rk_shuliang,0)-
							isnull(fc_shuliang,0)-isnull(ck_shuliang,0)-isnull(sy_shuliang,0)-isnull(Ls_shuliang,0)-isnull(dbQty,0))),0)
		where isnull(pandian,99)=1
       
    update #temp_Goods_Detail0
		set pd_loseCostAll=isnull(pd_loseShuliang,0)*isnull(costPrice,0),
		pd_loseSaleAll=isnull(pd_loseShuliang,0)*isnull(salePrice,0)
    where isnull(pandian,99)=1

--------20081013 begin

        select *
        into #temp_Goods_Detail0_last0
        from #temp_Goods_Detail0
        where zdriqi between '''+@Date_begin +''' and '''+ @Date_end+'''
       

        select a.spno,b.type,b.mingcheng,b.huoNo,b.danwei,b.guige,b.hj,b.zdriqi,b.salePrice,b.costpriceold,b.costPrice,
        b.storageShuliang_begin,b.costAll_begin,b.saleAll_begin,b.storageShuliang_end,b.costAll_end,
        b.saleAll_end,b.pandian,b.pd_shuliang,b.pd_jine,b.pd_loseShuliang,b.pd_loseCostAll,b.pd_loseSaleAll,
        b.jc_shuliang,b.jc_jine,b.rk_shuliang,b.rk_jine,b.ck_shuliang,b.ckCostAll,b.ck_jine,b.fc_shuliang,
        b.fc_jine,b.sy_shuliang,b.syCostAll,b.sy_jine,b.Ls_shuliang,b.LsCostAll,b.Ls_jine,b.cj_shuliang,b.cj_jine,
        b.dbQty,b.db_money,spnoTmp,iserno
        into #temp_Goods_Detail0_last
        from '+@GoodsTable+' a left join #temp_Goods_Detail0_last0 b
        on a.spno=b.spno
      
        select a.spno,a.type,zdriqi='''+ @Date_end+''',zdriqiLastdate=
                                              isnull((
                                                 select max(b.zdriqi)from #temp_Goods_Detail0 b 
                                                 where a.spno=b.spno
                                                 and a.type=b.type
                                                  
                                              ),''1899-01-01'')
        into #temp_lastDate        -- drop table #temp_lastDate   drop table #tempNullDate
        from #temp_Goods_Detail0_last a 
        where a.zdriqi is null

       select a.spno,a.type,a.zdriqi,b.mingcheng,b.huoNo,b.danwei,b.guige,b.hj,b.salePrice,b.costpriceold,b.costPrice,
        b.storageShuliang_begin,b.costAll_begin,b.saleAll_begin,b.storageShuliang_end,b.costAll_end,
        b.saleAll_end,b.pandian,b.pd_shuliang,b.pd_jine,b.pd_loseShuliang,b.pd_loseCostAll,b.pd_loseSaleAll,
        b.jc_shuliang,b.jc_jine,b.rk_shuliang,b.rk_jine,b.ck_shuliang,b.ckCostAll,b.ck_jine,b.fc_shuliang,
        b.fc_jine,b.sy_shuliang,b.syCostAll,b.sy_jine,b.Ls_shuliang,b.LsCostAll,b.Ls_jine,b.cj_shuliang,b.cj_jine,
        b.dbQty,b.db_money
       into #tempNullDate
       from #temp_lastDate a left join #temp_Goods_Detail0 b
       on a.spno=b.spno and a.type=b.type and b.zdriqi is not null and a.zdriqiLastdate=isnull(b.zdriqi,''1899-01-01'')

       update a
        set a.spno=b.spno,a.type=b.type,a.zdriqi=b.zdriqi,a.mingcheng=b.mingcheng,a.huoNo=b.huoNo,a.danwei=b.danwei,
        a.guige=b.guige,a.hj=b.hj,a.salePrice=b.salePrice,a.costPriceold=b.costPriceold,a.costPrice=b.costPrice,
        a.storageShuliang_begin=b.storageShuliang_end,a.costAll_begin=b.costAll_end,
        a.saleAll_begin=b.saleAll_end,a.storageShuliang_end=b.storageShuliang_end,a.costAll_end=b.costAll_end,
        a.saleAll_end=b.saleAll_end,a.pandian=0,a.pd_shuliang=0,a.pd_jine=0,
        a.pd_loseShuliang=0,a.pd_loseCostAll=0,a.pd_loseSaleAll=0,
        a.jc_shuliang=0,a.jc_jine=0,a.rk_shuliang=0,a.rk_jine=0,
        a.ck_shuliang=0,a.ckCostAll=0,a.ck_jine=0,a.fc_shuliang=0,
        a.fc_jine=0,a.sy_shuliang=0,a.syCostAll=0,a.sy_jine=0,
        a.Ls_shuliang=0,a.LsCostAll=0,a.Ls_jine=0,a.cj_shuliang=0,a.cj_jine=0,
        a.dbQty=0,a.db_money=0
        from #temp_Goods_Detail0_last a, #tempNullDate b
        where a.spno=b.spno and a.type=b.type  and a.zdriqi is null
--------20081013 end

       update #temp_Goods_Detail0_last
       set  spnotmp=spno,iserno=1



--每天合计

  select spno,type=null,mingcheng,huoNo,danwei,guige,hj=null,zdriqi,saleprice,costpriceold,
  costprice,storageshuliang_begin=sum(isnull(storageshuliang_begin,0)),
  costall_begin=sum(isnull(costall_begin,0)),saleall_begin=sum(isnull(saleall_begin,0)),
  storageshuliang_end=sum(isnull(storageshuliang_end,0)),costall_end=sum(isnull(costall_end,0)),
  saleall_end=sum(isnull(saleall_end,0)),pandian,pd_shuliang=sum(isnull(pd_shuliang,0)),
  pd_jine=sum(isnull(pd_jine,0)),pd_loseshuliang=sum(isnull(pd_loseshuliang,0)),
  pd_LoseCostAll=sum(isnull(pd_LoseCostAll,0)),pd_loseSaleAll=sum(isnull(pd_loseSaleAll,0)),
  jc_shuliang=sum(isnull(jc_shuliang,0)),jc_jine=sum(isnull(jc_jine,0)),
  rk_shuliang=sum(isnull(rk_shuliang,0)),rk_jine=sum(isnull(rk_jine,0)),
  ck_shuliang=sum(isnull(ck_shuliang,0)),ckCostAll=sum(isnull(ckCostAll,0)),ck_jine=sum(isnull(ck_jine,0)),
  fc_shuliang=sum(isnull(fc_shuliang,0)),fc_jine=sum(isnull(fc_jine,0)),
  sy_shuliang=sum(isnull(sy_shuliang,0)),syCostAll=sum(isnull(syCostAll,0)),sy_jine=sum(isnull(sy_jine,0)),
	Ls_shuliang=sum(isnull(Ls_shuliang,0)),LsCostAll=sum(isnull(LsCostAll,0)),Ls_jine=sum(isnull(Ls_jine,0)),
  cj_shuliang=sum(isnull(cj_shuliang,0)),cj_jine=sum(isnull(cj_jine,0)),
  dbQty=sum(isnull(dbQty,0)),db_money=sum(isnull(db_money,0)),spnotmp=spno,iserno=0
  into #temp_hjDay 
  from #temp_Goods_Detail0_last
  group by spno,mingcheng,huoNo,danwei,guige,zdriqi,saleprice,costpriceold,costprice,pandian
  
--合计
	select spno,type=''-'',hj=''合计:'',
			pd_loseShuliang=sum(isnull(pd_loseShuliang,0)),pd_LoseCostAll=sum(isnull(pd_LoseCostAll,0)),
			pd_loseSaleAll=sum(isnull(pd_loseSaleAll,0)),
			jc_shuliang=sum(isnull(jc_shuliang,0)),jc_jine=sum(isnull(jc_jine,0)),
			rk_shuliang=sum(isnull(rk_shuliang,0)),rk_jine=sum(isnull(rk_jine,0)),
			ck_shuliang=sum(isnull(ck_shuliang,0)),ckCostAll=sum(isnull(ckCostAll,0)),ck_jine=sum(isnull(ck_jine,0)),
			fc_shuliang=sum(isnull(fc_shuliang,0)),fc_jine=sum(isnull(fc_jine,0)),
			sy_shuliang=sum(isnull(sy_shuliang,0)),syCostAll=sum(isnull(syCostAll,0)),sy_jine=sum(isnull(sy_jine,0)),
			Ls_shuliang=sum(isnull(Ls_shuliang,0)),LsCostAll=sum(isnull(LsCostAll,0)),Ls_jine=sum(isnull(Ls_jine,0)),
      cj_shuliang=sum(isnull(cj_shuliang,0)),cj_jine=sum(isnull(cj_jine,0)),
      dbQty=sum(isnull(dbQty,0)),db_money=sum(isnull(db_money,0))	
	into #temp_hj0   --drop table #temp_hj0
	from #temp_Goods_Detail0_last
	group by spno


	select distinct a.spno,a.zdriqi,a.type,storageShuliang_end=isnull(b.storageShuliang_end,0),
  CostAll_end=isnull(b.CostAll_end,0),saleAll_end=isnull(b.saleAll_end,0)
	into #temp_3
	from
	(
		select spno,type,zdriqi=max(zdriqi)
		from #temp_Goods_Detail0_last
		group by spno,type
	)a left join #temp_Goods_Detail0_last b
	on a.spno=b.spno and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'')  

  select distinct a.spno,a.zdriqi,a.type,storageShuliang_begin=isnull(b.storageShuliang_begin,0),
  CostAll_begin=isnull(b.CostAll_begin,0),saleAll_begin=isnull(b.saleAll_begin,0)
	into #temp_4    --drop table #temp_4
	from
	(
		select spno,type,zdriqi=min(zdriqi)
		from #temp_Goods_Detail0_last
		group by spno,type
	)a left join #temp_Goods_Detail0_last b
	on a.spno=b.spno and a.type=b.type and a.zdriqi=isnull(b.zdriqi,''1899-01-01'') 
	
    
   select distinct a.spno,a.type,a.storageShuliang_begin,a.CostAll_begin,a.saleAll_begin,b.storageShuliang_end,b.CostAll_end,b.saleAll_end
   into #temp_5    --drop table #temp_5
	 from #temp_4 a,#temp_3 b
	 where a.spno=b.spno and a.type=b.type
    
   select spno,storageShuliang_begin=sum(storageShuliang_begin),CostAll_begin=sum(CostAll_begin),
   saleAll_begin=sum(saleAll_begin),storageShuliang_end=sum(storageShuliang_end),
   CostAll_end=sum(CostAll_end),saleAll_end=sum(saleAll_end)
   into #temp_6
   from #temp_5 
   group by spno

	select distinct a.spno,a.hj,a.pd_loseShuliang,a.pd_LoseCostAll,a.pd_loseSaleAll,a.jc_shuliang,a.jc_jine,a.rk_shuliang,
		   a.rk_jine,a.ck_shuliang,a.ckCostAll,a.ck_jine,a.fc_shuliang,a.fc_jine,a.sy_shuliang,a.syCostAll,a.sy_jine,
		   a.Ls_shuliang,a.LsCostAll,a.Ls_jine,b.storageShuliang_end,b.CostAll_end,b.saleAll_end,
		   b.storageShuliang_begin,b.CostAll_begin,b.saleAll_begin,a.cj_shuliang,a.cj_jine,a.dbQty,a.db_money
	into #temp_hj  --drop table #temp_hj
	from #temp_hj0 a left join #temp_6 b
	on a.spno=b.spno 

	insert into #temp_Goods_Detail0_last(spno,type, hj, zdriqi, salePrice, 
				costPrice, storageShuliang_begin, costAll_begin, saleAll_begin, storageShuliang_end, 
				costAll_end, saleAll_end, pandian, pd_shuliang, pd_jine, pd_loseShuliang, pd_loseCostAll, 
				pd_loseSaleAll, jc_shuliang, jc_jine, rk_shuliang, rk_jine, ck_shuliang, ckCostAll, ck_jine,
				 fc_shuliang, fc_jine, sy_shuliang, syCostAll, sy_jine, Ls_shuliang, LsCostAll, Ls_jine,cj_shuliang,cj_jine,
         dbQty,db_money,spnotmp,iserno)
	select distinct spno,type=null,hj,zdriqi='''+@date_end+''',salePrice=null,costPrice=null, storageShuliang_begin, costAll_begin,
			saleAll_begin,storageShuliang_end,CostAll_end,saleAll_end,pandian=0, pd_shuliang=null, pd_jine=null,
		   pd_loseShuliang,pd_loseCostAll,pd_loseSaleAll,jc_shuliang,jc_jine,rk_shuliang,rk_jine,ck_shuliang,
		   ckCostAll,ck_jine,fc_shuliang,fc_jine,sy_shuliang,syCostAll,sy_jine,Ls_shuliang,LsCostAll,Ls_jine,cj_shuliang,cj_jine,
       dbQty,db_money,spno,2
	from #temp_hj


  insert into #temp_Goods_Detail0_last(spno,type, hj, zdriqi, salePrice, 
				costPrice,costpriceold, storageShuliang_begin, costAll_begin, saleAll_begin, storageShuliang_end, 
				costAll_end, saleAll_end, pandian, pd_shuliang, pd_jine, pd_loseShuliang, pd_loseCostAll, 
				pd_loseSaleAll, jc_shuliang, jc_jine, rk_shuliang, rk_jine, ck_shuliang, ckCostAll, ck_jine,
				 fc_shuliang, fc_jine, sy_shuliang, syCostAll, sy_jine, Ls_shuliang, LsCostAll, Ls_jine,cj_shuliang,cj_jine,
         dbQty,db_money,spnotmp,iserno)
	select spno,type=null,hj,zdriqi,salePrice,costPrice,costpriceold, storageShuliang_begin, costAll_begin,
			saleAll_begin,storageShuliang_end,CostAll_end,saleAll_end,pandian, pd_shuliang, pd_jine,
		   pd_loseShuliang,pd_loseCostAll,pd_loseSaleAll,jc_shuliang,jc_jine,rk_shuliang,rk_jine,ck_shuliang,
		   ckCostAll,ck_jine,fc_shuliang,fc_jine,sy_shuliang,syCostAll,sy_jine,Ls_shuliang,LsCostAll,Ls_jine,cj_shuliang,cj_jine,
       dbQty,db_money,spno,0
	from #temp_hjDay

	insert into #temp_Goods_Detail0_last(spno,mingcheng,huoNO,danwei,guiGe,hj,zdriqi, 
				salePrice, costPrice,type,storageShuliang_begin, costAll_begin, saleAll_begin, 
				storageShuliang_end, costAll_end, saleAll_end, pandian, pd_shuliang, pd_jine, 
				pd_loseShuliang, pd_loseCostAll, pd_loseSaleAll, jc_shuliang, jc_jine, rk_shuliang, 
				rk_jine, ck_shuliang, ckCostAll, ck_jine, fc_shuliang, fc_jine, sy_shuliang, syCostAll, 
				sy_jine, Ls_shuliang, LsCostAll, Ls_jine,cj_shuliang,cj_jine,dbQty,db_money,spnotmp,iserno)								
	select  spno=''柜组/商品:'',mingcheng=''查询条件'',huoNO=null,danwei=null,guiGe=null,hj=''总计:'',zdriqi='''+@date_end+''',
			salePrice=null,costPrice=null,type=null,storageShuliang_begin=sum(isnull(storageShuliang_begin,0)), 
			costAll_begin=sum(isnull(CostAll_begin,0)), saleAll_begin=sum(isnull(saleAll_begin,0)),
			storageShuliang_end=sum(isnull(storageShuliang_end,0)),CostAll_end=sum(isnull(CostAll_end,0)),
		    saleAll_end=sum(isnull(saleAll_end,0)),pandian=0,pd_shuliang=null,pd_jine=null,
			pd_loseShuliang=sum(isnull(pd_loseShuliang,0)),pd_LoseCostAll=sum(isnull(pd_LoseCostAll,0)),
			pd_loseSaleAll=sum(isnull(pd_loseSaleAll,0)),
			jc_shuliang=sum(isnull(jc_shuliang,0)),jc_jine=sum(isnull(jc_jine,0)),
			rk_shuliang=sum(isnull(rk_shuliang,0)),rk_jine=sum(isnull(rk_jine,0)),
			ck_shuliang=sum(isnull(ck_shuliang,0)),ckCostAll=sum(isnull(ckCostAll,0)),ck_jine=sum(isnull(ck_jine,0)),
			fc_shuliang=sum(isnull(fc_shuliang,0)),fc_jine=sum(isnull(fc_jine,0)),
			sy_shuliang=sum(isnull(sy_shuliang,0)),syCostAll=sum(isnull(syCostAll,0)),sy_jine=sum(isnull(sy_jine,0)),
			Ls_shuliang=sum(isnull(Ls_shuliang,0)),LsCostAll=sum(isnull(LsCostAll,0)),Ls_jine=sum(isnull(Ls_jine,0)),
      cj_shuliang=sum(isnull(cj_shuliang,0)),cj_jine=sum(isnull(cj_jine,0)),
			dbQty=sum(isnull(dbQty,0)),db_money=sum(isnull(db_money,0)),''ZZZZZZ'',3
	from #temp_hj

	update a
	set a.mingcheng=b.mingcheng,a.huoNO=b.dw1,a.danwei=b.danwei,a.guiGe=b.guige
	from #temp_Goods_Detail0_last a left join spxx b
	on a.spno=b.spno

  update #temp_Goods_Detail0_last
  set spno='''',mingcheng=null,huono=null,danwei=null,guige=null,saleprice=null,
  costpriceold=null,costprice=null
  where  iserno=1
 
	select spno,mingcheng,huono,danwei,guige,hj,zdriqi,saleprice,costpriceold,costprice,
  type,storageshuliang_begin,costall_begin,saleall_begin,storageshuliang_end,
  costall_end,saleall_end,pandian,pd_shuliang,pd_jine,pd_loseshuliang,pd_losecostall,
  pd_losesaleall,jc_shuliang,jc_jine,rk_shuliang,rk_jine,ck_shuliang,ckcostall,ck_jine,
  fc_shuliang,fc_jine,sy_shuliang,sycostall,sy_jine,ls_shuliang,lscostall,ls_jine,cj_shuliang,
  cj_jine,dbQty,db_money,spnoTmp,iserno 
  from #temp_Goods_Detail0_last 
  order by spnotmp,zdriqi,iserno





')


GO
