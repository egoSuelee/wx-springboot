
create  procedure p_sum_guizu_jiesuan
@guizuno varchar(32),
@cYear char(4),
@cMonth char(2)
as
begin

	select cYear,cYearEnd,cMonth,iWeekNo=cast(iWeekNo as varchar(8)) ,dDate1,dDate2,iHolidays,fRight,iDays
	into #tempWeekOfMonth_Finance
	from dbo.t_WeekOfMonth_Finance
	where cYear=@cYear and cMonth=@cMonth

	select a.guizuno,a.guizu,a.feiyongno,a.feiyong,a.feiyongjine,a.serno,a.zdriqi,
	b.cYear,b.cYearEnd,b.cMonth,b.iWeekNo
	into #tempGuizuFeiyong
	from  dbo.guizufeiyong a,#tempWeekOfMonth_Finance b
	where a.zdriqi between b.dDate1 and b.dDate2 and (a.guizuno=@guizuno or dbo.trim(@guizuno)='')

  select cYear,cYearEnd,cMonth,iWeekNo,guizuno,guizu,feiyongno,feiyong,feiyongjine,serno,zdriqi
	from #tempGuizuFeiyong
	union all
	select cYear,cYearEnd,cMonth,iWeekNo='期末',guizuno='总计:',guizu=null,feiyongno=null,feiyong=null,feiyongjine=sum(feiyongjine),serno=null,zdriqi=null
	from #tempGuizuFeiyong
	group by cYear,cYearEnd,cMonth
	order by cYear,cYearEnd,cMonth,guizuno,zdriqi
	

	

end

/*
 p_GuizuFeiyong_Month_guizuno  '210070','2006','06'
*/

GO
