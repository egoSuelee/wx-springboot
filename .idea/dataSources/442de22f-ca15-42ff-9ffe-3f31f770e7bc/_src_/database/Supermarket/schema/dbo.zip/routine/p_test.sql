create proc p_test
as
select * into #tempguizu from guizu
select * from #tempguizu
GO
