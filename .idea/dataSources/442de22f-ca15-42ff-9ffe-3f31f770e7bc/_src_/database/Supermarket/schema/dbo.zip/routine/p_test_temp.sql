CREATE procedure p_test_temp
as
begin


  select sheetno ,shishou=sum(shishou)
	into #jiesuan_tmp
	from dbo.jiesuan
	where zdriqi between '2006-11-22' and '2006-11-30'
	group by sheetno

  select sheetno=substring(lsdno,1,14) ,shishou=sum(jine)
	into #lsdsp_tmp
	from dbo.lsdsp
	where lsriqi between '2006-11-22' and '2006-11-30'
	group by substring(lsdno,1,14)

  select sheetno_a=a.sheetno,shishou_a=a.shishou,sheetno_b=b.sheetno,shishou_b=b.shishou
	into #last_comp_temp
  from #jiesuan_tmp a
	left join #lsdsp_tmp b
	on a.sheetno=b.sheetno

  select * from #last_comp_temp where shishou_a<>shishou_b
 
end
GO
