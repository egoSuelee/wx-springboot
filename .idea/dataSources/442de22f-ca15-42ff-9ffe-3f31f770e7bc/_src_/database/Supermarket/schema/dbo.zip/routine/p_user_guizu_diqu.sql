
CREATE procedure p_user_guizu_diqu
@userno varchar(32),
@guizuno varchar(32)
as
begin
/*
	select top 1 a.guizuno,diquno=a.quno,diqumc=a.qu
	from guizu a,user_diqu_chen b
	where a.guizuno=@guizuno and b.[user]=@userno  and a.quno=b.diquno
*/	
  
	select top 1 a.guizuno,diquno=a.quno,diqumc=a.qu
  into #temp1
	from guizu a,user_diqu_chen b
	where a.guizuno=@guizuno and b.[user]=@userno  and a.quno=b.diquno
  
	select iCount=count(guizuno)
	from #temp1

/*
select *
from user_diqu_chen

p_user_guizu_diqu '015','18002'

select * from weizhi

select * from diqu


*/
end

GO
