
/*
Vip会员客单价（按日期排序）
p_vip_KeDanJiaByDay_chen 'temp_delphi_last','2007-1-18','2008-12-18'
*/



create proc p_vip_KeDanJiaByDay_chen
@delphiTable varchar(50),
@date1 datetime,
@date2 datetime
as
begin
    set nocount on
  exec('
	if (select object_id(''tempdb..#temp_Lsdsp_VipNo''))is not null 
	begin
		drop table #temp_Lsdsp_VipNo
	end
	if (select object_id(''tempdb..#temp_VipSheet_shishou''))is not null 
	begin
		drop table #temp_VipSheet_shishou
	end
	if (select object_id(''tempdb..#temp_VipNo_sheetNo''))is not null 
	begin
		drop table #temp_VipNo_sheetNo
	end
	if (select object_id(''tempdb..#temp_KeDanJia_date''))is not null 
	begin
		drop table #temp_KeDanJia_date
	end
	if (select object_id(''tempdb..#temp_vip_KeDanJia_Day''))is not null 
	begin
		drop table #temp_vip_KeDanJia_Day
	end

    select a.VipNo,b.zdriqi,b.LsdNo,b.guizuno,b.guizu,c.Spno,c.MingCheng
    into #temp_Lsdsp_VipNo
    from '+@delphiTable+' a left join lsd b
    on isnull(b.VipNO,'''')=a.VipNo
    left join lsdsp c
    on b.lsdno=c.lsdno
    where isnull(b.zdriqi,''1900-01-01'') between '''+@date1+''' and '''+ @date2+'''

	select  a.sheetNo,a.zdriqi,shishou=sum(a.shishou),
	Sheet_day=datepart(day,a.zdriqi),Sheet_week=datepart(weekday,a.zdriqi),
	Sheet_Month=datepart(month,a.zdriqi)
	into #temp_VipSheet_shishou
	from jiesuan a,#temp_Lsdsp_VipNo b
	where a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)
	group by a.sheetNo,a.zdriqi


	select distinct b.vipNo,a.sheetNo,a.zdriqi,a.shishou,
	a.Sheet_day,a.Sheet_week,a.Sheet_Month
	into #temp_VipNo_sheetNo
	from #temp_VipSheet_shishou a left join #temp_Lsdsp_VipNo b
	on a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)

	select vipno,Sheet_day,KeDanJia=cast(sum(shishou) as money)/count(sheetNo)
    into #temp_KeDanJia_date
	from #temp_VipNo_sheetNo
	group by vipno,Sheet_day
	
--    select vipNo,Sheet_day,KeDanJia
--    from #temp_KeDanJia_date
--    order by vipNo,Sheet_day
--    union all
--    select VipNo=''平均客单价'',Sheet_day,KeDanJia=sum(KeDanJia)/count(distinct vipno)
--    from #temp_KeDanJia_date
--    group by sheet_day
    

    create table #temp_vip_KeDanJia_Day
    (
		vipNo varchar(50),
		day1 money,
		day2 money,
		day3 money,
		day4 money, 
		day5 money, 
		day6 money, 
		day7 money, 
		day8 money, 
		day9 money, 
		day10 money, 
		day11 money, 
		day12 money, 
		day13 money, 
		day14 money, 
		day15 money, 
		day16 money, 
		day17 money, 
		day18 money, 
		day19 money, 
		day20 money, 
		day21 money, 
		day22 money, 
		day23 money, 
		day24 money, 
		day25 money, 
		day26 money, 
		day27 money, 
		day28 money, 
		day29 money, 
		day30 money, 
		day31 money 
	)  
    
    --插入卡号
	insert into #temp_vip_KeDanJia_Day
	(   vipNo ,
		day1 ,day2 ,day3 ,day4 , day5 , day6 , day7 , day8 , day9 , day10 , day11 , day12 , day13 , 
		day14 , day15 , day16 , day17 , day18 , day19 , day20 , day21 , day22 , day23 , day24 , 
		day25 , day26 , day27 , day28 , day29 , day30 , day31 
	)
    select distinct vipNo=VipNo,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    from #temp_KeDanJia_date

   --更新每天数据
/*
   declare @i int
   set @i=1
   while (@i<=31)
   begin
	update a
	set a.vipNO=b.vipNo,a.day1=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=@i
    
    set @i=@i+1
   end
*/

    --1号
	update a
	set a.day1=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=1
    --2号
	update a
	set a.day2=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=2
    --3号
	update a
	set a.day3=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=3
    --4号
	update a
	set a.day4=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=4
    --5号
	update a
	set a.day5=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=5
    --6号
	update a
	set a.day6=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=6
    --7号
	update a
	set a.day7=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=7
    --8号
	update a
	set a.day8=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=8
    --9号
	update a
	set a.day9=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=9
    --10号
	update a
	set a.day10=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=10
    --11号
	update a
	set a.day11=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=11
    --12号
	update a
	set a.day12=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=12
    --13号
	update a
	set a.day13=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=13
    --14号
	update a
	set a.day14=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=14
    --15号
	update a
	set a.day15=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=15
    --16号
	update a
	set a.day16=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=16
    --17号
	update a
	set a.day17=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=17
    --18号
	update a
	set a.day18=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=18
    --19号
	update a
	set a.day19=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=19
    --20号
	update a
	set a.day20=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=20
    --21号
	update a
	set a.day21=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=21
    --22号
	update a
	set a.day22=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=22
    --23号
	update a
	set a.day23=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=23
    --24号
	update a
	set a.day24=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=24
    --25号
	update a
	set a.day25=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=25
    --26号
	update a
	set a.day26=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=26
    --27号
	update a
	set a.day27=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=27
    --28号
	update a
	set a.day28=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=28
    --29号
	update a
	set a.day29=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=29
    --30号
	update a
	set a.day30=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=30
    --31号
	update a
	set a.day31=b.KeDanJia
	from #temp_vip_KeDanJia_Day a,#temp_KeDanJia_date b
	where a.vipNo=b.VipNo and b.Sheet_day=31

    --select * from #temp_vip_KeDanJia_Day
    select vipNo,day1,day2,day3,day4,day5,day6,day7,day8,day9,day10,day11,day12,day13,day14,day15,day16,
		   day17,day18,day19,day20,day21,day22,day23,day24,day25,day26,day27,day28,day29,day30,day31
    from #temp_vip_KeDanJia_Day
    union all
    select vipNO=''平均客单价'',day1=sum(day1)/count(vipNO),day2=sum(day2)/count(vipNO),day3=sum(day3)/count(vipNO),
           day4=sum(day4)/count(vipNO),day5=sum(day5)/count(vipNO),day6=sum(day6)/count(vipNO),day7=sum(day7)/count(vipNO),
		   day8=sum(day8)/count(vipNO),day9=sum(day9)/count(vipNO),day10=sum(day10)/count(vipNO),day11=sum(day11)/count(vipNO),
		   day12=sum(day12)/count(vipNO),day13=sum(day13)/count(vipNO),day14=sum(day14)/count(vipNO),day15=sum(day15)/count(vipNO),
		   day16=sum(day16)/count(vipNO),day17=sum(day17)/count(vipNO),day18=sum(day18)/count(vipNO),day19=sum(day19)/count(vipNO),
		   day20=sum(day20)/count(vipNO),day21=sum(day21)/count(vipNO),day22=sum(day22)/count(vipNO),day23=sum(day23)/count(vipNO),
           day24=sum(day24)/count(vipNO),day25=sum(day25)/count(vipNO),day26=sum(day26)/count(vipNO),day27=sum(day27)/count(vipNO),
		   day28=sum(day28)/count(vipNO),day29=sum(day29)/count(vipNO),day30=sum(day30)/count(vipNO),day31=sum(day31)/count(vipNO)
    from #temp_vip_KeDanJia_Day
    order by vipNo
    

 ')     
end

GO
