
/*
Vip会员客单价（按周次排序）
p_vip_KeDanJiaByWeekday_chen 'temp_delphi_last','2007-1-2','2008-12-2'
*/



create proc p_vip_KeDanJiaByWeekday_chen
@delphiTable varchar(50),
@date1 datetime,
@date2 datetime
as
begin
set nocount on
exec('	
	if (select object_id(''tempdb..#temp_Lsdsp_VipNo''))is not null 
	begin
		drop table #temp_Lsdsp_VipNo
	end
	if (select object_id(''tempdb..#temp_VipSheet_shishou''))is not null 
	begin
		drop table #temp_VipSheet_shishou
	end
	if (select object_id(''tempdb..#temp_VipNo_sheetNo''))is not null 
	begin
		drop table #temp_VipNo_sheetNo
	end
	if (select object_id(''tempdb..#temp_KeDanJia_week''))is not null 
	begin
		drop table #temp_KeDanJia_week
	end
	if (select object_id(''tempdb..#temp_Vip_KeDanJia_weekday''))is not null 
	begin
		drop table #temp_Vip_KeDanJia_weekday
	end


    select a.VipNo,b.zdriqi,b.LsdNo,b.guizuno,b.guizu,c.Spno,c.MingCheng
    into #temp_Lsdsp_VipNo
    from '+@delphiTable+' a left join lsd b
    on isnull(b.VipNO,'''')=a.VipNo
    left join lsdsp c
    on b.lsdno=c.lsdno
    where isnull(b.zdriqi,''1900-01-01'') between '''+@date1+''' and '''+ @date2+'''

	select  a.sheetNo,a.zdriqi,shishou=sum(a.shishou),
	Sheet_day=datepart(day,a.zdriqi),Sheet_week=datepart(weekday,a.zdriqi),
	Sheet_Month=datepart(month,a.zdriqi)
	into #temp_VipSheet_shishou
	from jiesuan a,#temp_Lsdsp_VipNo b
	where a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)
	group by a.sheetNo,a.zdriqi


	select distinct b.vipNo,a.sheetNo,a.zdriqi,a.shishou,
	a.Sheet_day,a.Sheet_week,a.Sheet_Month
	into #temp_VipNo_sheetNo
	from #temp_VipSheet_shishou a left join #temp_Lsdsp_VipNo b
	on a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)

	select vipno,Sheet_week,KeDanJia=cast(sum(shishou)as money)/count(sheetNo)
    into #temp_KeDanJia_week
	from #temp_VipNo_sheetNo
	group by vipno,Sheet_week

--    select vipNo,Sheet_week,KeDanJia
--    from #temp_KeDanJia_week
--    union all
--    select VipNo=''平均客单价'',Sheet_week,KeDanJia=sum(KeDanJia)/count(distinct vipno)
--    from #temp_KeDanJia_week
--    group by Sheet_week
--    order by vipno,Sheet_week

	create table #temp_Vip_KeDanJia_weekday
	(
		VipNo varchar(50),
		MON  money,
		TUS  money,
		WEN  money,
		THUR money,
		FRI  money,
		SAT  money,
		SUN  money
	)
    --插入卡号到表
   insert into #temp_Vip_KeDanJia_weekday
   (
		VipNo,MON,TUS,WEN,THUR,FRI,SAT,SUN
   )
   select distinct Vipno=VipNo,0,0,0,0,0,0,0
   from #temp_KeDanJia_week

  --更新星期数据
  --星期一
  update a
  set a.MON=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=2
  --星期2
  update a
  set a.TUS=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=3
  --星期3
  update a
  set a.WEN=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=4
  --星期4
  update a
  set a.THUR=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=5
  --星期5
  update a
  set a.FRI=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=6
  --星期6
  update a
  set a.SAT=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=7
  --星期7
  update a
  set a.SUN=b.KeDanJia
  from #temp_Vip_KeDanJia_weekday a,#temp_KeDanJia_week b
  where a.VipNo=b.VipNo and b.Sheet_week=1

 select VipNo,MON,TUS,WEN,THUR,FRI,SAT,SUN
 from #temp_Vip_KeDanJia_weekday
 union all
 select Vipno=''平均客单价'',MON=sum(MON)/count(vipNo),TUS=sum(TUS)/count(vipNo),WEN=sum(WEN)/count(vipNo),
					       THUR=sum(THUR)/count(vipNo),FRI=sum(FRI)/count(vipNo),SAT=sum(SAT)/count(vipNo),
						   SUN=sum(SUN)/count(vipNo)
 from #temp_Vip_KeDanJia_weekday
 order by vipno

')
end


GO
