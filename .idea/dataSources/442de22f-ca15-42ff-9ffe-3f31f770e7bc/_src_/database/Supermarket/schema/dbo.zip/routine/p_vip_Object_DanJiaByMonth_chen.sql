
/*
		会员件单价统计（某时间段内按月份统计）
     p_vip_Object_DanJiaByMonth_chen 'temp_delphi_last','2007-1-2','2008-12-2'
	*/

create proc p_vip_Object_DanJiaByMonth_chen
@delphiTable varchar(50),
@date1 datetime,
@date2 datetime
as
begin
    set nocount on
exec('
    if (select object_id(''tempdb..#temp_Lsdsp_VipNo''))is not null 
	begin
		drop table #temp_Lsdsp_VipNo
	end
	if (select object_id(''tempdb..#temp_VipSheet_shishou''))is not null 
	begin
		drop table #temp_VipSheet_shishou
	end
	if (select object_id(''tempdb..#temp_VipNo_sheetNo''))is not null 
	begin
		drop table #temp_VipNo_sheetNo
	end
	if (select object_id(''tempdb..#temp_KeDanJia_week''))is not null 
	begin
		drop table #temp_KeDanJia_week
	end
	if (select object_id(''tempdb..#temp_Vip_KeDanJia_weekday''))is not null 
	begin
		drop table #temp_Vip_KeDanJia_weekday
	end


	select a.VipNo,b.zdriqi,b.LsdNo,b.guizuno,b.guizu,c.shuliang,c.Spno,c.MingCheng
	into #temp_Lsdsp_VipNo
	from '+@delphiTable+' a left join lsd b
	on isnull(b.VipNO,'''')=a.VipNo
	left join lsdsp c
	on b.lsdno=c.lsdno
	where isnull(b.zdriqi ,''1900-01-01'') between'''+@date1+''' and '''+@date2+'''

	select  a.sheetNo,a.zdriqi,shishou=sum(a.shishou),shuliang=sum(b.shuliang),
	Sheet_day=datepart(day,a.zdriqi),Sheet_week=datepart(weekday,a.zdriqi),
	Sheet_Month=datepart(month,a.zdriqi)
	into #temp_VipSheet_shishou
	from jiesuan a,#temp_Lsdsp_VipNo b
	where a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)
	group by a.sheetNo,a.zdriqi


	select distinct b.vipNo,a.sheetNo,a.zdriqi,a.shishou,a.shuliang,
	a.Sheet_day,a.Sheet_week,a.Sheet_Month
	into #temp_VipNo_sheetNo
	from #temp_VipSheet_shishou a left join #temp_Lsdsp_VipNo b
	on a.sheetNo=substring(b.LsdNo,1,patindex(''%-%'',b.LsdNo)-1)


    select vipNo,Sheet_Month,KeDanJia=cast(sum(shishou) as money)/sum(shuliang)
    into #temp_KeDanJia_Month
    from #temp_VipNo_sheetNo
    group by vipNo,Sheet_Month
    order by vipNo,Sheet_Month


   create table #temp_Vip_KeDanJia_Month
    (
		vipNo varchar(50),
        JAN  money,
		FEB  money,
		MAR  money,
		APR  money,
		MAY	 money,
		JUN  money,
		JUL  money,
		AUG  money,
		SEP  money,
		OCT  money,
		NOV  money,
		[DEC]  money
	)

    insert into #temp_Vip_KeDanJia_Month
    (
      VipNo,JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,[DEC]
	)
	select distinct VipNo,0,0,0,0,0,0,0,0,0,0,0,0
    from #temp_KeDanJia_Month

	--更新1-12月数据
    --1月
    update a
    set a.JAN=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=1
    --2月
    update a
    set a.FEB=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=2
    --3月
    update a
    set a.MAR=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=3
    --4月
    update a
    set a.APR=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=4
    --5月
    update a
    set a.MAY=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=5
    --6月
    update a
    set a.JUN=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=6
    --7月
    update a
    set a.JUL=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=7
    --8月
    update a
    set a.AUG=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=8
    --9月
    update a
    set a.SEP=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=9
    --10月
    update a
    set a.OCT=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=10
    --11月
    update a
    set a.NOV=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=11
    --12月
    update a
    set a.DEC=b.KeDanJia
    from #temp_Vip_KeDanJia_Month a,#temp_KeDanJia_Month b
    where a.VipNo=b.VipNo  and b.Sheet_Month=12
    

    --select * from  #temp_Vip_KeDanJia_Month 
    select VipNo,JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,[DEC]
    from #temp_Vip_KeDanJia_Month
    union all
    select VipNo=''平均件单价'',JAN=sum(JAN)/count(vipNo),FEB=sum(FEB)/count(vipNo),MAR=sum(MAR)/count(vipNo),
                              APR=sum(APR)/count(vipNo),MAY=sum(MAY)/count(vipNo),JUN=sum(JUN)/count(vipNo),
							  JUL=sum(JUL)/count(vipNo),AUG=sum(AUG)/count(vipNo),SEP=sum(SEP)/count(vipNo),
							  OCT=sum(OCT)/count(vipNo),NOV=sum(NOV)/count(vipNo),[DEC]=sum([DEC])/count(vipNo)
    from #temp_Vip_KeDanJia_Month
    order by VipNo
')
end


GO
