/*
drop #tempPinpaino
select pinpaino
into #delp
from t_pinpai

paiPerformanceAnalyse_chen '2009-05-01','2009-05-10','#delp'

*/
create proc paiPerformanceAnalyse_chen
@dateBgn datetime,
@dateEnd datetime,
@delphiTable varchar(32)
as
exec('
if (select object_id(''tempdb..#tempRkdsp''))is not null
drop table #tempRkdsp
if (select object_id(''tempdb..#tempLsdsp''))is not null
drop table #tempLsdsp
if (select object_id(''tempdb..#tempPinpaino''))is not null
drop table #tempPinpaino
if (select object_id(''tempdb..#tempFcdsp''))is not null
drop table #tempFcdsp
if (select object_id(''tempdb..#tempRkNumber''))is not null
drop table #tempRkNumber


select * into #tempPinpaino from ' +@delphiTable+ ' 

--待统计的品牌商品入库情况
select pinpaino,InQty=sum(isnull(shuliang,0)),InMoney=sum(isnull(jinjiajine,0))
into #tempRkdsp
from v_rkdSp_PinpaiNo
where pinpaino in
(
	select pinpaino from #tempPinpaino
)
and zdriqi between '''+@dateBgn+''' and +'''+@dateEnd+'''
group by pinpaino

--待统计的品牌商品返厂情况
select pinpaino,FcQty=sum(isnull(shuliang,0)),FcMoney=sum(isnull(jinjiajine,0))
into #tempFcdsp
from v_fcdSp_PinpaiNo  
where pinpaino in
(
	select pinpaino from #tempPinpaino
)
and zdriqi between '''+@dateBgn+''' and +'''+@dateEnd+'''
group by pinpaino

--待统计的品牌商品零售情况
select pinpaino,LsQty=sum(isnull(shuliang,0)),LsMoney=sum(isnull(jine,0))
into #tempLsdsp
from v_lsdsp_pinpaiNo
where pinpaino in
(
	select pinpaino from #tempPinpaino
)
and lsriqi between '''+@dateBgn+''' and +'''+@dateEnd+'''
group by pinpaino

--品牌进货次数
select pinpaino,rkNumber=count(distinct rkdno)
into #tempRkNumber
from v_rkdSp_PinpaiNo
where zdriqi between '''+@dateBgn+''' and +'''+@dateEnd+'''
group by pinpaino

select a.pinpaino,b.pinpai,area=isnull(b.area,0),fee=isnull(b.fee,0),
InQty=isnull(c.InQty,0),InMoney=isnull(c.InMoney,0),
LsQty=isnull(d.LsQty,0),LsMoney=isnull(d.LsMoney,0),
FcQty=isnull(f.FcQty,0),FcMoney=isnull(f.FcMoney,0),
RkNumber=isnull(n.rkNumber,0)
from #tempPinpaino a left join t_pinpai b
on a.pinpaino=b.pinpaino
left join #tempRkdsp c
on a.pinpaino=c.pinpaino
left join #tempLsdsp d
on a.pinpaino=d.pinpaino
left join #tempFcdsp f
on a.pinpaino=f.pinpaino
left join #tempRkNumber n
on a.pinpaino=isnull(n.pinpaino,'''')
order by a.pinpaino

')
GO
