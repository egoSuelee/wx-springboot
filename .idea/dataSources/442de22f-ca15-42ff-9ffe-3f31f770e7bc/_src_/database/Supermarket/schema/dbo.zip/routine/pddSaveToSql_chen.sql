create proc pddSaveToSql_chen
@TableName varchar(100),
@guizuno varchar(32)
as
if (select object_id('tempdb..#tmp_rkdsp'))is not null
drop table #tmp_rkdsp
if (select object_id('tempdb..#tmp_rkdspLast'))is not null
drop table #tmp_rkdspLast
create table #tmp_rkdsp
(
        rkdno varchar(32),
        serno int,
	spno varchar(32),
	mingcheng varchar(64),
	guige varchar(32),
	dw1 varchar(32),
	danwei varchar(32),
	shuliang money,
	jinjia money,
	jinjiajine money,
	shuilv money,
	shuilvjine money,
	shoujia money,
	shoujiajine money,
	chajiajine money,
	cangkuno varchar(32),
	cangku varchar(64),
	guizuno varchar(32),
	zdriqi datetime,
	zdtime datetime,
        Type varchar(32) 

)

declare @sql varchar(8000)
select @sql =isnull(@sql + ' union all ' , '' ) + ' select rkdno,serno,spno,mingcheng,guige,dw1,danwei,jinjia,jinjiajine,shuilv,shuilvjine,
         shoujia,shoujiajine,chajiajine,cangkuno,cangku,guizuno,zdriqi,zdtime ,name= ' +
          quotename(type , '''') + ' , shuliang = ' + quotename(type) + ' from '+@TableName
from guizu_type
where guizuno=@guizuno
/*
from syscolumns 
where (name! = N'rkdno') and 
name! = N'serno' and 
name! = N'spno' and 
name! = N'mingcheng' and
name! = N'guige' and 
name! = N'dw1' and 
name! = N'danwei' and 
name! = N'shuliang' and
name! = N'jinjia' and 
name! = N'jinjiajine' and 
name! = N'shuilv' and 
name! = N'shuilvjine'  and
name! = N'shoujia' and 
name! = N'shoujiajine' and 
name! = N'chajiajine' and 
name! = N'cangkuno' and
name! = N'cangku' and
name! = N'guizuno' and 
name! = N'zdriqi' and 
name! = N'zdtime' 
and ID = object_id(@TableName) 
order by colid asc
*/
insert into #tmp_rkdsp
(rkdno,serno,spno,mingcheng,guige,dw1,danwei,jinjia,jinjiajine,shuilv,shuilvjine,
        shoujia,shoujiajine,chajiajine,cangkuno,cangku,guizuno,zdriqi,zdtime,Type,shuliang)

exec(@sql + ' order by spno ')

--select * from rkdsp_CHEN
select rkdno,serno=identity(int,1,1),spno,mingcheng,guige,dw1,danwei,jinjia,jinjiajine,shuilv,shuilvjine,
         shoujia,shoujiajine,chajiajine,cangkuno,cangku,guizuno,zdriqi,zdtime,Type,shuliang
into #tmp_rkdspLast 
from #tmp_rkdsp
--where isnull(shuliang,0)<>0

insert into pdd_sp
(
    pandian,pddno,serno,spno,mingcheng,guige,dw1,danwei,jinjia,jinjiajine,shuilv,shuilvjine,
    shoujia,shoujiajine,chajiajine,cangkuno,cangku,guizuno,zdriqi,zdtime,Type,shuliang
)
select pandian=1,rkdno,serno,spno,mingcheng,guige,dw1,danwei,jinjia,
jinjiajine=isnull(shuliang,0)*isnull(jinjia,0),shuilv,
shuilvjine=isnull(shuliang,0)*isnull(jinjia,0)*isnull(shuilv,0)/100,
    shoujia,shoujiajine=isnull(shoujia,0)*isnull(shuliang,0),
chajiajine=isnull(shoujia,0)*isnull(shuliang,0)-isnull(shuliang,0)*isnull(jinjia,0),
cangkuno,cangku,guizuno,zdriqi,zdtime,Type,shuliang
from #tmp_rkdspLast


--select * from #tmp_rkdspLast
--rkdSaveToSql_chen 'rkdsp_chen','100'
--select * from rkdsp_chen
/*
select  pandian,pddno,serno,spno,mingcheng,guige,dw1,danwei,jinjia,jinjiajine,shuilv,shuilvjine,
    shoujia,shoujiajine,chajiajine,cangkuno,cangku,guizuno,zdriqi,zdtime,Type,shuliang
from pdd_sp

select * from pdd_sp
*/
GO
