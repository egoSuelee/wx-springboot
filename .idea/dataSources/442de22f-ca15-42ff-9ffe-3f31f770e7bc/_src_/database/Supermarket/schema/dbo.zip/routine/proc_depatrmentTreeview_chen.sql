
CREATE proc [dbo].[proc_depatrmentTreeview_chen]
as
begin
    set nocount on   

	if (select object_id('tempdb..#temp_depart_Manage_chen'))is not null 
		drop table #temp_depart_Manage_chen

	create table #temp_depart_Manage_chen
	(
		departNo varchar(32),
		departName varchar(32),
		parentNO varchar(32)
	)

	--查找部门
    insert into #temp_depart_Manage_chen(departNo,departName,parentNO)
	select BumenNo,BumenMc='部门'+'['+BumenNo+']'+BumenMc,cParentNo
	from dbo.bumen
    --添加上级
--    insert into #temp_depart_Manage_chen(departNo,departName,parentNO)
--    select departNo='M.'+cManagerNo,departName='用户'+'['+cManagerNo+']'+cManager,parentNO=BumenNo
--    from pass
    --添加下级
    insert into #temp_depart_Manage_chen(departNo,departName,parentNO)
	select departNo='U.'+[User],departName='用户'+'['+[User]+']'+[Name],parentNO=BumenNo
    from pass

	insert into #temp_depart_Manage_chen(departNo,departName,parentNO)
    values('--','所有部门员工信息','All')

	
    select departNo,departName,parentNO 
	from #temp_depart_Manage_chen
    order by departNO

end


GO
