  CREATE   procedure refresh_lsd_jiesuan   
  as   
  begin   
    declare @zdriqi_max datetime    
    select @zdriqi_max=case when max(zdriqi) is null then getdate() else  max(zdriqi) end
    from jiesuan   
    insert into lsd (  
     vipno,daogouyuanno,daogouyuan,guizu,guizuno,lsdno,kehu,kehuno,zdriqi,xstime,xsy,xsyno,yingshou,mlt,shishou) 
    select vipno,daogouyuanno,daogouyuan,guizu,guizuno,lsdno,kehu,kehuno,zdriqi,xstime,xsy,xsyno,yingshou,mlt,shishou
    from lsd_oneday  
  	where  zdriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate())            
  	and lsdno not in (select lsdno from lsd where zdriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate())) 
    update lsd_oneday set jiecun=1 where  isnull(jiecun,0)=0 
    insert into lsdsp (    
    taxirate,ojine,tjine,daogouyuanno,daogouyuan,chongjian,hyzhekoulv,lstime,lsriqi,lsdno,spno,mingcheng,pnumber,danwei,guige,guizu,guizuno,danjia,
     shuliang,zhongliang,yingshou,zhekou,zhekoulv,jine,chengben,lirun,beizhu)                                                     
    select taxirate,ojine,tjine,daogouyuanno,daogouyuan,chongjian,hyzhekoulv,lstime,lsriqi,lsdno,spno,mingcheng,pnumber,danwei,guige,guizu,guizuno,danjia,
     shuliang,zhongliang,yingshou,zhekou,zhekoulv,jine,chengben,lirun,beizhu
    from lsdsp_oneday
  	where  lsriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate())     
  	and lsdno not in (select lsdno from lsdsp where lsriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate())) 
    update lsdsp_oneday set jiecun=1 where  isnull(jiecun,0)=0
    insert into  jiesuan (detail,orientmoney,leftmoney,storevalue,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi)
     select detail,orientmoney,leftmoney,storevalue,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi
       from jiesuan_oneday 
  	where zdriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate())
  	and sheetno not in (select sheetno from  jiesuan where zdriqi between dbo.getdaystr(getdate()-30) and dbo.getdaystr(getdate()))
    update jiesuan_oneday set  jiecun=1 where   isnull(jiecun,0)=0 
  end
  GO
