/*
refresh_lsd_jiesuan_today 7

select * from lsd_oneday  where zdriqi='2009-07-01'
select * from jiesuan_byguizu  where zdriqi='2009-07-01'
*/
CREATE       procedure [dbo].[refresh_lsd_jiesuan_today]
  @iDays int   
  as   
  begin
    update a set a.cangkuno=b.cangkuno
    from lsd_oneday a,posstation b
	  where a.zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate()) 
    and isnull(jiecun,0)=0 
    and isnull(dbo.trim(a.cangkuno),'')='' 
		and substring(lsdno,1,2)=b.posid

    update a set a.cangkuno=b.cangkuno
    from lsdsp_oneday a,posstation b
	  where a.lsriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate()) 
    and isnull(jiecun,0)=0 
    and isnull(dbo.trim(a.cangkuno),'')='' 
		and substring(lsdno,1,2)=b.posid

    update a set a.cangkuno=b.cangkuno
    from jiesuan_oneday a,posstation b
	  where a.zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate()) 
    and isnull(jiecun,0)=0 
    and isnull(dbo.trim(a.cangkuno),'')='' 
		and substring(sheetno,1,2)=b.posid
		
    update a set a.cangkuno=b.cangkuno
    from jiesuan_byguizu a,posstation b
	  where a.zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate()) 
    and isnull(dbo.trim(a.cangkuno),'')='' 
		and substring(sheetno,1,2)=b.posid

    declare @zdriqi_max datetime    
    select @zdriqi_max=case when max(zdriqi) is null then getdate() else  max(zdriqi) end
    from jiesuan   
    insert into lsd (  
    fVipScore,cangkuno,vipno,daogouyuanno,daogouyuan,guizu,guizuno,lsdno,kehu,kehuno,zdriqi,xstime,xsy,xsyno,yingshou,mlt,shishou) 
 
    select fVipScore,cangkuno,vipno,daogouyuanno,daogouyuan,guizu,guizuno,lsdno,kehu,kehuno,zdriqi,xstime,xsy,xsyno,yingshou,mlt,shishou
    from lsd_oneday  
  	where  zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate())            
  	and lsdno not in (select lsdno from lsd where zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate())) 

    update lsd_oneday set jiecun=1 where  isnull(jiecun,0)=0 



    insert into lsdsp ( lsdNo_canceled,   
    cangkuno,taxirate,ojine,tjine,daogouyuanno,daogouyuan,chongjian,hyzhekoulv,lstime,lsriqi,lsdno,spno,mingcheng,pnumber,danwei,guige,guizu,guizuno,danjia,
     shuliang,zhongliang,yingshou,zhekou,zhekoulv,jine,chengben,lirun,beizhu)                                                     
    select lsdNo_canceled, cangkuno,taxirate,ojine,tjine,daogouyuanno,daogouyuan,chongjian,hyzhekoulv,lstime,lsriqi,lsdno,spno,mingcheng,pnumber,danwei,guige,guizu,guizuno,danjia,
     shuliang,zhongliang,yingshou,zhekou,zhekoulv,jine,chengben,lirun,beizhu
    from lsdsp_oneday
  	where  lsriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate())     
  	and lsdno+'ZZ'+Pnumber not in (select lsdno+'ZZ'+Pnumber from lsdsp where lsriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate())) 
 
    update lsdsp_oneday set jiecun=1 where  isnull(jiecun,0)=0



    insert into  jiesuan (cangkuno,detail,orientmoney,leftmoney,storevalue,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi)
     select cangkuno,detail,orientmoney,leftmoney,storevalue,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi
       from jiesuan_oneday 
  	where zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate())
  	and sheetno not in (select sheetno from  jiesuan where zdriqi between dbo.getdaystr(getdate()-@iDays) and dbo.getdaystr(getdate()))
    update jiesuan_oneday set  jiecun=1 where   isnull(jiecun,0)=0 
  end


GO
