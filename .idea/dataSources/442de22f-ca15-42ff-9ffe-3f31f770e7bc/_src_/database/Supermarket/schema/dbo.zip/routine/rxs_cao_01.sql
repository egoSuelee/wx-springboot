
/*
exec rxs_cao_01 
@stime='2011-10-01 00:00:00',@etime='2011-10-09 00:00:00',@time='2011-10-02 00:00:00'
,@quno='admin'
exec rxs_cao 
@stime='2011-10-01 00:00:00',@etime='2011-10-09 00:00:00',@time='2011-10-02 00:00:00'
,@quno='@@@@,@@4@@,@@401@@,@@402@@,@@404@@,@@@@,@@@@'
,@quno='@@402@@,@@301@@,@@30102@@,@@3010201@@,@@3010202@@,@@30101@@,@@3010101@@,@@3010102@@,@@30105@@,@@30103@@,@@3010302@@,@@3010301@@,@@30104@@,@@4@@,@@401@@,@@404@@,@@@@,@@@@'

*/
create procedure [dbo].[rxs_cao_01]
@stime datetime,     ----月查询起始时间
@etime datetime,     ----月查询结束时间，当日时间
@time datetime,      ----上周本日时间
@quno varchar(64)--, ----区no
--@tablename varchar(100)      ----报表数据需要类型
as 
begin
if (select object_id('tempdb..#tempQu'))is not null drop table #tempQu 
create table #tempQu (guizuno varchar(32) null)
exec(
'
if(select object_id(''Temp_SupKey.dbo.temp_TypeTree'+@quno+''')) is null
create table Temp_SupKey.dbo.temp_TypeTree'+@quno+' (guizuno varchar(32) null)
insert into #tempQu select guizuno as quno  from Temp_SupKey.dbo.temp_TypeTree'+@quno+'
')
if(select object_id('tempdb..#qu001')) is not null drop table #qu001
   select peoplenum=COUNT(lsdno),jinrimoney=SUM(Shishou),a.guizuno,a.guizu ,b.qu,b.quno 
   into #qu001
   from dbo.lsd a left join guizu b on a.guizuno=b.guizuno 
   where Zdriqi=@etime group by a.guizuno,a.guizu,b.qu,b.quno

if(select object_id('tempdb..#huanbi')) is not null drop table #huanbi
   select peoplenum=COUNT(lsdno),jinrimoney=SUM(Shishou),a.guizuno,a.guizu ,b.qu,b.quno 
   into #huanbi
   from dbo.lsd a left join guizu b on a.guizuno=b.guizuno 
   where Zdriqi=@time group by a.guizuno,a.guizu,b.qu,b.quno
  
if(select object_id('tempdb..#qu001_1')) is not null drop table #qu001_1
   select quno,qu,ren=SUM(peoplenum),qian=SUM(jinrimoney) 
   into #qu001_1 
   from #qu001 where quno in (select guizuno from #tempQu)
   group by quno,qu order by quno

if(select object_id('tempdb..#huan_1')) is not null drop table #huan_1
   select quno,qu,ren=SUM(peoplenum),qian=SUM(jinrimoney) 
   into #huan_1 
   from #huanbi where quno in (select guizuno from #tempQu)
   group by quno,qu order by quno

if(select object_id('tempdb..#qu')) is not null drop table #qu
   select a.*,huanbi=b.qian,beizhu=b.qu
   into #qu --select * from #qu
   from #qu001_1 a left join #huan_1 b
   on a.quno=b.quno

if(select object_id('tempdb..#bb')) is not null drop table #bb
   select quno,qu,ren,qian,huanbi=(isnull(huanbi,0)),beizhu
   into #bb
   from #qu where quno in (select guizuno from #tempQu)
   
update #bb set huanbi=(qian-huanbi)*100/(huanbi+1)
   
if(select object_id('tempdb..#bb1')) is not null drop table #bb1
   select quno,qu,ren,qian,huanbi=(CONVERT(varchar(32),huanbi)+'%') 
   into #bb1 
   from #bb

if(select object_id('tempdb..#rxs')) is not null drop table #rxs
   create table #rxs(quno varchar(32),qu varchar(32),ren int ,qian money ,bili real,huanbi varchar(32) )

if(select object_id('tempdb..#大厦合计')) is not null drop table #大厦合计
  select distinct guizuno 
  into #大厦合计 
  from dbo.guizu 
  where quno in (select guizuno from #tempQu)
  
  select qian=sum(a.qian),ren=sum(a.ren),kdj=SUM(qian)/SUM(ren)
  into #bili  
  from (
      select ren=count(lsdno),qian=SUM(Jine) 
      from dbo.lsdsp 
      where Lsriqi=@etime and 
      guizuno in (select distinct guizuno from #大厦合计) 
      group by guizuno
      )a

  insert #rxs (quno,qu,ren,qian,bili,huanbi)
  select a.quno,a.qu,a.ren,a.qian,bili=a.qian*100/(b.qian),huanbi 
  from #bb1 a , #bili b
   --select sum(bili) from #rxs
if(select object_id('tempdb..#rxs1')) is not null drop table #rxs1
  select quno,qu,ren,qian,bili=(CONVERT(varchar(32),bili)+'%'),huanbi into #rxs1  from #rxs
   
if(select object_id('tempdb..#cc')) is not null drop table #cc
  select distinct lc=SUBSTRING(quno,1,1) into #cc from #rxs1

  update #rxs1 set quno=SUBSTRING(quno,1,1)

  select b.diqumc,a.qu,a.qian,a.bili,a.huanbi 
  from #rxs1 a left join (
  select a.*,b.diqumc 
  from #cc a left join dbo.diqu b
  on a.lc=b.diquno where b.cParentNo='--') b
  on a.quno=b.lc
-----------------------------------------------------------------月大厦合计
if(select object_id('tempdb..#月大厦合计')) is not null drop table #月大厦合计
	
select distinct guizuno into #月大厦合计 
from dbo.guizu where quno in (select guizuno from #tempQu)
   
select qian=sum(a.qian),ren=sum(a.ren),kdj=SUM(qian)/SUM(ren)  from (
      select ren=count(lsdno),qian=SUM(Jine) 
      from dbo.lsdsp 
      where Lsriqi between @stime and @etime and 
      guizuno in 
      (select distinct guizuno from #月大厦合计
      ) 
      group by guizuno
      )a
-------------------------------------------------------------------------大厦合计
select qian=sum(a.qian),ren=sum(a.ren),kdj=SUM(qian)/SUM(ren)  from (
      select ren=count(lsdno),qian=SUM(Jine) 
      from dbo.lsdsp 
      where Lsriqi=@etime and 
      guizuno in 
      (select distinct guizuno from #大厦合计
      ) 
      group by guizuno
      )a
------------------------------------------------------------------------时间段
   if(select object_id('tempdb..#sjd')) is not null
	begin
		drop table #sjd
	end
   create table #sjd(sj varchar(32),ren int,qian money,leiji money) 
   declare @sjd int
   declare @leiji money
   declare @money money
   declare @ren int
   declare @sj varchar(1000)
   set @sjd=9
   set @leiji=0
   set @money=0
   set @ren=0
   
if(select object_id('tempdb..#aaaa')) is not null drop table #aaaa
select distinct guizuno into #aaaa from dbo.guizu where quno in (select guizuno from #tempQu)
 
   while @sjd<22
   begin
      select @ren=sum(a.ren),@money=sum(a.qian)  from (
      select ren=count(lsdno),qian=SUM(Jine) 
      from dbo.lsdsp 
      where Lsriqi=@etime and DATEPART(hh,lstime)=@sjd and 
      guizuno in 
      (select distinct guizuno from #aaaa
      ) 
      group by guizuno
      )a
      set @leiji=@leiji+@money
      set @sj=CONVERT(char(2),@sjd)+':00-'+CONVERT(char(2),@sjd+1)+':00'
      insert into #sjd(sj,ren,qian,leiji)values(@sj,@ren,@money,@leiji)
      set @sjd=@sjd+1
   end
   select * from #sjd
end
GO
