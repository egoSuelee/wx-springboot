




create PROCEDURE [dbo].[sp_GetRows]
	@tblName        varchar(255),       -- 表名
	@fldName        varchar(1000),      -- 所要提取的字段名
	@OrderByfldName varchar(255),       -- 排序所依据的字段名
	@OrderType      int = 0,            -- 设置排序类型,默认0为升序，非0为降序
	@PageSize       int = 10,           -- 每页显示的记录数
	@PageIndex      int = 1,            -- 页码
	@strWhere       varchar(1000)='1=1' -- 查询条件 (注意: 不要加 where)
     --   @strWhere  int =1=1
AS

declare @strSQL   varchar(6000)       -- 主语句

if @OrderType != 0	begin
	set @strSQL='SELECT * FROM (SELECT ROW_NUMBER() OVER(order by '+@OrderByfldName+' desc) AS pos,'+@fldName+' FROM ['+@tblName+'] where '+@strWhere+') AS sp WHERE pos BETWEEN '+str((@PageIndex-1)*@PageSize+1)+' AND '+str(@PageIndex*@PageSize)
end 
else begin
	set @strSQL='SELECT * FROM (SELECT ROW_NUMBER() OVER(order by '+@OrderByfldName+' asc) AS pos,'+@fldName+' FROM ['+@tblName+'] where '+@strWhere+') AS sp WHERE pos BETWEEN '+str((@PageIndex-1)*@PageSize+1)+' AND '+str(@PageIndex*@PageSize)
end
exec(@strSQL)


GO
