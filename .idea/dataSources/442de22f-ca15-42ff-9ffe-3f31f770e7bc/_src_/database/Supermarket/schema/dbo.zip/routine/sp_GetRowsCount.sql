

Create proc [dbo].[sp_GetRowsCount]
@tblName      varchar(255),       -- 表名
@strWhere     varchar(1000) = '1=1'  -- 查询条件 (注意: 不要加 where)
as
	declare @strSql varchar(6000) --查询语句
	set @strSql='select count(*) as Total from ['+@tblName+'] where '+@strWhere
	exec (@strSql)

GO
