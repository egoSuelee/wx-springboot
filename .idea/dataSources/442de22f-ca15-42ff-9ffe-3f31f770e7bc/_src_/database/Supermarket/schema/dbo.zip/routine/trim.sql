
create  function trim
(@str varchar(1000)) returns varchar(1000)
as
begin
  return ltrim(rtrim(@str))
end

GO
