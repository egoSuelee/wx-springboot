
CREATE TRIGGER T_IN_spxx 
ON spxx 
FOR INSERT 
AS 
--提交事务处理 
BEGIN TRANSACTION 
--强制执行下列语句，保证业务规则 
declare @spno varchar(32)
declare @isnull varchar(32)
set @isnull=null
set @spno=null
	select @spno=spno from inserted where SpNo not in(Select SpNo from Deleted)
    select @isnull=spno from spxx_WaitSend where spno=@spno
		if(@isnull is null)
		begin
			insert into spxx_WaitSend(spno,binserted,download) values(@spno,1,1)  --- 未上传 的download 为1
		end
COMMIT TRANSACTION
GO
