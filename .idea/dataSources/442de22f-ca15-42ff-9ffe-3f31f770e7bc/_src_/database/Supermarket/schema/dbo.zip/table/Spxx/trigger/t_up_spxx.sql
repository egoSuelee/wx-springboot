Create Trigger t_up_spxx
On Spxx                         --在Spxx表中创建触发器 
for Update                          --为什么事件触发 
As                                        --事件触发后所要做的事情           
begin 
	declare @spno varchar(32)
	declare @isnull varchar(32)
	set @isnull=null
	set @spno=null
    select @spno=spno from deleted
    if(@spno is not null)
    begin
		select @isnull=spno from spxx_WaitSend where spno=@spno
		if(@isnull is null)
		begin
		insert into spxx_WaitSend(spno,bupdated,download) values(@spno,1,1)  --- 未上传 的download 为1
		end
    end
end
GO
