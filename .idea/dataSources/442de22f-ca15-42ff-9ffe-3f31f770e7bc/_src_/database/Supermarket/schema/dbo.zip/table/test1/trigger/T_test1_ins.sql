CREATE TRIGGER [T_test1_ins] ON [dbo].[test1] 
FOR INSERT
AS
declare @col1 varchar(32),@col2 money ,@col3 money
select @col1=ins.col1, @col2=ins.col2, @col3=ins.col3 from inserted ins
insert into test2 (col1,col2,col3)
values (@col1,@col2,@col3)
GO
