CREATE TRIGGER [T_test1_update] ON [dbo].[test1] 
FOR  UPDATE
AS
declare @col1 varchar(32),@col2 money ,@col3 money
select @col1=upd.col1, @col2=upd.col2, @col3=upd.col3 from inserted upd
update  test2  set test2.col2=test2.col2+10
--update  test2  set test2.col2=test2.col2+@col2-test1.col2
--from test1
--where test2.col1=@col1 and test1.col1=@col1
GO
