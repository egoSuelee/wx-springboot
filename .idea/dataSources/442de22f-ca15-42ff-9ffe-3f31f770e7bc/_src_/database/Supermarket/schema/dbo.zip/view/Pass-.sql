
CREATE view [dbo].[Pass]
as
select 

[User],[Name],[Pass],[Right],
[Ki],[quanxian],userType=userType_MP,[RightPrint],
[RightQuery],[RightOutPut],[RightUpate],
[RightDelete],[RightInsert],[BumenMc],
[BumenNo],[cManagerNo],[cManager],[bManager]

from posmanagement.dbo.t_Pass


GO
