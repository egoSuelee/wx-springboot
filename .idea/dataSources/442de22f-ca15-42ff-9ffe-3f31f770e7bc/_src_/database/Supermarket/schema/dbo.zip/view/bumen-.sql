create view bumen
as
select
	BumenNo=cDeptNo ,
	BumenMc=cDept,
	cEmployeeNo,
	cManager,
	cTel,
	cMobile,
	cFax,
	bExecute,
	Kouling,
	cParentNo,
	deposit
from Posmanagement.dbo.t_department


/*
CREATE TABLE [dbo].[t_department](
	[cDeptNo] [varchar](32) NOT NULL,
	[cDept] [varchar](64) NULL,
	[cEmployeeNo] [varchar](32) NULL,
	[cManager] [varchar](16) NULL,
	[cTel] [varchar](64) NULL,
	[cMobile] [varchar](64) NULL,
	[cFax] [varchar](64) NULL,
	[cParentNO] [varchar](32) NULL,
	[bExecute] [bit] NULL
*/
GO
