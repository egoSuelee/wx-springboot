
CREATE view [dbo].[card]
as
select cWeixinID,
cardno=cVipno, cardtype, name=cVipName, sex=cSex, birthday=dBirthday, date1=dValidStart, date2=dValidEnd, 
danwei, zhiwu=cWorkUnit, home=cHome, tel=cTel, beizhu, yhl=fPFrate, curvalue=fCurValue, 
fCurValue_MP,curvalue_pos=fCurValue_Pos, usehyj=bVipPrice, store=cStoreNo, tiaoma,dazhe=bDiscount, 
bChoujiang, dazhe_old, yhl_old, date1_old, date2_old,tijiao, 
Marks_his,
--fMoney_Ret_Sum,fMoney_Ret_Sum_Cust,
cZoneNo,cZoneName,cPsw,fMoney_sum,fMoney_used,fMoney_Left,
fMoney_POS,fMoney_MP,fMoneyLimit_POS,fMoneyLimit_MP,fMoneyLimit_Init,dMoneyLimit1,dMoneyLimit2,
fMoneyLimit_Init_Left,fMoney_PosUsedPer,fMoney_MpUsedPer,fCurValue_MP_Activity,fCurValue_Pos_Activity,
dCurValue_MP_Activity,dCurValue_Pos_Activity,

cOperater_Last,
本次积分返现扣分,本次积分返现金额,本次积分返现操作记录,bConsumeOnVipScore,
cVipNo_Parent,
  fMoney_Ret_Sum , --累计返现
  
   fMoney_Ret_waiting ,--本次待返现
   fMoney_Ret_Sum_Left,
   bMoney_LastRet ,--是否返现
   dMoney_LastRet ,--最近一次返现日期
   fMoney_Ret_Sum_cust,--累计返现消费
   fValue_MP_LastRetSub_sum ,  --百货累计返现减分
   fValue_POS_LastRetSub_sum ,  --超市累计返现减分
   fValue_MP_LastRetSub ,  --最近百货返现减分
   fValue_POS_LastRetSub --最近超市返现减分

from Posmanagement_main.dbo.t_vip


GO
