Create view ele_tmp_DELL as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='AT200704100002')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like 'AT200704100002%' and b.sheetno='AT200704100002'
where a.lsdno like 'AT200704100002%'
GO
