Create view ele_tmp_PC05 as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='AE200511080033')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like 'AE200511080033%' and b.sheetno='AE200511080033'
where a.lsdno like 'AE200511080033%'
GO
