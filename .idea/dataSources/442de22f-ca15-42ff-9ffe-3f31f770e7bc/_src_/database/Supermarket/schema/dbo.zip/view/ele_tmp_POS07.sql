Create view ele_tmp_POS07 as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='25201105170291')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like '25201105170291%' and b.sheetno='25201105170291'
where a.lsdno like '25201105170291%'
GO
