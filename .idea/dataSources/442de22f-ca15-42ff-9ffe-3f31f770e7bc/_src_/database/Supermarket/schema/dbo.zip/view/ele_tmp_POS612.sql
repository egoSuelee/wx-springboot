Create view ele_tmp_POS612 as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='72201105120001')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like '72201105120001%' and b.sheetno='72201105120001'
where a.lsdno like '72201105120001%'
GO
