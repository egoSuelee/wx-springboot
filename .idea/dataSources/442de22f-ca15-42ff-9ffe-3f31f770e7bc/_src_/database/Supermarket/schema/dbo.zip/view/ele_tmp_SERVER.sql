Create view ele_tmp_SERVER as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='09200911250002')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like '09200911250002%' and b.sheetno='09200911250002'
where a.lsdno like '09200911250002%'
GO
