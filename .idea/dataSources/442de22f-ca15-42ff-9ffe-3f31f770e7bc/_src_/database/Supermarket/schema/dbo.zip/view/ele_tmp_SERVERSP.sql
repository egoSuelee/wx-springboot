Create view ele_tmp_SERVERSP as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno='AB200501090132')
 from lsdsp_oneday a left join jiesuan_oneday b 
on a.lsdno like 'AB200501090132%' and b.sheetno='AB200501090132'
where a.lsdno like 'AB200501090132%'
GO
