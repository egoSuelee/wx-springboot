CREATE view t_Goods
as
select cGoodsNo=a.SpNo,cGoodsName=a.Mingcheng,cProductNo=a.SpNo,cBarcode=a.spno,
cGoodsTypeNo=b.cGoodsTypeno,cGoodsTypename=b.cGoodsTypename,cUnit=a.Danwei,cSpec=a.guige,
fNormalPrice=a.Bzlsj,cSupNo=a.guizuno,cSupName=a.guizu
from spxx a,t_GoodsType b
where a.kind=b.cGoodsTypeno
GO
