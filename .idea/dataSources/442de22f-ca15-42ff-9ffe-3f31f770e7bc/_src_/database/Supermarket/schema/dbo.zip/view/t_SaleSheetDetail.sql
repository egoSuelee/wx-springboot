create view t_SaleSheetDetail
as
select
dSaleDate=a.Lsriqi, cSaleSheetno=a.lsdno, iSeed=a.Pnumber, 
cGoodsNo=a.SpNo, cGoodsName=a.Mingcheng, cBarCode=a.SpNo, 
cOperatorno=b.xsyno, cOperatorName=b.xsy, cVipCardno=b.kehuno,  
 fVipScore=a.Danjia, fPrice=a.Danjia, fNormalSettle=a.Jine, 
  fVipPrice=a.Danjia, 
 fQuantity=a.Shuliang, fLastSettle0=a.Jine, fLastSettle=a.Jine, 
  cSaleTime=a.lstime, dFinanceDate=a.lsriqi, 
  cVipNo=b.kehuno, cWHno=b.cangkuno, fNormalVipScore=a.Danjia
from lsdsp a,lsd b
where a.Lsriqi=b.Zdriqi and a.lsdno=b.lsdno
GO
