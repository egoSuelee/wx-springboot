CREATE VIEW dbo.temp2
AS
SELECT sheetno, SUM(shishou) AS shishou
FROM dbo.jiesuan_byguizu a
WHERE (zdriqi BETWEEN '2004-11-27' AND '2004-12-5')
GROUP BY sheetno
GO
