CREATE view test_1
as
select a.spno,a.guizuno,a.guizu,b.sheetno,b.detail,b.shishou,
  detail_jine=b.shishou*a.jine/(select sum(shishou) from jiesuan_oneday  where sheetno like a.lsdno+'%')
 from lsdsp a left join jiesuan b 
on a.lsdno like b.sheetno+'%' 
where a.lsriqi between '2005-01-01' and '2005-01-09' and datalength(a.spno)=5 and a.spno in (select spno from ele_shangpin)--and a.lsdno like '''+trim(edt_sheetno.text)+'%''');
GO
