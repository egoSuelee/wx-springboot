create view tmp_all
as
select a.sheetno,shishou_a=a.shishou,shishou_b=b.shishou from temp1 a join temp2 b on a.sheetno=b.sheetno and a.shishou<>b.shishou
GO
