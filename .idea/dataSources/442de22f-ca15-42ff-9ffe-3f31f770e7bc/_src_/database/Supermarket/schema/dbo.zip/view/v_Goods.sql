
CREATE  view v_Goods
as
	select cGoodsNo=a.spno,cGoodsName=a.mingcheng,cUnitedNo=a.Belong,cProductNo=a.Belong,
	cBarCode=a.Tiaoma,GoodsName_Pdt=b.mingcheng,GoodsNo_Pdt=a.spno,Qty=1,BasePrice=a.Bzlsj,
	ProductedPrice=a.Bzlsj,bStorage=a.selected
	from spxx a left join spxx b on a.belong=b.spno
--	where isnull(a.selected,0)=1

GO
