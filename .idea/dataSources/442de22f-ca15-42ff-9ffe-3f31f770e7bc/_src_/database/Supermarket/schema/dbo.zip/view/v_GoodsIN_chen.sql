/*
所有入的单据 无需检查出库情况，可以一直入
select * from v_GoodsIN_chen
*/
CREATE view v_GoodsIN_chen
as
--入库单 select * from rkd_sp select * from rkd
select distinct SheetType='采购入库单',TypeNo=0,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.rkdno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from rkd_sp a,rkd b,spxx c
where a.rkdno=b.rkdno and a.spno=c.spno
and isnull(b.bAccount,0)<>1
--调拨入库单
union all
select distinct SheetType='调拨入库单',TypeNo=1,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.jcdno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from jcd_sp a,jcd b,spxx c
where a.jcdno=b.jcdno and a.spno=c.spno
and isnull(b.bAccount,0)<>1
union all
--syd
select distinct SheetType='损溢单(溢)',TypeNo=2,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.sydno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from syd_sp a,syd b,spxx c
where a.sydno=b.sydno and a.spno=c.spno and isnull(a.shuliang,0)<0
and isnull(b.bAccount,0)<>1
union all
--成品入库单
select distinct SheetType='成品入库单',TypeNo=3,b.dDate,zdtime=cast(b.ctime as datetime),guizu='成品入库,无柜组',
cSheetno=a.cSheetNo,a.cGoodsNo,a.cGoodsName,a.iLineNo,cangku=b.cWhNo+' '+b.cWh,c.Selected,b.cWhNo
from wh_PackDetail a,wh_Divide b,spxx c
where a.cSheetNo=b.cSheetNo and a.cGoodsNo=c.spno
and isnull(b.bAccount,0)<>1


GO
