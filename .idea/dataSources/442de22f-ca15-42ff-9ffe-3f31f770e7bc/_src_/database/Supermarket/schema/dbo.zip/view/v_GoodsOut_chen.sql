/*
出库单据 

select * from v_GoodsOut_chen order by zdriqi,zdtime
*/
CREATE view v_GoodsOut_chen
as
------------------------------------------------------------------
--入
select SheetType,TypeNo,zdriqi,zdtime,guizu,cSheetno,spno,mingcheng,serno,cangku,Selected,cangkuno
from v_GoodsIN_chen


------------------------------------------------------------------
union all
--出
--ckd
select distinct SheetType='出库单',TypeNo=4,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.ckdno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from ckd_sp a,ckd b,spxx c
where a.ckdno=b.ckdno and a.spno=c.spno
and isnull(b.bAccount,0)<>1

union all
--fcd
select distinct SheetType='返厂单',TypeNo=5,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.fcdno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from fcd_sp a,fcd b,spxx c
where a.fcdno=b.fcdno and a.spno=c.spno
and isnull(b.bAccount,0)<>1

union all
--syd
select distinct SheetType='损溢单(损)',TypeNo=6,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.sydno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from syd_sp a,syd b,spxx c
where a.sydno=b.sydno and a.spno=c.spno and isnull(a.shuliang,0)>0
and isnull(b.bAccount,0)<>1

union all
--dbd
select distinct SheetType='调拨出库单',TypeNo=7,a.zdriqi,zdtime=cast(a.zdtime as datetime),guizu=b.guizuno+' '+b.guizu,
cSheetno=a.dbdno,a.spno,a.mingcheng,a.serNo,cangku=a.cangkuno+' '+a.cangku,c.Selected,a.cangkuno
from dbd_sp a,dbd b,spxx c
where a.dbdno=b.dbdno and a.spno=c.spno
and isnull(b.bAccount,0)<>1

union all
--原料出库单
select distinct SheetType='原料出库单',TypeNo=8,b.dDate,zdtime=cast(b.ctime as datetime),guizu='原料出库,无柜组',
cSheetno=a.cSheetNo,a.cGoodsNo,a.cGoodsName,a.iLineNo,cangku=b.cWhNo+' '+b.cWh,c.Selected,b.cWhNo
from wh_PackDetail a,wh_Pack b,spxx c
where a.cSheetNo=b.cSheetNo and a.cGoodsNo=c.spno
and isnull(b.bAccount,0)<>1


GO
