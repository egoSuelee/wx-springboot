
CREATE view [dbo].[v_Module_userType]
as
select userTypeno, userType, ModuleNo, ModuleName
--from posmanagement.dbo.t_Module_userType
from t_Module_userType

GO
