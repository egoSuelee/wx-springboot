create view dbo.v_Modules
as
select ModuleNo, ModuleName, ModuleNo_Parent, TreeParentNo, bMainMenuItem,
 bActive, photo, photoType, width, height, bHide
from posmanagement.dbo.t_Modules
GO
