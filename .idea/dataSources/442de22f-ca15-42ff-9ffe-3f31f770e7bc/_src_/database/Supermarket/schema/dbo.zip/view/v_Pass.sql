
CREATE view [dbo].[v_Pass]
as
select [User], Name, Pass, [Right],
Ki, quanxian,
 userType, cManagerNo, cManager, bManager, 
 BumenNo, BumenMc, blookjj=cast(1 as bit), bLockJJ=cast(1 as bit), cIME=''
from dbo.Pass
 
--from posmanagement.dbo.t_Pass
GO
