create view v_SheetAll_chen
as

select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=0,
typeName='采购入库单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=rkdno,
cWhNo=cangkuno,Wh=cangkuno+' '+cangku,gz=guizuno+' '+guizu,iGroupNo=0
from rkd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=1,
typeName='调拨入库单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=jcdno,
cWhNo=cangkuno,Wh=cangkuno+' '+cangku,gz=guizuno+' '+guizu,iGroupNo=0
from jcd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=2,
typeName='损溢单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=sydno,
cWhNo=cangkuno,Wh=cangkuno+' '+cangku,gz=guizuno+' '+guizu,iGroupNo=0
from syd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(bExamin,0),bAccount=isnull(bAccount,0),typeNo=3,
typeName='成品入库单',dDate,cTime,cSheetNo,
cWhNo,Wh=cWhNo+' '+cWh,gz='成品入库,无柜组',iGroupNo=0
from wh_Divide
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=4,
typeName='出库单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=ckdno,
cWhNo=cangkuno,Wh=cangkuno+' '+cangku,gz=guizuno+' '+guizu,iGroupNo=1
from ckd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=5,
typeName='返厂单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=fcdno,
cWhNo=cangkuno,Wh=cangkuno+' '+cangku,gz=guizuno+' '+guizu,iGroupNo=1
from fcd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(shenhe,0),bAccount=isnull(bAccount,0),typeNo=7,
typeName='调拨出库单',dDate=zhidanriqi,cTime=zdtime,cSheetNo=dbdno,
cWhNo=cangkuno_s,Wh=cangkuno_s+' '+cangku_s,gz=guizuno+' '+guizu,iGroupNo=1
from dbd
--where isnull(bAccount,0)<>1

union all
select bExamin=isnull(bExamin,0),bAccount=isnull(bAccount,0),typeNo=8,
typeName='原料出库单',dDate,cTime,cSheetNo,
cWhNo,Wh=cWhNo+' '+cWh,gz='原料出库,无柜组',iGroupNo=1
from wh_Pack
--where isnull(bAccount,0)<>1


GO
