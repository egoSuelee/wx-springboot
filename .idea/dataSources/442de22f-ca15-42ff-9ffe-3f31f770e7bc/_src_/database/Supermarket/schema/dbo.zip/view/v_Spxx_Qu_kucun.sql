

CREATE        view v_Spxx_Qu_kucun
as
select a.spno,a.Mingcheng,b.guizuNo,b.guizu,quno=c.diquno,qu=c.diqumc,fRatio=isnull(fRatio,0),
			 d.jingyingfangshi,cGoodsTypeno=a.kind,g.cGoodsTypename
from spxx a 
left join guizu b on a.guizuno=b.guizuno
left join dbo.shanghu_hetong d on a.guizuno=d.guizuno
left join diqu c on b.quno=c.diquno
left join 
(select guizuno,fRatio=max(fRatio) from Shanghu_hetong_Ratio group by guizuno
) f  on b.guizuno=f.guizuno
left join t_GoodsType g on a.kind=g.cGoodsTypeno
--where isnull(a.theValue,0)=0 and dbo.trim(isnull(a.selected,'0'))='1'
where dbo.trim(isnull(a.selected,'0'))='1'


GO
