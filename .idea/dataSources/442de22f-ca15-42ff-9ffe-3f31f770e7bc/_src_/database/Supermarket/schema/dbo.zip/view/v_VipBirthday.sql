	create view [dbo].[v_VipBirthday]
	as
	select 
		*,
		yourbirthday=

		case when (datepart(month,birthday)<datepart(month,getdate()))
		then
			dbo.trim(cast((datepart(year, getdate())+1) as varchar(16)))+'-'+datename(month, birthday)+'-'+datename(day, birthday)
		else
		  case when (datepart(month,birthday)=datepart(month,getdate())) and datepart(day, birthday)<datepart(day, getdate())
		  then
				dbo.trim(cast((datepart(year, getdate())+1) as varchar(16)))+'-'+datename(month, birthday)+'-'+datename(day, birthday)
		  else
				dbo.trim(cast((datepart(year, getdate())) as varchar(16)))+'-'+datename(month, birthday)+'-'+datename(day, birthday)
		  end
		end

		from card
		where ISDATE(birthday)=1 and (birthday is not null)


  GO
