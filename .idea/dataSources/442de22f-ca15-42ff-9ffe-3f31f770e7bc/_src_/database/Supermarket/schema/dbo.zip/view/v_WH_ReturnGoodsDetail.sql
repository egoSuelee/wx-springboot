

/*
select * from wh_CheckWhDetail
--drop view wh_CheckWhDetail
*/


CREATE   view v_WH_ReturnGoodsDetail
as
	select cSheetno=null,cGoodsNo=null,cProductSerno=null,fQuantity=null,fPrice=null,fTaxrate=null,
				fTaxPrice=null,dProduct=null,bChecked=null,fLastSettle=null,
				cWhNo=null,cWh=null,dDate=null,cTime=null,iLineNo=null


GO
