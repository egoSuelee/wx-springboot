create view v_ckd_sp_CAIWU
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from ckd_sp
where (guizuno='100'
  or spno='100')
 and cangkuno='001'
and zdriqi between '2009-05-30' and '2009-06-30'
and spno in (select spno from spxx where pinpaino='10081')
group by spno
GO
