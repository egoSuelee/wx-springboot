create view v_ckd_sp_CAIWU02
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from ckd_sp
where (guizuno='500'
  or spno='500')
 and cangkuno='001'
and zdriqi between '2009-04-01' and '2009-05-31'
group by spno
GO
