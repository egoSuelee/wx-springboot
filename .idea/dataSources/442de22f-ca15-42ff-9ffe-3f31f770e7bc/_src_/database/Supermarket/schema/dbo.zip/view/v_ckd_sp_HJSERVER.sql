create view v_ckd_sp_HJSERVER
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from ckd_sp
where (guizuno='88001'
  or spno='88001') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2007-05-31'
group by spno
GO
