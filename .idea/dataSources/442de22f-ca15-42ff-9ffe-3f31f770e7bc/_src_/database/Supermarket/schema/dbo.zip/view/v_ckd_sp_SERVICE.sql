create view v_ckd_sp_SERVICE
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from ckd_sp
where (guizuno='21032'
  or spno='21032') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2006-12-22'
group by spno
GO
