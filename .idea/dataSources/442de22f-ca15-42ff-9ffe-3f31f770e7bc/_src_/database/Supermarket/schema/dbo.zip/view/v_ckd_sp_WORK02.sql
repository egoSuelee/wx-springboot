create view v_ckd_sp_WORK02
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from ckd_sp
where (guizuno='18023'
  or spno='18023') and pandian='0'
 and cangkuno=''
 and zdriqi<='2007-05-31'
group by spno
GO
