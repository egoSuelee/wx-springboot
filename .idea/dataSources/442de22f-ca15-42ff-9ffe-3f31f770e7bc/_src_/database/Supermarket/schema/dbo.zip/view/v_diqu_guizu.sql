
create  view v_diqu_guizu
as
select diquno,diqumc,cParentNo
from diqu
union all
select diquno=guizuno,diqumc=guizu,cParentNo=quno
from guizu


GO
