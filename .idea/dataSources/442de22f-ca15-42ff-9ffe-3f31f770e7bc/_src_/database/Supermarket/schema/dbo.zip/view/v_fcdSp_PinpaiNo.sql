create  view v_fcdSp_PinpaiNo
as
select a.spno,a.mingcheng,a.shuliang,a.jinjiajine,a.zdriqi,b.pinpaino
from fcd_sp a left join spxx b
on a.spno=b.spno
GO
