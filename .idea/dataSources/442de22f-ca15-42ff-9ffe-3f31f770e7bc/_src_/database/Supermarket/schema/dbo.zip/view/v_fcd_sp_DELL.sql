create view v_fcd_sp_DELL
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from fcd_sp
where (guizuno='18001'
  or spno='18001')
 and cangkuno='001'
and zdriqi between '2007-09-29' and '2008-07-15'
group by spno
GO
