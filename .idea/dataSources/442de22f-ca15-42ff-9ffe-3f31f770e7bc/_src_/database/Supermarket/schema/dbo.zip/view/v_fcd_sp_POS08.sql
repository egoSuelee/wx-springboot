create view v_fcd_sp_POS08
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from fcd_sp
where (guizuno='100'
  or spno='100')
 and cangkuno='001'
and zdriqi between '2009-05-30' and '2009-06-30'
group by spno
GO
