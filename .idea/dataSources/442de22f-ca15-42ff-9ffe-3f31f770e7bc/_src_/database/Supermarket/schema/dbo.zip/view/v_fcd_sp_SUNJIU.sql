create view v_fcd_sp_SUNJIU
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from fcd_sp
where (guizuno=''
  or spno='') and pandian='0'
 and zdriqi<='2007-06-08'
group by spno
GO
