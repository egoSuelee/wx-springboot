create view v_init_kucunbiao_825724CA5D4543B
as     
select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,a.bzjj,a.bzlsj,shuliang=isnull(b.shuliang,0),b.deleted,b.cangkuno
 from spxx a left join pdd_sp b
on a.spno=b.spno and b.pandian=0 and b.cangkuno=''
where (a.guizuno='18019' or a.spno='18019')
GO
