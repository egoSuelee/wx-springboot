create view v_init_kucunbiao_HL_SU
as     
select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,a.bzjj,a.bzlsj,shuliang=isnull(b.shuliang,0),b.deleted,b.cangkuno
 from spxx a left join pdd_sp b
on a.spno=b.spno and b.pandian=0 and b.cangkuno='001'
where (a.guizuno='88001' or a.spno='88001')
GO
