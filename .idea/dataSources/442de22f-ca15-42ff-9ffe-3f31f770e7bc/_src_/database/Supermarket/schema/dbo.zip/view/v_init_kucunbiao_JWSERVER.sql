create view v_init_kucunbiao_JWSERVER
as     
select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,a.bzjj,a.bzlsj,shuliang=isnull(b.shuliang,0),b.deleted,b.cangkuno
 from spxx a left join shangpin_kucunbiao b
on a.spno=b.spno and b.deleted=0 and b.cangkuno='001'
 and b.pdpici=''
where a.guizuno='58007' or a.spno='58007'
GO
