create  view v_init_kucunbiao_TLSERVER
as       
select a.spno,a.mingcheng,a.danwei,a.guige,a.bzjj,a.bzlsj,shuliang=isnull(b.shuliang,0),b.deleted,b.cangkuno
 from spxx a left join shangpin_kucunbiao b
on a.spno=b.spno and b.deleted=0 and b.cangkuno=''
 and b.pdpici=''
GO
