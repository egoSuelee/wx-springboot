create view v_jcd_sp_
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from jcd_sp
where (guizuno='18019'
  or spno='18019')
 and cangkuno='001'
and zdriqi between '2007-05-01' and '2007-06-20'
group by spno
GO
