create view v_jcd_sp_825724CA5D4543B
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from jcd_sp
where (guizuno='18019'
  or spno='18019') and pandian='0'
 and cangkuno=''
 and zdriqi<='2007-05-08'
group by spno
GO
