create view v_jcd_sp_CAIWU
as     
select x.spno,shuliang=sum(isnull(x.shuliang,0)),jine=sum(isnull(x.jine,0))    
from     
(     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from jcd_sp
where (guizuno='100'
  or spno='100')
 and cangkuno='001'
and zdriqi between '2009-05-30' and '2009-06-30'
and spno in (select spno from spxx where pinpaino='10081')
group by spno
union all
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from rkd_sp
where (guizuno='100'
  or spno='100')
 and cangkuno='001'
and zdriqi between '2009-05-30' and '2009-06-30'
and spno in (select spno from spxx where pinpaino='10081')
group by spno
) x    
group by x.spno
GO
