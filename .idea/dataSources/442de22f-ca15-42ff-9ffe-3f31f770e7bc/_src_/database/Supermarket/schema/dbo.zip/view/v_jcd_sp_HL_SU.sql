create view v_jcd_sp_HL_SU
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from jcd_sp
where (guizuno='88001'
  or spno='88001') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2007-06-02'
group by spno
GO
