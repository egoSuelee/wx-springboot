create view v_jcd_sp_JINDIE
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from jcd_sp
where (guizuno=''
  or spno='') and pandian='0'
 and zdriqi<='2007-05-31'
group by spno
GO
