create view v_jcd_sp_KUCUN
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from jcd_sp
where (guizuno='68018'
  or spno='68018') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2006-02-05'
group by spno
GO
