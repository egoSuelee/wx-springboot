create view v_jcd_sp_POS03
as     
select f.spno,shuliang=sum(isnull(f.shuliang,0))
 from
(
select spno,shuliang from jcd_sp
where (guizuno='40021'
  or spno='40021') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2009-04-28'
union all
select spno,shuliang from rkd_sp
where (guizuno='40021'
  or spno='40021') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2009-04-28'
) f
group by f.spno
GO
