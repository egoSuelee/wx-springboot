create view v_jcd_sp_TLSERVER
as     
select x.spno,shuliang=sum(isnull(x.shuliang,0)),jine=sum(isnull(x.jine,0))    
from     
(     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from jcd_sp
where (guizuno='40025'
  or spno='40025')
 and cangkuno='001'
and zdriqi between '2009-04-01' and '2009-05-31'
group by spno
union all
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from rkd_sp
where (guizuno='40025'
  or spno='40025')
 and cangkuno='001'
and zdriqi between '2009-04-01' and '2009-05-31'
group by spno
) x    
group by x.spno
GO
