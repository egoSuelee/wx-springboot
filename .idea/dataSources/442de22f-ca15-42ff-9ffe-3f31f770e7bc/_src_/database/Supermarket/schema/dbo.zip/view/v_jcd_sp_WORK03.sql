create view v_jcd_sp_WORK03
as     
select spno,shuliang=sum(isnull(shuliang,0)),jine=sum(isnull(jinjiajine,0))
 from jcd_sp
where (guizuno='88012'
  or spno='88012') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2007-06-07'
group by spno
GO
