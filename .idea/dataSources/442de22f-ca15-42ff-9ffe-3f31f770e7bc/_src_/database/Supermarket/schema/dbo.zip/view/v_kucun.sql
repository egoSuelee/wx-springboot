CREATE  view v_kucun                                    
as                                                     
select a.spno,a.mingcheng,shuliang=isnull(b.shuliang,0)
 from spxx a left join shangpin_kucunbiao b
on a.spno=b.spno and b.deleted=0 and b.cangkuno=''
GO
