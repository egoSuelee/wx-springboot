create  view v_kucunbiao_JINDIE
as     
select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,a.bzjj,a.bzlsj,shuliang=(isnull(a.shuliang,0)+isnull(b.shuliang,0)-
   isnull(c.shuliang,0)-isnull(d.shuliang,0)-
   isnull(e.shuliang,0)-isnull(f.shuliang,0)),qcsl=a.shuliang,
   jcsl=isnull(b.shuliang,0),jcjine=isnull(b.jine,0),
   cksl=isnull(c.shuliang,0),ckjine=isnull(c.jine,0),
   sysl=isnull(d.shuliang,0),syjine=isnull(d.jine,0),
   fcsl=isnull(e.shuliang,0),fcjine=isnull(e.jine,0),
   pdsl=isnull(z.shuliang,0),pdjine=isnull(z.jine,0),
   lssl=isnull(f.shuliang,0),lsjine=f.lsjine,plsjine=g.lsjine,plssl=g.shuliang
from v_init_kucunbiao_JINDIE a  left join v_jcd_sp_JINDIE b on a.spno=b.spno 
  left join v_ckd_sp_JINDIE  c on a.spno=c.spno 
    left join v_syd_sp_JINDIE  d on a.spno=d.spno
      left join v_fcd_sp_JINDIE  e on a.spno=e.spno 
        left join v_lsdsp_JINDIE f on a.spno=f.spno 
        left join v_plsdsp_JINDIE g on a.spno=g.spno 
    left join v_pdd_sp_JINDIE  z on a.spno=z.spno
GO
