create  view v_kucunbiao_WIND
as     
select a.spno,a.mingcheng,a.danwei,a.dw1,a.guige,a.bzjj,a.bzlsj,shuliang=(isnull(a.shuliang,0)+isnull(b.shuliang,0)-
   isnull(c.shuliang,0)-isnull(d.shuliang,0)-
   isnull(e.shuliang,0)-isnull(f.shuliang,0)),qcsl=a.shuliang,
   jcsl=isnull(b.shuliang,0),cksl=isnull(c.shuliang,0),sysl=isnull(d.shuliang,0),fcsl=isnull(e.shuliang,0),
   lssl=isnull(f.shuliang,0),lsjine=f.lsjine,plsjine=g.lsjine,plssl=g.shuliang
from v_init_kucunbiao_WIND a  left join v_jcd_sp_WIND b on a.spno=b.spno 
  left join v_ckd_sp_WIND  c on a.spno=c.spno 
    left join v_syd_sp_WIND  d on a.spno=d.spno
      left join v_fcd_sp_WIND  e on a.spno=e.spno 
        left join v_lsdsp_WIND f on a.spno=f.spno 
        left join v_plsdsp_WIND g on a.spno=g.spno
GO
