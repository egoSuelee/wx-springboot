create view v_lsdSp_PinpaiNo
as
select a.spno,a.mingcheng,a.lsriqi,shuliang=isnull(a.shuliang,0),jine=isnull(a.jine,0),b.pinpaino
from lsdsp a left join spxx b
on a.spno=b.spno
GO
