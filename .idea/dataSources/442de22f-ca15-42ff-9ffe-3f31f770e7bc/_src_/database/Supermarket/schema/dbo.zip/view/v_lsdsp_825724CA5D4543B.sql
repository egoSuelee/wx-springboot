create view v_lsdsp_825724CA5D4543B
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='18019'
  or spno='18019') and pandian='0'
 and lsriqi<='2007-05-08'
group by spno
GO
