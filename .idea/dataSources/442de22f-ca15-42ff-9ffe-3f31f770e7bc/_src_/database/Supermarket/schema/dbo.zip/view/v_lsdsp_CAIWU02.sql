create view v_lsdsp_CAIWU02
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='500'
  or spno='500')
and lsriqi between '2009-04-01' and '2009-05-31'
group by spno
GO
