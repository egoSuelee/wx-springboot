create view v_lsdsp_DELL
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='18001'
  or spno='18001')
and lsriqi between '2007-09-29' and '2008-07-15'
group by spno
GO
