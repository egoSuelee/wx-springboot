create view v_lsdsp_KUCUN
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='68018'
  or spno='68018') and pandian='0'
 and lsriqi<='2006-02-05'
group by spno
GO
