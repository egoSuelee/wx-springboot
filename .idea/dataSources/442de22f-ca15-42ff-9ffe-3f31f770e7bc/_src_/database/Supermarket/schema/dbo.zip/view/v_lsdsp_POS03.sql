create view v_lsdsp_POS03
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from lsdsp
where (guizuno='40021'
  or spno='40021') and pandian='0'
 and lsriqi<='2009-04-28'
group by spno
GO
