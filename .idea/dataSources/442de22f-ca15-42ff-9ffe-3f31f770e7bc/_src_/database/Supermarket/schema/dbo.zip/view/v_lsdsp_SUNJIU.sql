create view v_lsdsp_SUNJIU
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno=''
  or spno='') and pandian='0'
 and lsriqi<='2007-06-08'
group by spno
GO
