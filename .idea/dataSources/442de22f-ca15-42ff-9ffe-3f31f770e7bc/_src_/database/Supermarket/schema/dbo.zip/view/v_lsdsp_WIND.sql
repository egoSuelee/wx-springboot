create view v_lsdsp_WIND
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='68012'
  or spno='68012') and pandian='0'
 and lsriqi<='2006-02-08'
group by spno
GO
