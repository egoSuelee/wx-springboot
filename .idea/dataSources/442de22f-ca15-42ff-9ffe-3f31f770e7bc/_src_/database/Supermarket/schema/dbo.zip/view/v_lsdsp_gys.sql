CREATE view v_lsdsp_gys
as
select a.*,gysno=b.dw2,gysmc=b.dw3 from lsdsp a
left join spxx b on a.spno=b.spno

GO
