
create  view v_lsdsp_qu
as

select a.lsriqi,a.spno,a.mingcheng,c.pinpaino,c.pinpai,a.danwei,a.shuliang,a.danjia,a.jine,
a.guizuno,a.guizu,b.quno,b.qu,b.jingyingfangshi
from lsdsp a left join guizu b
on a.guizuno=b.guizuno
left join spxx c
on a.spno=c.spno

GO
