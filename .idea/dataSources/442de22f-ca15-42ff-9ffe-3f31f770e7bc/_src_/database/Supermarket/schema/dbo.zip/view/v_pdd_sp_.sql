create view v_pdd_sp_
as     
select a.spno,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0))
 from pdd_sp a left join pdd b on a.pddno=b.pddno
where (a.guizuno='18019'
  or a.spno='18019')
 and a.cangkuno='001'
 and a.zdriqi='2007-06-20'
group by spno
GO
