create view v_pdd_sp_POS08
as     
select a.spno,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0))
 from pdd_sp a left join pdd b on a.pddno=b.pddno
where (a.guizuno='100'
  or a.spno='100')
 and a.cangkuno='001'
 and a.zdriqi='2009-06-30'
group by spno
GO
