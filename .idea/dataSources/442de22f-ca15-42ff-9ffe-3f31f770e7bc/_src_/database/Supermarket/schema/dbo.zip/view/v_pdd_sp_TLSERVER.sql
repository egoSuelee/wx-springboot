create view v_pdd_sp_TLSERVER
as     
select a.spno,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0))
 from pdd_sp a left join pdd b on a.pddno=b.pddno
where (a.guizuno='40025'
  or a.spno='40025')
 and a.cangkuno='001'
 and a.zdriqi='2009-05-31'
group by spno
GO
