create view v_pdd_sp_WORK03
as     
select a.spno,shuliang=sum(isnull(a.shuliang,0)),jine=sum(isnull(a.jinjiajine,0))
 from pdd_sp a left join pdd b on a.pddno=b.pddno
where (a.guizuno='88012'
  or a.spno='88012') and isnull(b.shenhe,0)=0
 and a.cangkuno='001'
 and a.zdriqi='2007-06-07'
group by spno
GO
