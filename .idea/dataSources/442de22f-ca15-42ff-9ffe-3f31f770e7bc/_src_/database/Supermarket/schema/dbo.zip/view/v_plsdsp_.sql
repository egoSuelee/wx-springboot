create view v_plsdsp_
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='18019'
  or spno='18019')
and lsriqi between '2007-05-01' and '2007-06-20'
group by spno
GO
