create view v_plsdsp_A01
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='88013'
  or spno='88013') and pandian='0'
 and lsriqi between '2007-05-01' and '2007-05-19'
group by spno
GO
