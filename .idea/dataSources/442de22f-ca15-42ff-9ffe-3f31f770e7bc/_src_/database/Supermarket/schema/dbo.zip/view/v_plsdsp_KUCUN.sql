create view v_plsdsp_KUCUN
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='68018'
  or spno='68018') and pandian='0'
 and lsriqi between '2006-02-05' and '2006-02-05'
group by spno
GO
