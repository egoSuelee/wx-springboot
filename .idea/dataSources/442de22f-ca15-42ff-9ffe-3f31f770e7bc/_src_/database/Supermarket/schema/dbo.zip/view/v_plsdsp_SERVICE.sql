create view v_plsdsp_SERVICE
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='21032'
  or spno='21032') and pandian='0'
 and lsriqi between '2006-12-22' and '2006-12-22'
group by spno
GO
