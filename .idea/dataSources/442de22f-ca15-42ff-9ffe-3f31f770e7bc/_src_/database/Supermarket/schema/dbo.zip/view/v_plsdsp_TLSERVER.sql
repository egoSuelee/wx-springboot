create view v_plsdsp_TLSERVER
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='40025'
  or spno='40025')
and lsriqi between '2009-04-01' and '2009-05-31'
group by spno
GO
