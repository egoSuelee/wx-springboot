create view v_plsdsp_TZJ
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='200'
  or spno='200')
and lsriqi between '2009-04-30' and '2009-05-14'
group by spno
GO
