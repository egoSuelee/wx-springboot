create view v_plsdsp_WORK03
as     
select spno,shuliang=sum(isnull(shuliang,0)),lsjine=sum(isnull(jine,0))
 from lsdsp
where (guizuno='88012'
  or spno='88012') and pandian='0'
 and lsriqi <='2007-06-07'
group by spno
GO
