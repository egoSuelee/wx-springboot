
create  view v_rkdSp_PinpaiNo
as
select a.rkdno,a.spno,a.mingcheng,a.shuliang,a.jinjiajine,a.zdriqi,b.pinpaino
from rkd_sp a left join spxx b
on a.spno=b.spno

GO
