CREATE view v_spxx
as
select * from spxx 
where iSpec is null 
or iSpec=0 
or (iSpec=1 
		and spno in (select spno 
									from t_Ploy_detail 
									where getdate() between dPeriod1 and dPeriod2
							  )
   )
GO
