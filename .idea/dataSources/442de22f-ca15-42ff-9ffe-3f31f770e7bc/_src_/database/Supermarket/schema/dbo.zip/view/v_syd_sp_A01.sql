create view v_syd_sp_A01
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from syd_sp
where (guizuno='88013'
  or spno='88013') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2007-05-19'
group by spno
GO
