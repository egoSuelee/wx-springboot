create view v_syd_sp_JWSERVER
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from syd_sp
where (guizuno='58007'
  or spno='58007') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2005-12-10'
group by spno
GO
