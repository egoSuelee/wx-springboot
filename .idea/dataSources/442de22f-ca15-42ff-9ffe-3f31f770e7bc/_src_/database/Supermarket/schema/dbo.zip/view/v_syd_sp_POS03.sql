create view v_syd_sp_POS03
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from syd_sp
where (guizuno='40021'
  or spno='40021') and pandian=0
 and cangkuno='001'
 and zdriqi<='2009-04-28'
group by spno
GO
