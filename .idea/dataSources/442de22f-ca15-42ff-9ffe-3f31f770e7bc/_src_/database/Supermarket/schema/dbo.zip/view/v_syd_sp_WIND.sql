create view v_syd_sp_WIND
as     
select spno,shuliang=sum(isnull(shuliang,0))
 from syd_sp
where (guizuno='68012'
  or spno='68012') and pandian='0'
 and cangkuno='001'
 and zdriqi<='2006-02-08'
group by spno
GO
