
/*
select * from wh_CheckWhDetail
*/


CREATE  view v_wh_CheckWhDetail
as
	select cSheetno=a.pddno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime

	from dbo.pdd_sp a left join dbo.pdd b on a.pddno=b.pddno
	where a.spno<> '合计:'


GO
