


/*
select * from wh_CheckWhDetail
*/


CREATE    view v_wh_InWarehouseDetail
as
	select cSheetno=a.rkdno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime,
				iLineNo=a.serno	
	from dbo.rkd_sp a left join dbo.rkd b on a.rkdno=b.rkdno
	where a.spno<> '合计:'
	union all
	select cSheetno=a.jcdno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime,
				iLineNo=a.serno	
	from dbo.jcd_sp a left join dbo.jcd b on a.jcdno=b.jcdno
	where a.spno<> '合计:'


GO
