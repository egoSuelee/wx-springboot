


/*
select * from wh_CheckWhDetail
*/


CREATE    view v_wh_LossWarehouseDetail
as
	select cSheetno=a.sydno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime,
				iLineNo=a.serno	
	from dbo.syd_sp a left join dbo.syd b on a.sydno=b.sydno
	where a.spno<> '合计:'


GO
