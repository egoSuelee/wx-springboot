


/*
select * from wh_CheckWhDetail
*/


CREATE    view v_wh_OutWarehouseDetail
as
	select cSheetno=a.ckdno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime,
				iLineNo=a.serno	
	from dbo.ckd_sp a left join dbo.ckd b on a.ckdno=b.ckdno
	where a.spno<> '合计:'


GO
