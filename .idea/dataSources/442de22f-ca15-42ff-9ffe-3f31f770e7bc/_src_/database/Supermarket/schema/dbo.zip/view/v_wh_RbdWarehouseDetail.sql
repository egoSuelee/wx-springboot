


/*
select * from wh_CheckWhDetail
*/


CREATE    view v_wh_RbdWarehouseDetail
as
	select cSheetno=a.fcdno,cGoodsNo=a.spno,cProductSerno=null,fQuantity=a.shuliang,fPrice=a.jinjia,fTaxrate=0,
				fTaxPrice=a.jinjia,dProduct=null,bChecked=a.pandian,fLastSettle=a.jinjiajine,
				cWhNo=b.cangkuno,cWh=b.cangku,dDate=b.zhidanriqi,b.cTime,
				iLineNo=a.serno	
	from dbo.fcd_sp a left join dbo.fcd b on a.fcdno=b.fcdno
	where a.spno<> '合计:'


GO
